import { Toaster } from "@/components/ui/toaster"
import { QueryClientProvider } from '@tanstack/react-query'
import { queryClientInstance } from '@/lib/query-client'
import { BrowserRouter as Router, Route, Routes, Navigate } from 'react-router-dom';
import PageNotFound from './lib/PageNotFound';
import { AuthProvider } from '@/lib/AuthContext';
import ScrollToTop from './components/ScrollToTop';
import ProtectedRoute from '@/components/ProtectedRoute';
import { AppProvider } from '@/lib/AppContext';
import AppLayout from '@/components/layout/AppLayout';
// Auth boilerplate
import Login from '@/pages/Login';
import Register from '@/pages/Register';
import ForgotPassword from '@/pages/ForgotPassword';
import ResetPassword from '@/pages/ResetPassword';
// Add page imports here
import Dashboard from '@/pages/Dashboard';
import Sales from '@/pages/Sales';
import Checkouts from '@/pages/Checkouts';
import PublicCheckout from '@/pages/PublicCheckout';
import Products from '@/pages/Products';
import Customers from '@/pages/Customers';
import Recovery from '@/pages/Recovery';
import Transactions from '@/pages/Transactions';
import Finance from '@/pages/Finance';
import Reports from '@/pages/Reports';
import Settings from '@/pages/Settings';
import Bots from '@/pages/bots/Bots';
import FlowBuilder from '@/pages/bots/FlowBuilder';
import WalletHot from '@/pages/bots/WalletHot';
import BotReports from '@/pages/bots/BotReports';

// SXPay — Plataforma de pagamentos SIMULADA. Nenhum processamento financeiro real.
function App() {
  return (
    <AuthProvider>
      <QueryClientProvider client={queryClientInstance}>
        <Router>
          <ScrollToTop />
          <AppProvider>
            <Routes>
              {/* Auth routes */}
              <Route path="/login" element={<Login />} />
              <Route path="/register" element={<Register />} />
              <Route path="/forgot-password" element={<ForgotPassword />} />
              <Route path="/reset-password" element={<ResetPassword />} />

              {/* Public checkout (no auth required) */}
              <Route path="/c/:id" element={<PublicCheckout />} />

              {/* Authenticated app routes */}
              <Route element={<ProtectedRoute unauthenticatedElement={<Navigate to="/login" replace />} />}>
                <Route element={<AppLayout />}>
                  <Route path="/" element={<Dashboard />} />
                  <Route path="/vendas" element={<Sales />} />
                  <Route path="/checkout" element={<Checkouts />} />
                  <Route path="/produtos" element={<Products />} />
                  <Route path="/clientes" element={<Customers />} />
                  <Route path="/recuperacao" element={<Recovery />} />
                  <Route path="/transacoes" element={<Transactions />} />
                  <Route path="/financeiro" element={<Finance />} />
                  <Route path="/relatorios" element={<Reports />} />
                  <Route path="/configuracoes" element={<Settings />} />
                  <Route path="/bots" element={<Navigate to="/bots/meus-bots" replace />} />
                  <Route path="/bots/meus-bots" element={<Bots />} />
                  <Route path="/bots/fluxos" element={<FlowBuilder />} />
                  <Route path="/bots/wallet" element={<WalletHot />} />
                  <Route path="/bots/relatorios" element={<BotReports />} />
                </Route>
              </Route>

              <Route path="*" element={<PageNotFound />} />
            </Routes>
          </AppProvider>
        </Router>
        <Toaster />
      </QueryClientProvider>
    </AuthProvider>
  )
}

export default App