import React, { useState, useEffect, useMemo } from "react";
import { Search, Users, Mail, Phone, Wallet, ShoppingBag, Calendar, Send, Loader2 } from "lucide-react";
import StatusBadge from "@/components/ui/status-badge";
import { DataTable } from "@/components/ui/data-table";
import EmptyState from "@/components/ui/empty-state";
import { TableSkeleton } from "@/components/ui/loading-skeleton";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { useApp } from "@/lib/AppContext";
import { formatCurrency } from "@/lib/mockData";
import { useToast } from "@/components/ui/use-toast";

export default function Customers() {
  const { customers, transactions, products, sendDeliveryEmail } = useApp();
  const { toast } = useToast();
  const [sending, setSending] = useState(false);
  const [loading, setLoading] = useState(true);
  const [query, setQuery] = useState("");
  const [debounced, setDebounced] = useState("");
  const [selected, setSelected] = useState(null);

  useEffect(() => {
    const t = setTimeout(() => setLoading(false), 500);
    return () => clearTimeout(t);
  }, []);
  useEffect(() => {
    const t = setTimeout(() => setDebounced(query), 300);
    return () => clearTimeout(t);
  }, [query]);

  const filtered = useMemo(() => {
    const q = debounced.toLowerCase().trim();
    if (!q) return customers;
    return customers.filter((c) => c.name.toLowerCase().includes(q) || c.email.toLowerCase().includes(q) || c.cpf.includes(q));
  }, [customers, debounced]);

  const customerTx = selected ? transactions.filter((t) => t.email === selected.email) : [];

  const columns = [
    { key: "name", header: "Cliente", render: (r) => (
      <div className="flex items-center gap-3">
        <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-gradient-to-br from-[#8A0303] to-[#1a1a1a] text-white text-xs font-semibold border border-primary/20">
          {r.name.split(" ").map(n => n[0]).join("").slice(0, 2)}
        </div>
        <div>
          <div className="text-sm text-white">{r.name}</div>
          <div className="text-[11px] text-muted-foreground">{r.email}</div>
        </div>
      </div>
    ) },
    { key: "phone", header: "Telefone", render: (r) => <span className="text-xs text-muted-foreground">{r.phone}</span> },
    { key: "orders", header: "Compras", align: "right", render: (r) => <span className="tabular-nums">{r.orders}</span> },
    { key: "totalSpent", header: "Total gasto", align: "right", render: (r) => <span className="font-medium text-primary tabular-nums">{formatCurrency(r.totalSpent)}</span> },
    { key: "lastPurchase", header: "Última compra", render: (r) => <span className="text-xs text-muted-foreground">{r.lastPurchase}</span> },
    { key: "status", header: "Status", render: (r) => <StatusBadge status={r.status} /> }
  ];

  return (
    <div className="space-y-5 max-w-[1400px] mx-auto">
      <div>
        <span className="text-[10px] uppercase tracking-[0.2em] text-primary font-semibold">CRM</span>
        <h2 className="font-display font-bold text-white text-2xl tracking-tight-display">Clientes</h2>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        {[
          { label: "Total de clientes", value: customers.length, icon: Users },
          { label: "Ativos", value: customers.filter(c => c.status === "ativo").length, icon: ShoppingBag },
          { label: "Receita média", value: formatCurrency(customers.reduce((s, c) => s + c.totalSpent, 0) / (customers.length || 1)), icon: Wallet },
          { label: "Ticket médio", value: formatCurrency(customers.reduce((s, c) => s + c.totalSpent, 0) / (customers.reduce((s, c) => s + c.orders, 0) || 1)), icon: ShoppingBag }
        ].map((s) => (
          <div key={s.label} className="rounded-xl surface p-4 glow-soft flex items-center gap-3">
            <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-black/40 border border-white/5"><s.icon className="h-4 w-4 text-primary" /></div>
            <div>
              <div className="text-[10px] uppercase tracking-[0.12em] text-muted-foreground">{s.label}</div>
              <div className="font-display font-bold text-white text-base tabular-nums">{s.value}</div>
            </div>
          </div>
        ))}
      </div>

      <div className="relative max-w-xs">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Buscar cliente..." className="w-full rounded-lg surface pl-9 pr-3 py-2 text-sm text-white placeholder:text-muted-foreground focus:outline-none focus:border-primary/50" />
      </div>

      <div className="rounded-xl surface glow-soft overflow-hidden">
        {loading ? <TableSkeleton rows={8} cols={6} /> : filtered.length === 0 ? (
          <EmptyState icon={Users} title="Nenhum cliente encontrado" description="Ajuste a busca para encontrar clientes." />
        ) : (
          <DataTable columns={columns} data={filtered} onRowClick={setSelected} />
        )}
      </div>

      {/* Customer detail */}
      <Dialog open={!!selected} onOpenChange={(o) => !o && setSelected(null)}>
        <DialogContent className="bg-popover border-white/10 max-w-lg">
          {selected && (
            <>
              <DialogHeader>
                <DialogTitle className="text-white flex items-center gap-3">
                  <div className="flex h-11 w-11 items-center justify-center rounded-lg bg-gradient-to-br from-[#8A0303] to-[#1a1a1a] text-white text-sm font-semibold border border-primary/30">
                    {selected.name.split(" ").map(n => n[0]).join("").slice(0, 2)}
                  </div>
                  {selected.name}
                </DialogTitle>
              </DialogHeader>
              <div className="grid grid-cols-2 gap-3 py-2">
                <InfoRow icon={Mail} label="E-mail" value={selected.email} />
                <InfoRow icon={Phone} label="Telefone" value={selected.phone} />
                <InfoRow icon={Wallet} label="Total gasto" value={formatCurrency(selected.totalSpent)} />
                <InfoRow icon={ShoppingBag} label="Compras" value={String(selected.orders)} />
                <InfoRow icon={Calendar} label="Última compra" value={selected.lastPurchase} />
                <InfoRow icon={Users} label="Status" value={selected.status === "ativo" ? "Ativo" : "Inativo"} />
              </div>
              {(() => {
                const lastApproved = customerTx.find((t) => t.status === "aprovado");
                const prod = lastApproved ? products.find((p) => p.id === lastApproved.productId) : null;
                if (!prod) return null;
                const hasDelivery = prod.delivery && (prod.delivery.message || (prod.delivery.links || []).some((l) => l.url));
                if (!hasDelivery) return null;
                return (
                  <button
                    onClick={async () => { setSending(true); const res = await sendDeliveryEmail(selected, prod); setSending(false); toast({ title: res.status === "enviado" ? "Acesso reenviado" : "Reenvio registrado (simulado)", description: res.status === "enviado" ? `Links de entrega enviados para ${selected.email}.` : "Destinatário não registrado no app — entrega simulada.", variant: res.status === "enviado" ? "default" : "destructive" }); }}
                    disabled={sending}
                    className="mt-3 w-full inline-flex items-center justify-center gap-2 rounded-lg bg-primary hover:bg-[#E10600] px-4 py-2.5 text-sm font-bold text-white disabled:opacity-60 transition-colors"
                  >
                    {sending ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />} Reenviar acesso ({prod.name})
                  </button>
                );
              })()}
              <div className="mt-2">
                <h4 className="text-xs uppercase tracking-[0.12em] text-muted-foreground font-semibold mb-2">Histórico de compras</h4>
                {customerTx.length === 0 ? (
                  <p className="text-sm text-muted-foreground py-4 text-center">Nenhuma transação registrada.</p>
                ) : (
                  <div className="space-y-1.5 max-h-[240px] overflow-y-auto">
                    {customerTx.map((tx) => (
                      <div key={tx.id} className="flex items-center justify-between rounded-lg bg-white/[0.02] border border-white/5 px-3 py-2">
                        <div>
                          <div className="text-sm text-white">{tx.product}</div>
                          <div className="text-[11px] text-muted-foreground">{tx.date} · {tx.method}</div>
                        </div>
                        <div className="text-right">
                          <div className="text-sm font-medium tabular-nums">{formatCurrency(tx.value)}</div>
                          <StatusBadge status={tx.status} />
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}

function InfoRow({ icon: Icon, label, value }) {
  return (
    <div className="rounded-lg bg-white/[0.02] border border-white/5 p-3">
      <div className="flex items-center gap-1.5 text-[10px] uppercase tracking-[0.1em] text-muted-foreground mb-1"><Icon className="h-3 w-3" />{label}</div>
      <div className="text-sm text-white truncate">{value}</div>
    </div>
  );
}