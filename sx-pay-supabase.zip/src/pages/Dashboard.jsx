import React, { useState, useEffect, useMemo } from "react";
import {
  AreaChart, Area, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip,
  ResponsiveContainer } from
"recharts";
import { ArrowUpRight, ArrowDownRight, TrendingUp, BarChart3, Target, CheckCircle, Receipt, Wallet, Radio, Camera } from "lucide-react";
import { TableSkeleton } from "@/components/ui/loading-skeleton";
import StatusBadge from "@/components/ui/status-badge";
import CountUp from "@/components/ui/CountUp";
import Sparkline from "@/components/ui/Sparkline";
import LiveFeedPanel from "@/components/dashboard/LiveFeedPanel";
import TerritoryMap from "@/components/dashboard/TerritoryMap";
import { ChartTooltip } from "@/components/charts/ChartTooltip";
import {
  dashboardStats, revenueSeries, salesBars, checkoutFunnel,
  chargebackSeries, formatCurrency } from
"@/lib/mockData";
import { useApp } from "@/lib/AppContext";
import { Link } from "react-router-dom";
import PrintFaturamentoModal from "@/components/dashboard/PrintFaturamentoModal";
import ExportZipButton from "@/components/dashboard/ExportZipButton";
import { pickRandomPhrase } from "@/lib/systemxPhrases";
import { cn } from "@/lib/utils";

export default function Dashboard() {
  const { transactions } = useApp();
  const [loading, setLoading] = useState(true);
  const [printOpen, setPrintOpen] = useState(false);

  useEffect(() => {
    const t = setTimeout(() => setLoading(false), 600);
    return () => clearTimeout(t);
  }, []);

  const balance = dashboardStats[0];
  const secondary = dashboardStats.slice(1);
  const recentTx = transactions.slice(0, 6);
  const sparkData = revenueSeries.map((d) => d.faturamento);
  // Frase SYSTEMX viva no card de saldo — sorteada a cada carregamento.
  const balancePhrase = useMemo(() => pickRandomPhrase(), []);

  return (
    <div className="space-y-5 max-w-[1400px] mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-3">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-[10px] uppercase tracking-[0.2em] text-primary font-semibold">Cockpit</span>
            <span className="h-1 w-1 rounded-full bg-muted-foreground/40" />
            <span className="text-[10px] uppercase tracking-[0.2em] text-muted-foreground">03 Ago 2026</span>
          </div>
          <h2 className="font-display font-bold text-white text-2xl sm:text-3xl tracking-tight-display">Bom dia, Márcio.</h2>
          <p className="text-sm text-muted-foreground mt-1">Suas vendas estão <span className="text-success">+18,4%</span> acima do mês passado.</p>
        </div>
        <div className="flex items-center gap-2">
          <button onClick={() => setPrintOpen(true)} className="inline-flex items-center gap-2 rounded-lg border border-white/12 bg-white/[0.02] px-4 py-2.5 text-sm font-medium text-white/90 hover:border-primary/40 hover:text-white transition-colors">
            <Camera className="h-4 w-4 text-primary" /> Printar faturamento
          </button>
          <ExportZipButton />
          <Link to="/checkout" className="inline-flex items-center gap-2 rounded-lg bg-primary px-4 py-2.5 text-sm font-semibold text-white glow-red-sm hover:bg-[#E10600] transition-colors">
            <ArrowUpRight className="h-4 w-4" /> Criar checkout
          </Link>
        </div>
      </div>

      {/* Hero + secundários */}
      <div className="grid grid-cols-1 xl:grid-cols-[1.4fr_1fr] gap-4">
        {/* Hero — Saldo disponível */}
        <div className="relative rounded-2xl surface glow-soft overflow-hidden p-6 lg:p-7 min-h-[180px] flex flex-col justify-between">
          {/* sparkline marca d'água */}
          <div className="absolute inset-x-0 bottom-0 pointer-events-none" style={{ opacity: 0.22 }}>
            <Sparkline data={sparkData} height={120} color="#C10000" fill opacity={1} />
          </div>
          <div className="relative">
            <div className="flex items-center gap-2">
              <Wallet className="h-4 w-4 text-primary" />
              <span className="text-[10px] uppercase tracking-[0.2em] text-muted-foreground font-semibold">Saldo disponível</span>
              <span className="ml-1 inline-flex items-center gap-1 text-[10px] text-success"><ArrowUpRight className="h-3 w-3" />{balance.trend}%</span>
            </div>
            <div className="mt-2 flex items-end gap-2">
              {loading ?
              <div className="h-12 w-56 rounded-lg bg-white/5 animate-pulse" /> :

              <CountUp value={balance.value} prefix="R$ " decimals={2} className="font-display font-extrabold text-white text-4xl lg:text-5xl tracking-tight-display tabular-nums" />
              }
              <span className="text-[11px] text-muted-foreground mb-2">{balance.trendLabel}</span>
            </div>
            {!loading && (
              <p className="mt-3 text-[12px] sm:text-[13px] italic font-display tracking-tight bg-gradient-to-r from-white/70 via-white/45 to-primary/70 bg-clip-text text-transparent">{balancePhrase}</p>
            )}
          </div>
          <div className="relative flex items-center justify-between mt-3">
            <div className="flex items-center gap-1.5 text-[11px] text-muted-foreground">
              <span className="relative flex h-2 w-2"><span className="absolute inline-flex h-full w-full rounded-full bg-primary opacity-60 animate-ping" /><span className="relative inline-flex h-2 w-2 rounded-full bg-primary" /></span>
              3 vendas nos últimos 5 minutos
            </div>
            <Link to="/financeiro" className="text-xs text-primary hover:underline">Ver financeiro →</Link>
          </div>
        </div>

        {/* Secundários — hierarquia menor */}
        <div className="grid grid-cols-2 sm:grid-cols-3 xl:grid-cols-2 gap-3">
          {secondary.map((s) =>
          loading ?
          <div key={s.id} className="rounded-xl surface p-4 glow-soft"><div className="animate-pulse space-y-2"><div className="h-3 w-20 bg-white/5 rounded" /><div className="h-6 w-24 bg-white/5 rounded" /></div></div> :

          <SecondaryCard key={s.id} stat={s} />

          )}
        </div>
      </div>

      {/* Gráfico principal + funil + ao vivo */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <div className="lg:col-span-2 rounded-2xl surface glow-soft p-5">
          <div className="flex items-center justify-between mb-5">
            <div>
              <h3 className="font-display font-semibold text-white text-sm">Faturamento</h3>
              <p className="text-[11px] text-muted-foreground">Últimos 30 dias</p>
            </div>
            <div className="flex items-center gap-1.5 text-[11px] text-success"><ArrowUpRight className="h-3.5 w-3.5" /> +18,4%</div>
          </div>
          <ResponsiveContainer width="100%" height={260}>
            <AreaChart data={revenueSeries} margin={{ top: 5, right: 5, left: -20, bottom: 0 }}>
              <defs>
                <linearGradient id="revGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#C10000" stopOpacity={0.35} />
                  <stop offset="100%" stopColor="#C10000" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="2 4" stroke="rgba(255,255,255,0.025)" vertical={false} />
              <XAxis dataKey="day" tick={{ fill: "hsl(0 0% 40%)", fontSize: 10 }} axisLine={false} tickLine={false} interval={4} />
              <YAxis tick={{ fill: "hsl(0 0% 40%)", fontSize: 10 }} axisLine={false} tickLine={false} tickFormatter={(v) => `${v / 1000}k`} />
              <Tooltip content={<ChartTooltip currency />} />
              <Area type="monotone" dataKey="faturamento" stroke="#C10000" strokeWidth={1.5} fill="url(#revGrad)" animationDuration={1400} />
              <Area type="monotone" dataKey="meta" stroke="rgba(255,255,255,0.12)" strokeWidth={1} strokeDasharray="4 4" fill="none" animationDuration={1400} />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        <LiveFeedPanel transactions={transactions} />
      </div>

      {/* Funil + aprovação + vendas dia */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <div className="rounded-2xl surface glow-soft p-5">
          <h3 className="font-display font-semibold text-white text-sm mb-1">Conversão do checkout</h3>
          <p className="text-[11px] text-muted-foreground mb-5">Funil de vendas</p>
          <div className="space-y-2.5">
            {checkoutFunnel.map((step, i) => {
              const pct = (step.valor / checkoutFunnel[0].valor * 100).toFixed(1);
              return (
                <div key={step.etapa}>
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-xs text-muted-foreground">{step.etapa}</span>
                    <span className="text-xs text-white font-medium tabular-nums">{step.valor.toLocaleString("pt-BR")} <span className="text-muted-foreground/60">· {pct}%</span></span>
                  </div>
                  <div className="h-7 rounded-md bg-white/[0.03] overflow-hidden relative">
                    <div className="h-full rounded-md transition-all duration-700" style={{ width: `${pct}%`, background: step.cor, boxShadow: "0 0 12px -2px " + step.cor }} />
                  </div>
                </div>);

            })}
          </div>
        </div>

        <div className="rounded-2xl surface glow-soft p-5">
          <h3 className="font-display font-semibold text-white text-sm mb-1">Taxa de aprovação</h3>
          <p className="text-[11px] text-muted-foreground mb-4">Últimos 30 dias</p>
          <div className="flex flex-col items-center justify-center py-2">
            <div className="relative h-[140px] w-[140px]">
              <svg className="h-full w-full -rotate-90" viewBox="0 0 100 100">
                <circle cx="50" cy="50" r="42" fill="none" stroke="rgba(255,255,255,0.05)" strokeWidth="8" />
                <circle cx="50" cy="50" r="42" fill="none" stroke="#C10000" strokeWidth="8" strokeLinecap="round" strokeDasharray={`${92.4 * 2.64} 264`} style={{ filter: "drop-shadow(0 0 4px rgba(193,0,0,0.5))" }} />
              </svg>
              <div className="absolute inset-0 flex flex-col items-center justify-center">
                <span className="font-display font-bold text-white text-3xl tracking-tight-display tabular-nums">92,4%</span>
                <span className="text-[10px] text-success">+1,2%</span>
              </div>
            </div>
            <p className="text-xs text-muted-foreground mt-3">1.248 de 1.351 pagamentos</p>
          </div>
        </div>

        <div className="rounded-2xl surface glow-soft p-5">
          <h3 className="font-display font-semibold text-white text-sm mb-1">Vendas por dia</h3>
          <p className="text-[11px] text-muted-foreground mb-4">Esta semana</p>
          <ResponsiveContainer width="100%" height={180}>
            <BarChart data={salesBars} margin={{ top: 5, right: 5, left: -28, bottom: 0 }}>
              <CartesianGrid strokeDasharray="2 4" stroke="rgba(255,255,255,0.025)" vertical={false} />
              <XAxis dataKey="dia" tick={{ fill: "hsl(0 0% 40%)", fontSize: 10 }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fill: "hsl(0 0% 40%)", fontSize: 10 }} axisLine={false} tickLine={false} />
              <Tooltip content={<ChartTooltip />} cursor={{ fill: "rgba(255,255,255,0.02)" }} />
              <Bar dataKey="vendas" fill="#8A0303" radius={[4, 4, 0, 0]} maxBarSize={32} animationDuration={1000} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Mapa de vendas por território */}
      <TerritoryMap period="30d" />

      {/* Transações recentes */}
      <div className="rounded-2xl surface glow-soft overflow-hidden">
        


        
        {loading ? <TableSkeleton rows={5} cols={5} /> :
        <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-white/5">
                  {["ID", "Cliente", "Produto", "Valor", "Origem", "Status"].map((h) =>
                <th key={h} className="text-left text-[10px] uppercase tracking-[0.12em] text-muted-foreground font-semibold py-3 px-5 hidden">{h}</th>
                )}
                </tr>
              </thead>
              <tbody>
                {recentTx.map((tx) =>
              <tr key={tx.id} className="border-b border-white/[0.03] hover:bg-white/[0.02] transition-colors">
                    
                    
                    
                    
                    
                    
                  </tr>
              )}
              </tbody>
            </table>
          </div>
        }
      </div>

      <PrintFaturamentoModal open={printOpen} onOpenChange={setPrintOpen} />
    </div>);

}

function SecondaryCard({ stat }) {
  const ICONS = { "trending-up": TrendingUp, "bar-chart": BarChart3, target: Target, "check-circle": CheckCircle, receipt: Receipt };
  const Icon = ICONS[stat.icon] || TrendingUp;
  const up = (stat.trend || 0) >= 0;
  const isCount = stat.isCount;
  return (
    <div className="group rounded-xl surface glow-soft p-4 transition-all hover:-translate-y-0.5 hover:shadow-[0_8px_30px_-12px_rgba(193,0,0,0.35)]">
      <div className="flex items-center justify-between">
        <span className="text-[10px] uppercase tracking-[0.12em] text-muted-foreground">{stat.label}</span>
        <Icon className="h-3.5 w-3.5 text-muted-foreground/60 group-hover:text-primary transition-colors" />
      </div>
      <div className="mt-1.5">
        <CountUp value={stat.value} prefix={stat.prefix || ""} suffix={stat.suffix || ""} decimals={stat.decimals || 0} className="font-display font-bold text-white text-xl tracking-tight-display tabular-nums" />
      </div>
      <div className={cn("flex items-center gap-1 text-[10px] mt-0.5", up ? "text-success" : "text-[#FF6A4D]")}>
        {up ? <ArrowUpRight className="h-3 w-3" /> : <ArrowDownRight className="h-3 w-3" />}
        {Math.abs(stat.trend)}% <span className="text-muted-foreground/60">{stat.trendLabel}</span>
      </div>
    </div>);

}