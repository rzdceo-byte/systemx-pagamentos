import React, { useState, useMemo, useEffect } from "react";
import { useParams, Link } from "react-router-dom";
import { Lock, Shield, Zap, Check, QrCode, Barcode, CreditCard, Loader2, ArrowLeft, Star, Clock, Users, ChevronDown, Film, ChevronRight } from "lucide-react";
import Logo from "@/components/Logo";
import { useApp } from "@/lib/AppContext";
import { useToast } from "@/components/ui/use-toast";
import { formatCurrency } from "@/lib/mockData";
import { maskCPF, maskPhone, maskCard, maskExpiry, maskCVV, detectBrand, BRAND_LABELS, isValidEmail, isValidCPF } from "@/lib/masks";
import { cn } from "@/lib/utils";

function parseVideoId(url) {
  if (!url) return null;
  const yt = url.match(/(?:youtube\.com\/(?:watch\?v=|embed\/)|youtu\.be\/)([\w-]{6,})/);
  if (yt) return { provider: "youtube", id: yt[1] };
  const vm = url.match(/vimeo\.com\/(\d+)/);
  if (vm) return { provider: "vimeo", id: vm[1] };
  return null;
}

export default function PublicCheckout() {
  const { id } = useParams();
  const { checkouts, products, registerSale, registerLead } = useApp();
  const { toast } = useToast();
  const checkout = useMemo(() => checkouts.find((c) => c.id === id), [checkouts, id]);
  const product = useMemo(() => products.find((p) => p.id === checkout?.productId), [products, checkout]);
  const delivery = product?.delivery || null;

  // Captura UTM da URL para rastreamento de origem
  const utmSource = useMemo(() => {
    const p = new URLSearchParams(window.location.search);
    return p.get("utm_source") || p.get("src") || "Direto";
  }, []);

  const [method, setMethod] = useState("pix");
  const [processing, setProcessing] = useState(false);
  const [success, setSuccess] = useState(false);
  const [customer, setCustomer] = useState({ name: "", email: "", phone: "", cpf: "" });
  const [card, setCard] = useState({ number: "", name: "", expiry: "", cvv: "" });
  const [bump, setBump] = useState(false);
  const [coupon, setCoupon] = useState("");
  const [couponApplied, setCouponApplied] = useState(false);
  const [faqOpen, setFaqOpen] = useState(null);
  const [errors, setErrors] = useState({});
  const [step, setStep] = useState("lead"); // "lead" | "payment"
  const [consent, setConsent] = useState(false);
  const [leadRegistered, setLeadRegistered] = useState(false);

  useEffect(() => {
    if (checkout?.hasOrderBump && checkout.orderBump?.prechecked) setBump(true);
  }, [checkout]);

  if (!checkout) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-black px-6 text-center">
        <Logo size={40} />
        <h1 className="font-display font-bold text-white text-xl mt-6">Checkout não encontrado</h1>
        <p className="text-sm text-muted-foreground mt-2">Este checkout não existe ou foi despublicado.</p>
        <Link to="/" className="mt-6 inline-flex items-center gap-2 text-sm text-primary hover:underline"><ArrowLeft className="h-4 w-4" /> Voltar</Link>
      </div>
    );
  }

  if (!checkout.published) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-black px-6 text-center">
        <Logo size={40} />
        <h1 className="font-display font-bold text-white text-xl mt-6">Checkout indisponível</h1>
        <p className="text-sm text-muted-foreground mt-2">Este checkout está em modo rascunho.</p>
      </div>
    );
  }

  const template = checkout.template || "classico";
  const accent = checkout.accentColor || "#C10000";
  const bgColor = checkout.colors?.background || "#0D0D0D";
  const textColor = checkout.colors?.text || "#FFFFFF";
  const btnColor = checkout.colors?.button || accent;
  const fontFamily = `'${checkout.fontFamily || "Space Grotesk"}', sans-serif`;
  const brand = detectBrand(card.number);
  const media = checkout.media || {};
  const leadCfg = checkout.leadCapture || {};
  const twoStep = leadCfg.twoStep;
  const consentRequired = leadCfg.consentRequired;
  const activeStep = twoStep ? step : "payment";

  const basePrice = checkout.promoPrice || checkout.price;
  const bumpAdds = bump && checkout.hasOrderBump ? checkout.orderBump.price : 0;
  const pixDiscount = method === "pix" && checkout.payments?.pixDiscount ? (basePrice * (checkout.payments.pixDiscount / 100)) : 0;
  const couponDiscount = couponApplied && checkout.coupon?.enabled
    ? (checkout.coupon.type === "percent" ? basePrice * (checkout.coupon.value / 100) : checkout.coupon.value)
    : 0;
  const total = Math.max(0, basePrice - pixDiscount - couponDiscount) + bumpAdds;

  // O formulário de dados do lead é obrigatório em todo checkout — sempre visível e validado.
  const validateLead = () => {
    const e = {};
    if (!customer.name.trim()) e.name = "Informe seu nome";
    if (!isValidEmail(customer.email)) e.email = "E-mail inválido";
    if (!isValidCPF(customer.cpf)) e.cpf = "CPF inválido";
    if (customer.phone.replace(/\D/g, "").length < 10) e.phone = "Telefone inválido";
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const validatePayment = () => {
    if (method !== "card") return true;
    const e = { ...errors };
    let ok = true;
    if (card.number.replace(/\D/g, "").length < 13) { e.cardNumber = "Número inválido"; ok = false; }
    if (!card.name.trim()) { e.cardName = "Nome obrigatório"; ok = false; }
    if (card.expiry.length < 5) { e.expiry = "Validade inválida"; ok = false; }
    if (card.cvv.length < 3) { e.cvv = "CVV inválido"; ok = false; }
    setErrors(e);
    return ok;
  };

  const handleContinueToPayment = () => {
    if (!validateLead()) { toast({ title: "Verifique seus dados", variant: "destructive" }); return; }
    if (consentRequired && !consent) { toast({ title: "Aceite os termos para continuar", variant: "destructive" }); return; }
    if (!leadRegistered) { registerLead({ checkout, customer: { ...customer }, source: utmSource }); setLeadRegistered(true); }
    setStep("payment");
  };

  const handlePay = () => {
    if (!validateLead()) { toast({ title: "Verifique seus dados", variant: "destructive" }); return; }
    if (twoStep && consentRequired && !consent) { toast({ title: "Aceite os termos", variant: "destructive" }); return; }
    if (!validatePayment()) { toast({ title: "Verifique os dados do cartão", variant: "destructive" }); return; }
    if (!leadRegistered) { registerLead({ checkout, customer: { ...customer }, source: utmSource }); setLeadRegistered(true); }
    setProcessing(true);
    // SIMULAÇÃO de pagamento — nenhum processamento real ocorre
    setTimeout(() => {
      setProcessing(false);
      setSuccess(true);
      registerSale({
        checkout: { ...checkout, productName: checkout.productName || checkout.name, price: total },
        customer: { ...customer },
        method: method === "pix" ? "PIX" : method === "card" ? "Cartão de crédito" : "Boleto",
        status: "aprovado",
        source: utmSource
      });
    }, 2200);
  };

  const applyCoupon = () => {
    if (!checkout.coupon?.enabled) return;
    if (coupon.trim().toUpperCase() === (checkout.coupon.code || "").toUpperCase()) {
      setCouponApplied(true);
      toast({ title: "Cupom aplicado!", description: `Desconto de ${checkout.coupon.type === "percent" ? checkout.coupon.value + "%" : formatCurrency(checkout.coupon.value)} aplicado.` });
    } else toast({ title: "Cupom inválido", variant: "destructive" });
  };

  const showTestimonials = checkout.sections?.testimonials && (checkout.testimonials || []).length > 0;
  const showFaq = checkout.sections?.faq && (checkout.faq || []).length > 0;
  const showWarranty = checkout.sections?.warranty;
  const showCounter = checkout.sections?.counter && checkout.urgencyCounter?.enabled;
  const showStock = checkout.stockBar?.enabled;
  const showSocial = checkout.socialProof?.enabled;
  const headline = checkout.headline || checkout.productName || checkout.name;
  const description = checkout.description || "";

  if (success) {
    return (
      <div className="min-h-screen bg-black bg-circuit flex flex-col items-center justify-center px-6" style={{ fontFamily }}>
        <div className="max-w-md w-full text-center animate-fade-in">
          <div className="relative mx-auto mb-6 h-20 w-20">
            <div className="absolute inset-0 rounded-full" style={{ background: accent, opacity: 0.15, filter: "blur(20px)" }} />
            <div className="relative h-20 w-20 rounded-full flex items-center justify-center border-2" style={{ borderColor: accent, background: accent + "15" }}>
              <Check className="h-10 w-10" style={{ color: accent }} />
            </div>
          </div>
          <h1 className="font-display font-bold text-white text-2xl tracking-tight-display">Pagamento aprovado!</h1>
          <p className="text-sm text-muted-foreground mt-2">Recebemos seu pagamento de <span className="text-white font-medium">{formatCurrency(total)}</span>. Enviamos os detalhes para <span className="text-white">{customer.email}</span>.</p>
          <div className="mt-6 rounded-xl surface p-4 text-left">
            <div className="flex justify-between text-sm py-1.5"><span className="text-muted-foreground">Produto</span><span className="text-white">{headline}</span></div>
            <div className="flex justify-between text-sm py-1.5"><span className="text-muted-foreground">Método</span><span className="text-white">{method === "pix" ? "PIX" : method === "card" ? "Cartão" : "Boleto"}</span></div>
            <div className="flex justify-between text-sm py-1.5 border-t border-white/5 mt-1 pt-2.5"><span className="text-muted-foreground">Total pago</span><span className="text-white font-bold" style={{ color: accent }}>{formatCurrency(total)}</span></div>
          </div>

          {delivery && (delivery.message || (delivery.links || []).some((l) => l.url)) && (
            <div className="mt-4 rounded-xl border p-4 text-left" style={{ borderColor: accent + "40", background: accent + "0A" }}>
              <h2 className="font-display font-bold text-white text-sm mb-2 flex items-center gap-2"><Check className="h-4 w-4" style={{ color: accent }} /> Seu acesso está pronto</h2>
              {delivery.message && <p className="text-xs text-muted-foreground leading-relaxed mb-3">{delivery.message}</p>}
              {(delivery.links || []).filter((l) => l.url).length > 0 && (
                <div className="space-y-2">
                  {(delivery.links || []).filter((l) => l.url).map((l, i) => (
                    <a key={i} href={l.url} target="_blank" rel="noopener noreferrer" className="flex items-center justify-between gap-3 rounded-lg bg-white/5 border border-white/10 px-3 py-2.5 hover:border-primary/40 transition-colors">
                      <div className="min-w-0 text-left">
                        <div className="text-sm text-white font-medium truncate">{l.label || "Acessar"}</div>
                        <div className="text-[10px] text-muted-foreground">{l.type}</div>
                      </div>
                      <span className="text-xs font-bold shrink-0" style={{ color: accent }}>Acessar →</span>
                    </a>
                  ))}
                </div>
              )}
            </div>
          )}

          <div className="flex items-center justify-center gap-4 mt-6 text-[11px] text-muted-foreground">
            <span className="flex items-center gap-1"><Lock className="h-3 w-3" /> Pagamento seguro</span>
            <span className="flex items-center gap-1"><Shield className="h-3 w-3" /> Dados protegidos</span>
          </div>
        </div>
      </div>
    );
  }

  // ---- Blocos de mídia ----
  const mediaBlock = (extraCls = "") => {
    if (media.type === "vsl") return <VslBlock media={media} accent={accent} className={extraCls} />;
    if (media.type === "image") return <img src={media.imageUrl} alt={headline} className={`w-full object-cover ${extraCls}`} style={{ height: media.imageRatio === "retrato" ? 320 : media.imageRatio === "quadrada" ? 240 : 256 }} />;
    if (media.type === "none" && checkout.productImage) return <img src={checkout.productImage} alt={headline} className={`w-full h-48 lg:h-64 object-cover ${extraCls}`} />;
    return null;
  };

  // ---- Coluna de produto (mídia + oferta + seções) ----
  const ProductColumn = ({ withMedia = true }) => (
    <div className="space-y-6">
      <div className="rounded-2xl surface glow-soft overflow-hidden">
        {withMedia && media.type !== "none" && media.mediaOrder !== "offer-first" && mediaBlock()}
        {withMedia && media.type === "none" && checkout.productImage && <img src={checkout.productImage} alt={headline} className="w-full h-48 lg:h-64 object-cover" />}
        <div className="p-5 lg:p-6">
          <h1 className="font-display font-bold text-white text-xl lg:text-2xl tracking-tight-display leading-tight">{headline}</h1>
          {description && <p className="text-sm text-muted-foreground mt-2 leading-relaxed">{description}</p>}
          {withMedia && media.type !== "none" && media.mediaOrder === "offer-first" && (
            <div className="mt-4">{mediaBlock("rounded-lg")}</div>
          )}

          <div className="flex items-center gap-2 mt-5">
            {checkout.methods?.includes("pix") && <MethodPill icon={QrCode} label="PIX" accent={accent} />}
            {checkout.methods?.includes("card") && <MethodPill icon={CreditCard} label="Cartão" accent={accent} />}
            {checkout.methods?.includes("boleto") && <MethodPill icon={Barcode} label="Boleto" accent={accent} />}
          </div>

          <div className="grid grid-cols-3 gap-2 mt-6">
            {[
              { key: "secure", icon: Lock, t: "Pagamento seguro" },
              { key: "privacy", icon: Shield, t: "Dados protegidos" },
              { key: "fast", icon: Zap, t: "Aprovação rápida" },
              { key: "verified", icon: Check, t: "Compra verificada" }
            ].filter((s) => checkout.trustSeals?.[s.key]).slice(0, 3).map((s) => (
              <div key={s.t} className="flex flex-col items-center text-center gap-1.5 rounded-lg bg-white/[0.02] border border-white/5 p-3">
                <s.icon className="h-4 w-4" style={{ color: accent }} />
                <span className="text-[10px] text-muted-foreground leading-tight">{s.t}</span>
              </div>
            ))}
          </div>

          {showStock && (
            <div className="mt-5">
              <div className="flex justify-between text-[11px] text-muted-foreground mb-1.5"><span>{checkout.stockBar.text}</span><span className="text-white font-medium">{checkout.stockBar.qty} unidades</span></div>
              <div className="h-2 rounded-full bg-white/10 overflow-hidden"><div className="h-full rounded-full" style={{ width: `${Math.min(100, (checkout.stockBar.qty / 50) * 100)}%`, background: accent }} /></div>
            </div>
          )}
        </div>
      </div>

      {showWarranty && (
        <div className="rounded-2xl surface glow-soft p-5 text-center">
          <Shield className="h-8 w-8 mx-auto mb-2" style={{ color: accent }} />
          <h3 className="font-display font-bold text-white text-sm mb-1">Garantia de {checkout.warrantyText?.match(/\d+/)?.[0] || 7} dias</h3>
          <p className="text-xs text-muted-foreground leading-relaxed max-w-md mx-auto">{checkout.warrantyText}</p>
        </div>
      )}

      {showTestimonials && (
        <div className="rounded-2xl surface glow-soft p-5">
          <h3 className="font-display font-bold text-white text-sm mb-4">O que dizem nossos clientes</h3>
          <div className="grid sm:grid-cols-2 gap-3">
            {checkout.testimonials.map((t, i) => (
              <div key={i} className="rounded-lg bg-white/[0.02] border border-white/5 p-4">
                <div className="flex items-center gap-2.5 mb-2">
                  {t.photo ? <img src={t.photo} alt="" className="h-9 w-9 rounded-full object-cover" /> : <div className="h-9 w-9 rounded-full bg-white/10 flex items-center justify-center text-sm font-bold text-white">{t.name?.[0]}</div>}
                  <div><div className="text-sm text-white font-medium">{t.name}</div><div className="flex">{Array.from({ length: t.rating || 5 }).map((_, s) => <Star key={s} className="h-3 w-3" style={{ color: accent, fill: accent }} />)}</div></div>
                </div>
                <p className="text-xs text-muted-foreground leading-relaxed">"{t.text}"</p>
              </div>
            ))}
          </div>
        </div>
      )}

      {showFaq && (
        <div className="rounded-2xl surface glow-soft p-5">
          <h3 className="font-display font-bold text-white text-sm mb-4">Perguntas frequentes</h3>
          <div className="space-y-2">
            {checkout.faq.map((f, i) => (
              <div key={i} className="rounded-lg bg-white/[0.02] border border-white/5 overflow-hidden">
                <button onClick={() => setFaqOpen(faqOpen === i ? null : i)} className="w-full flex items-center justify-between px-4 py-3 text-left text-sm text-white">
                  {f.q}
                  <ChevronDown className={cn("h-4 w-4 text-muted-foreground transition-transform", faqOpen === i && "rotate-180")} />
                </button>
                {faqOpen === i && <div className="px-4 pb-3 text-xs text-muted-foreground leading-relaxed">{f.a}</div>}
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );

  // ---- Bloco do formulário de lead (sempre presente, 4 campos) ----
  const LeadForm = () => (
    <div className="space-y-3 mb-4">
      <div className="flex items-center gap-2 text-[11px] text-muted-foreground uppercase tracking-wider">
        <span className="h-5 w-5 rounded-full flex items-center justify-center text-[10px] font-bold text-white" style={{ background: accent }}>1</span>
        Seus dados
      </div>
      <Field label="Nome completo" error={errors.name}>
        <input value={customer.name} onChange={(e) => setCustomer({ ...customer, name: e.target.value })} placeholder="Seu nome" className={inputCls(errors.name)} />
      </Field>
      <Field label="E-mail" error={errors.email}>
        <input type="email" value={customer.email} onChange={(e) => setCustomer({ ...customer, email: e.target.value })} placeholder="voce@email.com" className={inputCls(errors.email)} />
      </Field>
      <div className="grid grid-cols-2 gap-3">
        <Field label="Telefone / WhatsApp" error={errors.phone}>
          <input value={customer.phone} onChange={(e) => setCustomer({ ...customer, phone: maskPhone(e.target.value) })} placeholder="(11) 90000-0000" className={inputCls(errors.phone)} />
        </Field>
        <Field label="CPF" error={errors.cpf}>
          <input value={customer.cpf} onChange={(e) => setCustomer({ ...customer, cpf: maskCPF(e.target.value) })} placeholder="000.000.000-00" className={inputCls(errors.cpf)} />
        </Field>
      </div>
    </div>
  );

  // ---- Coluna de pagamento (card fixo à direita) ----
  const PaymentColumn = ({ centered = false }) => (
    <div className={centered ? "" : "order-1 lg:order-2"}>
      <div className={cn("rounded-2xl surface glow-soft p-5 lg:p-6", !centered && "sticky top-24")}>
        <div className="flex items-baseline justify-between mb-4 pb-4 border-b border-white/5">
          <span className="text-xs text-muted-foreground">Total</span>
          <div className="text-right">
            {checkout.promoPrice && checkout.price > checkout.promoPrice && <div className="text-xs text-muted-foreground line-through">{formatCurrency(checkout.price)}</div>}
            <div className="font-display font-bold text-white text-2xl tracking-tight-display tabular-nums" style={{ color: accent }}>{formatCurrency(total)}</div>
            {(pixDiscount > 0 || couponDiscount > 0) && <div className="text-[10px] text-success">desconto aplicado</div>}
            {checkout.payments?.maxInstallments > 1 && method === "card" && <div className="text-[10px] text-muted-foreground">ou {checkout.payments.maxInstallments}x de {formatCurrency(total / checkout.payments.maxInstallments)}</div>}
          </div>
        </div>

        {checkout.hasOrderBump && (
          <label className="flex items-start gap-3 rounded-lg border p-3 mb-4 cursor-pointer transition-all" style={{ borderColor: bump ? accent : "rgba(255,255,255,0.08)", background: bump ? accent + "0A" : "transparent" }}>
            <input type="checkbox" checked={bump} onChange={(e) => setBump(e.target.checked)} className="mt-0.5 h-4 w-4" style={{ accentColor: accent }} />
            <div className="flex-1">
              <div className="text-sm text-white font-medium">{checkout.orderBump.name}</div>
              {checkout.orderBump.text && <div className="text-[11px] text-muted-foreground mt-0.5">{checkout.orderBump.text}</div>}
              <div className="text-[11px] text-muted-foreground mt-0.5">Adicione por apenas <span className="text-white">{formatCurrency(checkout.orderBump.price)}</span></div>
            </div>
            {checkout.orderBump.image && <img src={checkout.orderBump.image} alt="" className="h-12 w-12 rounded object-cover shrink-0" />}
            <Zap className="h-4 w-4 shrink-0" style={{ color: accent }} />
          </label>
        )}

        <LeadForm />

        {twoStep && consentRequired && (
          <label className="flex items-start gap-2 mb-4 cursor-pointer">
            <input type="checkbox" checked={consent} onChange={(e) => setConsent(e.target.checked)} className="mt-0.5 h-4 w-4" style={{ accentColor: accent }} />
            <span className="text-[11px] text-muted-foreground leading-snug">{leadCfg.consentText}</span>
          </label>
        )}

        {activeStep === "lead" ? (
          <button onClick={handleContinueToPayment} className="w-full rounded-lg py-3.5 text-sm font-bold text-white transition-all flex items-center justify-center gap-2" style={{ background: btnColor, boxShadow: `0 0 24px -6px ${btnColor}` }}>
            Continuar para pagamento <ChevronRight className="h-4 w-4" />
          </button>
        ) : (
          <>
            {checkout.coupon?.enabled && (
              <div className="flex gap-2 mb-4">
                <input value={coupon} onChange={(e) => setCoupon(e.target.value)} placeholder="Cupom de desconto" className={inputCls()} />
                <button onClick={applyCoupon} className="rounded-lg border px-4 text-xs font-medium text-white" style={{ borderColor: accent, background: couponApplied ? accent + "20" : "transparent" }}>{couponApplied ? "Aplicado ✓" : "Aplicar"}</button>
              </div>
            )}

            <div className="flex gap-1.5 mb-4">
              {checkout.methods?.includes("pix") && <MethodTab active={method === "pix"} onClick={() => setMethod("pix")} label="PIX" accent={accent} />}
              {checkout.methods?.includes("card") && <MethodTab active={method === "card"} onClick={() => setMethod("card")} label="Cartão" accent={accent} />}
              {checkout.methods?.includes("boleto") && <MethodTab active={method === "boleto"} onClick={() => setMethod("boleto")} label="Boleto" accent={accent} />}
            </div>

            {method === "pix" && (
              <div className="flex flex-col items-center py-2 animate-fade-in">
                <div className="rounded-xl bg-white p-3 mb-3">
                  <div className="grid grid-cols-8 gap-0.5 w-[140px] h-[140px]">{Array.from({ length: 64 }).map((_, i) => <div key={i} className={Math.random() > 0.5 ? "bg-black" : "bg-white"} />)}</div>
                </div>
                <p className="text-[11px] text-muted-foreground text-center">{checkout.payments?.pixDiscount ? `Pix com ${checkout.payments.pixDiscount}% de desconto! ` : ""}Escaneie o QR Code</p>
                <div className="w-full mt-2 flex items-center gap-2">
                  <input readOnly value="00020126580014BR.GOV.BCB.PIX0136sxpay-elite-marcio" className="flex-1 rounded-lg bg-white/5 border border-white/10 px-3 py-2 text-[11px] text-muted-foreground font-mono" />
                  <button onClick={() => { navigator.clipboard.writeText("00020126580014BR.GOV.BCB.PIX0136sxpay-elite-marcio"); toast({ title: "Código copiado" }); }} className="rounded-lg border border-white/10 px-3 py-2 text-[11px] text-white hover:bg-white/5">Copiar</button>
                </div>
              </div>
            )}

            {method === "card" && (
              <div className="space-y-3 animate-fade-in">
                <Field label="Número do cartão" error={errors.cardNumber}>
                  <div className="relative">
                    <input value={card.number} onChange={(e) => setCard({ ...card, number: maskCard(e.target.value) })} placeholder="0000 0000 0000 0000" className={cn(inputCls(errors.cardNumber), "pr-16 font-mono")} />
                    {brand && <span className="absolute right-3 top-1/2 -translate-y-1/2 text-[10px] font-bold text-white bg-white/10 px-1.5 py-0.5 rounded">{BRAND_LABELS[brand]}</span>}
                  </div>
                </Field>
                <Field label="Nome no cartão" error={errors.cardName}><input value={card.name} onChange={(e) => setCard({ ...card, name: e.target.value.toUpperCase() })} placeholder="COMO ESTÁ NO CARTÃO" className={inputCls(errors.cardName)} /></Field>
                <div className="grid grid-cols-2 gap-3">
                  <Field label="Validade" error={errors.expiry}><input value={card.expiry} onChange={(e) => setCard({ ...card, expiry: maskExpiry(e.target.value) })} placeholder="MM/AA" className={cn(inputCls(errors.expiry), "font-mono")} /></Field>
                  <Field label="CVV" error={errors.cvv}><input value={card.cvv} onChange={(e) => setCard({ ...card, cvv: maskCVV(e.target.value) })} placeholder="123" className={cn(inputCls(errors.cvv), "font-mono")} /></Field>
                </div>
              </div>
            )}

            {method === "boleto" && (
              <div className="py-2 animate-fade-in">
                <div className="rounded-lg bg-white/5 border border-white/10 p-3 mb-3">
                  <div className="text-[11px] text-muted-foreground mb-2">Código de barras</div>
                  <div className="font-mono text-[10px] text-white break-all leading-relaxed">34191.09008 12345.678909 87654.321000 1 98760000{String(Math.round(total * 100)).padStart(8, "0")}</div>
                </div>
                <p className="text-[11px] text-muted-foreground">O boleto vence em 3 dias. Após o pagamento, a compensação leva até 1 dia útil.</p>
              </div>
            )}

            <button onClick={handlePay} disabled={processing} className="w-full mt-5 rounded-lg py-3.5 text-sm font-bold text-white transition-all disabled:opacity-60 flex items-center justify-center gap-2" style={{ background: btnColor, boxShadow: `0 0 24px -6px ${btnColor}` }}>
              {processing ? <><Loader2 className="h-4 w-4 animate-spin" /> Processando...</> : `${checkout.buttonText || "COMPRAR AGORA"} · ${formatCurrency(total)}`}
            </button>

            <p className="text-[10px] text-muted-foreground text-center mt-3 leading-relaxed">
              Ao clicar, você concorda com os termos. Pagamento em ambiente seguro. <span className="text-muted-foreground/50">(Simulação)</span>
            </p>
          </>
        )}
      </div>
    </div>
  );

  // ---- Top bar / banner ----
  const TopBar = checkout.bannerUrl && template !== "minimalista" ? (
    <img src={checkout.bannerUrl} alt="" className="w-full h-28 object-cover" />
  ) : (
    <header className="border-b border-white/5 bg-black/60 backdrop-blur sticky top-0 z-20">
      <div className="max-w-5xl mx-auto flex items-center justify-between h-16 px-4">
        {checkout.logoUrl ? <img src={checkout.logoUrl} alt="" className="h-8 object-contain" /> : <Logo size={32} />}
        <div className="flex items-center gap-1.5 text-[11px] text-muted-foreground">
          <Lock className="h-3.5 w-3.5 text-success" /> Checkout seguro · SSL 256-bit
        </div>
      </div>
    </header>
  );

  // ---- Barra de urgência/estoque no topo (template urgência) ----
  const UrgencyTopBar = (
    <div className="max-w-5xl mx-auto px-4 pt-4 space-y-3">
      {showCounter && (
        <div className="rounded-lg border px-4 py-2.5 flex items-center justify-center gap-2 animate-pulse-red" style={{ borderColor: accent + "50", background: accent + "12" }}>
          <Clock className="h-4 w-4" style={{ color: accent }} />
          <span className="text-sm font-medium" style={{ color: accent }}>{checkout.urgencyCounter.text} <b><CountdownTimer minutes={checkout.urgencyCounter.minutes} /></b></span>
        </div>
      )}
      {showStock && (
        <div className="rounded-lg border border-white/10 bg-white/[0.02] px-4 py-3">
          <div className="flex justify-between text-[11px] text-muted-foreground mb-1.5"><span>{checkout.stockBar.text}</span><span className="text-white font-medium">{checkout.stockBar.qty} unidades</span></div>
          <div className="h-2 rounded-full bg-white/10 overflow-hidden"><div className="h-full rounded-full" style={{ width: `${Math.min(100, (checkout.stockBar.qty / 50) * 100)}%`, background: accent }} /></div>
        </div>
      )}
    </div>
  );

  // ---- Extras do topo (contador/prova social) para templates clássico e vídeo ----
  const TopExtras = (template === "classico" || template === "video") && (
    <>
      {showCounter && (
        <div className="max-w-5xl mx-auto px-4 pt-4">
          <div className="rounded-lg border px-4 py-2.5 flex items-center justify-center gap-2 animate-pulse-red" style={{ borderColor: accent + "50", background: accent + "12" }}>
            <Clock className="h-4 w-4" style={{ color: accent }} />
            <span className="text-sm font-medium" style={{ color: accent }}>{checkout.urgencyCounter.text} <b><CountdownTimer minutes={checkout.urgencyCounter.minutes} /></b></span>
          </div>
        </div>
      )}
      {showSocial && (
        <div className="max-w-5xl mx-auto px-4 pt-3">
          <div className="rounded-md bg-white/[0.03] border border-white/5 px-3 py-2 flex items-center gap-2">
            <Users className="h-3.5 w-3.5" style={{ color: accent }} />
            <span className="text-xs text-muted-foreground">{checkout.socialProof.text}</span>
          </div>
        </div>
      )}
    </>
  );

  // ---- VSL em largura total (template vídeo) ----
  const VslFull = media.type === "vsl" && (
    <div className="w-full bg-black">
      <div className="max-w-5xl mx-auto px-0 lg:px-4 lg:pt-4">
        <div className="lg:rounded-xl overflow-hidden">
          <VslBlock media={media} accent={accent} full />
        </div>
      </div>
    </div>
  );

  // ---- Layout principal por template ----
  let mainLayout;
  if (template === "minimalista") {
    mainLayout = (
      <div className="max-w-xl mx-auto px-4 py-8 lg:py-12">
        <div className="text-center mb-6">
          <h1 className="font-display font-bold text-white text-2xl lg:text-3xl tracking-tight-display leading-tight">{headline}</h1>
          {description && <p className="text-sm text-muted-foreground mt-2 leading-relaxed">{description}</p>}
        </div>
        <PaymentColumn centered />
      </div>
    );
  } else if (template === "video") {
    mainLayout = (
      <>
        {VslFull}
        <div className="max-w-5xl mx-auto px-4 py-6 lg:py-8 grid lg:grid-cols-[1fr_420px] gap-6 lg:gap-8">
          <div className="order-2 lg:order-1"><ProductColumn withMedia={false} /></div>
          <PaymentColumn />
        </div>
      </>
    );
  } else if (template === "urgencia") {
    mainLayout = (
      <>
        {UrgencyTopBar}
        <div className="max-w-5xl mx-auto px-4 py-6 lg:py-8 grid lg:grid-cols-[1fr_420px] gap-6 lg:gap-8">
          <div className="order-2 lg:order-1"><ProductColumn withMedia /></div>
          <PaymentColumn />
        </div>
      </>
    );
  } else {
    // clássico
    mainLayout = (
      <div className="max-w-5xl mx-auto px-4 py-6 lg:py-10 grid lg:grid-cols-[1fr_420px] gap-6 lg:gap-8">
        <div className="order-2 lg:order-1"><ProductColumn withMedia /></div>
        <PaymentColumn />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-black bg-circuit-red" style={{ fontFamily, color: textColor, background: bgColor }}>
      {TopBar}
      {template !== "urgencia" && TopExtras}
      {mainLayout}

      {/* CTA sticky mobile */}
      <div className="lg:hidden sticky bottom-0 z-30 border-t border-white/10 backdrop-blur px-4 py-3 flex items-center justify-between gap-3" style={{ background: bgColor + "F2" }}>
        <div className="min-w-0">
          <div className="text-[10px] text-muted-foreground truncate">{headline}</div>
          <div className="font-display font-bold text-white text-lg tabular-nums" style={{ color: accent }}>{formatCurrency(total)}</div>
        </div>
        <button onClick={activeStep === "lead" ? handleContinueToPayment : handlePay} disabled={processing} className="rounded-lg px-5 py-2.5 text-sm font-bold text-white flex items-center gap-1.5 disabled:opacity-60" style={{ background: btnColor, boxShadow: `0 0 18px -6px ${btnColor}` }}>
          {processing ? <Loader2 className="h-4 w-4 animate-spin" /> : <>{activeStep === "lead" ? "Continuar" : (checkout.buttonText || "COMPRAR")} <ChevronRight className="h-4 w-4" /></>}
        </button>
      </div>

      <footer className="border-t border-white/5 py-6 text-center">
        <p className="text-[11px] text-muted-foreground">Processado com segurança por <span className="font-bold text-white">SXPay Elite</span> · Pagamentos simulados</p>
      </footer>
    </div>
  );
}

function CountdownTimer({ minutes }) {
  const [secs, setSecs] = useState((minutes || 15) * 60);
  useEffect(() => { const t = setInterval(() => setSecs((s) => (s > 0 ? s - 1 : 0)), 1000); return () => clearInterval(t); }, [minutes]);
  const m = Math.floor(secs / 60), s = secs % 60;
  return <>{String(m).padStart(2, "0")}:{String(s).padStart(2, "0")}</>;
}

function VslBlock({ media, accent, full }) {
  const parsed = parseVideoId(media.vslUrl);
  return (
    <div className="relative bg-black">
      <div className={cn("aspect-video relative", full ? "max-h-[520px]" : "max-h-[420px]")}>
        {media.vslThumb && !parsed && <img src={media.vslThumb} alt="" className="absolute inset-0 w-full h-full object-cover opacity-50" />}
        {parsed?.provider === "youtube" ? (
          <iframe src={`https://www.youtube.com/embed/${parsed.id}?mute=1&autoplay=${media.vslAutoplay ? 1 : 0}&playsinline=1`} className="w-full h-full" allow="autoplay; encrypted-media" title="VSL" />
        ) : parsed?.provider === "vimeo" ? (
          <iframe src={`https://player.vimeo.com/video/${parsed.id}?muted=1&autoplay=${media.vslAutoplay ? 1 : 0}`} className="w-full h-full" allow="autoplay; fullscreen" title="VSL" />
        ) : media.vslUrl && media.vslProvider === "file" ? (
          <video src={media.vslUrl} controls muted={media.vslAutoplay} autoPlay={media.vslAutoplay} playsInline className="w-full h-full" poster={media.vslThumb} />
        ) : (
          <div className="absolute inset-0 flex flex-col items-center justify-center gap-2">
            <div className="h-12 w-12 rounded-full flex items-center justify-center" style={{ background: accent }}><Film className="h-5 w-5 text-white" /></div>
            <span className="text-xs text-muted-foreground">VSL · {parsed?.provider || "player externo"}</span>
          </div>
        )}
      </div>
    </div>
  );
}

const inputCls = (error) => cn("w-full rounded-lg bg-white/5 border px-3 py-2.5 text-sm text-white placeholder:text-muted-foreground/60 focus:outline-none transition-colors", error ? "border-[#E10600]" : "border-white/10 focus:border-primary/50");

function Field({ label, error, children }) {
  return (
    <div className="space-y-1">
      <label className="text-[11px] text-muted-foreground font-medium">{label}</label>
      {children}
      {error && <p className="text-[10px] text-[#FF6A4D]">{error}</p>}
    </div>
  );
}

function MethodPill({ icon: Icon, label, accent }) {
  return <div className="flex items-center gap-1.5 rounded-lg bg-white/[0.02] border border-white/5 px-2.5 py-1.5"><Icon className="h-3.5 w-3.5" style={{ color: accent }} /><span className="text-[11px] text-muted-foreground">{label}</span></div>;
}

function MethodTab({ active, onClick, label, accent }) {
  return (
    <button onClick={onClick} className={cn("flex-1 rounded-lg border py-2 text-xs font-semibold transition-all", active ? "text-white" : "border-white/10 text-muted-foreground hover:text-white")} style={active ? { borderColor: accent, background: accent + "15", color: accent } : {}}>
      {label}
    </button>
  );
}