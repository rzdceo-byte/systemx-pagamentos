import React, { useState, useEffect } from "react";
import { Wallet, Clock, TrendingUp, Percent, RotateCcw, ArrowDownToLine } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import StatusBadge from "@/components/ui/status-badge";
import { CardSkeleton } from "@/components/ui/loading-skeleton";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from "@/components/ui/dialog";
import { useApp } from "@/lib/AppContext";
import { financeCards, formatCurrency, bankData } from "@/lib/mockData";
import { useToast } from "@/components/ui/use-toast";
import { cn } from "@/lib/utils";

const ICONS = { wallet: Wallet, clock: Clock, "trending-up": TrendingUp, percent: Percent, "rotate-ccw": RotateCcw };

export default function Finance() {
  const { withdrawals, requestWithdrawal } = useApp();
  const { toast } = useToast();
  const [loading, setLoading] = useState(true);
  const [withdrawOpen, setWithdrawOpen] = useState(false);
  const [amount, setAmount] = useState("");
  const [method, setMethod] = useState("PIX");

  useEffect(() => {
    const t = setTimeout(() => setLoading(false), 500);
    return () => clearTimeout(t);
  }, []);

  const submitWithdraw = () => {
    const val = parseFloat(amount.replace(",", "."));
    if (!val || val <= 0) { toast({ title: "Valor inválido", variant: "destructive" }); return; }
    if (val > 24850) { toast({ title: "Saldo insuficiente", variant: "destructive" }); return; }
    requestWithdrawal(val, method);
    toast({ title: "Saque solicitado", description: `${formatCurrency(val)} via ${method} está em processamento.` });
    setAmount(""); setWithdrawOpen(false);
  };

  return (
    <div className="space-y-5 max-w-[1400px] mx-auto">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <span className="text-[10px] uppercase tracking-[0.2em] text-primary font-semibold">Financeiro</span>
          <h2 className="font-display font-bold text-white text-2xl tracking-tight-display">Gestão de saldo</h2>
        </div>
        <Button onClick={() => setWithdrawOpen(true)} className="bg-primary hover:bg-[#E10600] glow-red-sm gap-2">
          <ArrowDownToLine className="h-4 w-4" /> Solicitar saque
        </Button>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
        {financeCards.map((c, i) => {
          const Icon = ICONS[c.icon] || Wallet;
          return loading ? <CardSkeleton key={c.id} /> : (
            <div key={c.id} className={cn("rounded-xl surface p-4 glow-soft transition-all hover:-translate-y-0.5", i === 0 && "glow-red-sm")}>
              <div className="flex items-center gap-2 mb-3">
                <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-black/40 border border-white/5"><Icon className="h-4 w-4 text-primary" /></div>
                <span className="text-[10px] uppercase tracking-[0.12em] text-muted-foreground">{c.label}</span>
              </div>
              <div className="font-display font-bold text-white text-lg tracking-tight-display tabular-nums">{formatCurrency(c.value)}</div>
            </div>
          );
        })}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Withdrawals history */}
        <div className="lg:col-span-2 rounded-xl surface glow-soft overflow-hidden">
          <div className="px-5 py-4 border-b border-white/5">
            <h3 className="font-display font-semibold text-white text-sm">Histórico de saques</h3>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-white/5">
                  {["Data", "Método", "Valor", "Status"].map((h) => (
                    <th key={h} className="text-left text-[10px] uppercase tracking-[0.12em] text-muted-foreground font-semibold py-3 px-5">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {withdrawals.map((w) => (
                  <tr key={w.id} className="border-b border-white/[0.03]">
                    <td className="py-3 px-5 text-sm text-muted-foreground">{w.date}</td>
                    <td className="py-3 px-5 text-sm">{w.method}</td>
                    <td className="py-3 px-5 text-sm font-medium tabular-nums">{formatCurrency(w.value)}</td>
                    <td className="py-3 px-5"><StatusBadge status={w.status} /></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Bank data */}
        <div className="rounded-xl surface glow-soft p-5">
          <h3 className="font-display font-semibold text-white text-sm mb-4">Conta bancária</h3>
          <div className="space-y-3">
            {[
              { label: "Banco", value: bankData.bank },
              { label: "Agência", value: bankData.agency },
              { label: "Conta", value: `${bankData.account} · ${bankData.type}` },
              { label: "Titular", value: bankData.holder },
              { label: "CNPJ", value: bankData.document }
            ].map((r) => (
              <div key={r.label} className="flex items-center justify-between border-b border-white/5 pb-2.5">
                <span className="text-xs text-muted-foreground">{r.label}</span>
                <span className="text-sm text-white text-right">{r.value}</span>
              </div>
            ))}
          </div>
          <button className="mt-4 w-full rounded-lg border border-white/10 py-2 text-xs text-muted-foreground hover:text-white hover:bg-white/5 transition-colors">Editar dados bancários</button>
        </div>
      </div>

      {/* Withdraw modal */}
      <Dialog open={withdrawOpen} onOpenChange={setWithdrawOpen}>
        <DialogContent className="bg-popover border-white/10 max-w-md">
          <DialogHeader>
            <DialogTitle className="text-white">Solicitar saque</DialogTitle>
            <DialogDescription className="text-muted-foreground">O valor será transferido para sua conta cadastrada. Processamento simulado.</DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-2">
            <div className="rounded-lg bg-primary/5 border border-primary/20 p-3">
              <div className="text-[10px] uppercase tracking-[0.12em] text-primary">Saldo disponível</div>
              <div className="font-display font-bold text-white text-xl tabular-nums">{formatCurrency(24850)}</div>
            </div>
            <div className="space-y-1.5">
              <Label className="text-muted-foreground text-xs">Valor do saque (R$)</Label>
              <Input value={amount} onChange={(e) => setAmount(e.target.value)} placeholder="0,00" className="bg-background border-white/10" />
            </div>
            <div className="space-y-1.5">
              <Label className="text-muted-foreground text-xs">Método</Label>
              <div className="flex gap-2">
                {["PIX", "TED"].map((m) => (
                  <button key={m} onClick={() => setMethod(m)} className={cn("flex-1 rounded-md border py-1.5 text-xs font-medium transition-colors", method === m ? "border-primary/50 bg-primary/10 text-primary" : "border-white/10 text-muted-foreground hover:text-white")}>{m}</button>
                ))}
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="ghost" onClick={() => setWithdrawOpen(false)}>Cancelar</Button>
            <Button onClick={submitWithdraw} className="bg-primary hover:bg-[#E10600]">Confirmar saque</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}