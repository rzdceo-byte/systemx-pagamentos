import React, { useState, useMemo } from "react";
import { useApp } from "@/lib/AppContext";
import { formatCurrency } from "@/lib/mockData";
import { botFunnel, botMessageStats, botRevenueSeries } from "@/lib/mockData";
import { FunnelChart, Funnel, LabelList, Tooltip, ResponsiveContainer, AreaChart, Area, XAxis, YAxis, CartesianGrid, BarChart, Bar } from "recharts";
import { Users, MousePointerClick, DollarSign, Percent } from "lucide-react";

export default function BotReports() {
  const { bots, flows } = useApp();
  const [botId, setBotId] = useState(bots[0]?.id || "");
  const bot = bots.find((b) => b.id === botId) || bots[0];
  const flow = flows.find((f) => f.id === bot?.flowId);

  const totalFunnel = useMemo(() => botFunnel.reduce((s, x) => s + x.valor, 0), []);
  const kpis = [
    { label: "Contatos no fluxo", value: bot?.subscribers?.toLocaleString("pt-BR") || 0, icon: Users, color: "text-primary" },
    { label: "Cliques em ofertas", value: (bot?.subscribers ? Math.round(bot.subscribers * 0.62) : 0).toLocaleString("pt-BR"), icon: MousePointerClick, color: "text-warning" },
    { label: "Faturamento gerado", value: formatCurrency(bot?.revenue || 0), icon: DollarSign, color: "text-success" },
    { label: "Conversão", value: `${bot?.conversion || 0}%`, icon: Percent, color: "text-primary" }
  ];

  return (
    <div className="p-4 lg:p-8 max-w-[1400px] mx-auto">
      <div className="flex flex-wrap items-center justify-between gap-3 mb-6">
        <div>
          <h1 className="text-2xl font-heading font-bold text-white">Relatórios do Bot</h1>
          <p className="text-sm text-muted-foreground mt-1">Métricas por bot e por fluxo — funil, aberturas e faturamento.</p>
        </div>
        <select value={botId} onChange={(e) => setBotId(e.target.value)} className="h-9 rounded-md border border-input bg-transparent px-3 text-sm min-w-[200px]">
          {bots.map((b) => <option key={b.id} value={b.id}>{b.name}</option>)}
        </select>
      </div>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4 mb-6">
        {kpis.map((k) => (
          <div key={k.label} className="rounded-xl surface p-4 glow-soft">
            <div className="flex items-center gap-2 text-muted-foreground"><k.icon className={`h-4 w-4 ${k.color}`} /><span className="text-[10px] uppercase tracking-[0.12em]">{k.label}</span></div>
            <p className="text-2xl font-heading font-bold text-white mt-2">{k.value}</p>
          </div>
        ))}
      </div>

      <div className="grid gap-6 lg:grid-cols-2 mb-6">
        <div className="rounded-xl surface p-5">
          <h3 className="text-sm font-semibold text-white mb-1">Funil de conversão</h3>
          <p className="text-[11px] text-muted-foreground mb-4">Fluxo: {flow?.name || "—"} · onde as pessoas abandonam</p>
          <div className="h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              <FunnelChart layout="horizontal">
                <Tooltip contentStyle={{ background: "#0D0D0D", border: "1px solid rgba(193,0,0,0.4)", borderRadius: 8, fontSize: 12 }} />
                <Funnel dataKey="valor" nameKey="etapa" data={botFunnel.map((d) => ({ ...d, fill: d.cor }))} isAnimationActive>
                  <LabelList dataKey="etapa" position="left" fill="#fff" fontSize={11} />
                  <LabelList dataKey="valor" position="right" fill="#9ca3af" fontSize={11} formatter={(v) => `${Math.round((v / totalFunnel) * 100)}%`} />
                </Funnel>
              </FunnelChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="rounded-xl surface p-5">
          <h3 className="text-sm font-semibold text-white mb-1">Faturamento (14 dias)</h3>
          <p className="text-[11px] text-muted-foreground mb-4">Receita gerada por este bot</p>
          <div className="h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={botRevenueSeries}>
                <defs><linearGradient id="revHot" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor="#C10000" stopOpacity={0.5} /><stop offset="100%" stopColor="#C10000" stopOpacity={0} /></linearGradient></defs>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.04)" />
                <XAxis dataKey="day" tick={{ fill: "#71717a", fontSize: 10 }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fill: "#71717a", fontSize: 10 }} axisLine={false} tickLine={false} tickFormatter={(v) => `${v}`} />
                <Tooltip contentStyle={{ background: "#0D0D0D", border: "1px solid rgba(193,0,0,0.4)", borderRadius: 8, fontSize: 12 }} formatter={(v) => formatCurrency(v)} />
                <Area type="monotone" dataKey="faturamento" stroke="#C10000" strokeWidth={2} fill="url(#revHot)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      <div className="rounded-xl surface p-5 mb-6">
        <h3 className="text-sm font-semibold text-white mb-1">Taxa de abertura e clique por mensagem</h3>
        <p className="text-[11px] text-muted-foreground mb-4">Desempenho de cada bloco de conteúdo do fluxo</p>
        <div className="h-[260px]">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={botMessageStats} layout="vertical">
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.04)" horizontal={false} />
              <XAxis type="number" tick={{ fill: "#71717a", fontSize: 10 }} axisLine={false} tickLine={false} />
              <YAxis type="category" dataKey="message" tick={{ fill: "#a1a1aa", fontSize: 11 }} axisLine={false} tickLine={false} width={120} />
              <Tooltip contentStyle={{ background: "#0D0D0D", border: "1px solid rgba(193,0,0,0.4)", borderRadius: 8, fontSize: 12 }} />
              <Bar dataKey="opens" name="Aberturas" fill="#8A0303" radius={[0, 4, 4, 0]} />
              <Bar dataKey="clicks" name="Cliques" fill="#C10000" radius={[0, 4, 4, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {flows.length > 1 && (
        <div className="rounded-xl surface p-5">
          <h3 className="text-sm font-semibold text-white mb-1">Comparação de fluxos (A/B)</h3>
          <p className="text-[11px] text-muted-foreground mb-4">Comparativo entre fluxos vinculados aos bots</p>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="text-[11px] uppercase tracking-wide text-muted-foreground">
                <tr className="border-b border-white/5"><th className="text-left font-medium px-4 py-2.5">Fluxo</th><th className="text-left font-medium px-4 py-2.5">Status</th><th className="text-right font-medium px-4 py-2.5">Bots vinculados</th><th className="text-right font-medium px-4 py-2.5">Faturamento</th><th className="text-right font-medium px-4 py-2.5">Conversão</th></tr>
              </thead>
              <tbody>
                {flows.map((f) => {
                  const linkedBots = bots.filter((b) => b.flowId === f.id);
                  const rev = linkedBots.reduce((s, b) => s + (b.revenue || 0), 0);
                  const conv = linkedBots.length ? (linkedBots.reduce((s, b) => s + (b.conversion || 0), 0) / linkedBots.length).toFixed(1) : 0;
                  return (
                    <tr key={f.id} className="border-b border-white/[0.03] hover:bg-white/[0.02]">
                      <td className="px-4 py-2.5 text-[12px] text-white">{f.name}</td>
                      <td className="px-4 py-2.5 text-[12px] text-muted-foreground capitalize">{f.status}</td>
                      <td className="px-4 py-2.5 text-[12px] text-muted-foreground text-right">{linkedBots.length}</td>
                      <td className="px-4 py-2.5 text-[12px] text-white text-right tabular-nums">{formatCurrency(rev)}</td>
                      <td className="px-4 py-2.5 text-[12px] text-white text-right">{conv}%</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}