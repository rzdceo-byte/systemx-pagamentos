import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useApp } from "@/lib/AppContext";
import { useToast } from "@/components/ui/use-toast";
import BotCard from "@/components/bots/BotCard";
import BotEditorDialog from "@/components/bots/BotEditorDialog";
import { Button } from "@/components/ui/button";
import { Plus, Bot as BotIcon } from "lucide-react";

export default function Bots() {
  const { bots, flows, hotWallets, addBot, updateBot, deleteBot } = useApp();
  const { toast } = useToast();
  const navigate = useNavigate();
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editing, setEditing] = useState(null);

  const openCreate = () => { setEditing(null); setDialogOpen(true); };
  const openEdit = (bot) => { setEditing(bot); setDialogOpen(true); };

  const save = (form) => {
    if (editing) {
      updateBot(editing.id, form);
      toast({ title: "Bot atualizado" });
    } else {
      addBot(form);
      toast({ title: "Bot criado com sucesso" });
    }
    setDialogOpen(false);
  };

  const remove = (bot) => {
    deleteBot(bot.id);
    toast({ title: "Bot removido" });
  };

  const toggle = (bot) => {
    updateBot(bot.id, { status: bot.status === "ativo" ? "pausado" : "ativo" });
  };

  return (
    <div className="p-4 lg:p-8 max-w-[1400px] mx-auto">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-heading font-bold text-white">Bots & Fluxos</h1>
          <p className="text-sm text-muted-foreground mt-1">Crie bots de Telegram com identidade própria e automação completa de vendas.</p>
        </div>
        <Button onClick={openCreate} className="glow-red-sm"><Plus className="h-4 w-4" /> Criar novo bot</Button>
      </div>

      {bots.length === 0 ? (
        <div className="rounded-xl surface p-12 text-center">
          <BotIcon className="h-10 w-10 text-muted-foreground mx-auto mb-3" />
          <p className="text-sm text-muted-foreground">Nenhum bot criado ainda. Crie seu primeiro bot de Telegram.</p>
        </div>
      ) : (
        <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
          {bots.map((bot) => (
            <BotCard
              key={bot.id}
              bot={bot}
              flow={flows.find((f) => f.id === bot.flowId)}
              wallet={hotWallets.find((w) => w.id === bot.walletId)}
              onEdit={() => openEdit(bot)}
              onDelete={() => remove(bot)}
              onToggle={() => toggle(bot)}
              onOpenFlow={() => navigate(`/bots/fluxos?flow=${bot.flowId || ""}`)}
            />
          ))}
        </div>
      )}

      <BotEditorDialog open={dialogOpen} onClose={() => setDialogOpen(false)} onSave={save} bot={editing} flows={flows} wallets={hotWallets} />
    </div>
  );
}