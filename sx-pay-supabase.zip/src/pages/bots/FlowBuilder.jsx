import React, { useState, useEffect, useMemo } from "react";
import { useSearchParams } from "react-router-dom";
import { useApp } from "@/lib/AppContext";
import { useToast } from "@/components/ui/use-toast";
import { createNode, NODE_TYPES } from "@/lib/flowNodes";
import FlowCanvas from "@/components/flow/FlowCanvas";
import NodePalette from "@/components/flow/NodePalette";
import NodeEditorPanel from "@/components/flow/NodeEditorPanel";
import FlowTester from "@/components/flow/FlowTester";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Play, Save, UploadCloud, Plus, LayoutGrid } from "lucide-react";

export default function FlowBuilder() {
  const { flows, updateFlow, addFlow, deleteFlow } = useApp();
  const { toast } = useToast();
  const [params, setParams] = useSearchParams();
  const initialId = params.get("flow") || flows[0]?.id || "";
  const [selectedFlowId, setSelectedFlowId] = useState(initialId);
  const flow = flows.find((f) => f.id === selectedFlowId) || flows[0];

  const [nodes, setNodes] = useState([]);
  const [edges, setEdges] = useState([]);
  const [selectedId, setSelectedId] = useState(null);
  const [testerOpen, setTesterOpen] = useState(false);
  const [newName, setNewName] = useState("");

  useEffect(() => {
    setNodes(flow?.nodes ? JSON.parse(JSON.stringify(flow.nodes)) : []);
    setEdges(flow?.edges ? JSON.parse(JSON.stringify(flow.edges)) : []);
    setSelectedId(null);
  }, [selectedFlowId, flow?.id]);

  const selectedNode = useMemo(() => nodes.find((n) => n.id === selectedId), [nodes, selectedId]);

  const addNode = (type, x, y) => {
    const offset = nodes.length * 30;
    const node = createNode(type, x ?? 80 + offset, y ?? 120 + offset);
    if (!node) return;
    setNodes((prev) => [...prev, node]);
    setSelectedId(node.id);
  };

  const moveNode = (id, x, y) => setNodes((prev) => prev.map((n) => (n.id === id ? { ...n, x: Math.round(x), y: Math.round(y) } : n)));
  const connect = (from, fromPort, to) => {
    setEdges((prev) => {
      if (prev.some((e) => e.from === from && e.fromPort === fromPort && e.to === to)) return prev;
      return [...prev, { id: `e-${Date.now()}-${Math.floor(Math.random() * 999)}`, from, fromPort, to }];
    });
  };
  const deleteEdge = (id) => setEdges((prev) => prev.filter((e) => e.id !== id));
  const updateNodeData = (data) => setNodes((prev) => prev.map((n) => (n.id === selectedId ? { ...n, data } : n)));
  const deleteNode = () => {
    setNodes((prev) => prev.filter((n) => n.id !== selectedId));
    setEdges((prev) => prev.filter((e) => e.from !== selectedId && e.to !== selectedId));
    setSelectedId(null);
  };

  const autoLayout = () => {
    const start = nodes.find((n) => !edges.some((e) => e.to === n.id)) || nodes[0];
    if (!start) return;
    const visited = new Set();
    const levels = {};
    const queue = [{ id: start.id, level: 0 }];
    while (queue.length) {
      const { id, level } = queue.shift();
      if (visited.has(id)) continue;
      visited.add(id);
      levels[id] = Math.max(levels[id] || 0, level);
      edges.filter((e) => e.from === id).forEach((e) => queue.push({ id: e.to, level: level + 1 }));
    }
    const byLevel = {};
    nodes.forEach((n) => { const l = levels[n.id] ?? 0; (byLevel[l] = byLevel[l] || []).push(n); });
    setNodes((prev) => prev.map((n) => {
      const l = levels[n.id] ?? 0;
      const idx = byLevel[l].indexOf(n);
      return { ...n, x: 60 + l * 280, y: 80 + idx * 170 };
    }));
    toast({ title: "Canvas organizado" });
  };

  const save = (status) => {
    if (!flow) return;
    updateFlow(flow.id, { nodes, edges, status });
    toast({ title: status === "publicado" ? "Fluxo publicado" : "Rascunho salvo" });
  };

  const createFlow = () => {
    if (!newName.trim()) return;
    const startNode = createNode("start", 60, 120);
    const f = addFlow({ name: newName.trim(), nodes: [startNode], edges: [] });
    setNewName("");
    setSelectedFlowId(f.id);
    setParams({ flow: f.id });
    toast({ title: "Fluxo criado" });
  };

  if (!flow) {
    return (
      <div className="p-8 max-w-[1400px] mx-auto">
        <h1 className="text-2xl font-heading font-bold text-white mb-6">Construtor de Fluxos</h1>
        <div className="rounded-xl surface p-8 text-center">
          <p className="text-sm text-muted-foreground mb-4">Crie seu primeiro fluxo para começar.</p>
          <div className="flex gap-2 max-w-sm mx-auto">
            <Input value={newName} onChange={(e) => setNewName(e.target.value)} placeholder="Nome do fluxo" />
            <Button onClick={createFlow}><Plus className="h-4 w-4" /> Criar</Button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-[calc(100vh-64px)]">
      <div className="flex items-center gap-3 px-4 py-3 border-b border-white/5 bg-[#070707]">
        <select value={selectedFlowId} onChange={(e) => { setSelectedFlowId(e.target.value); setParams({ flow: e.target.value }); }} className="h-9 rounded-md border border-input bg-transparent px-3 text-sm min-w-[200px]">
          {flows.map((f) => <option key={f.id} value={f.id}>{f.name} ({f.status})</option>)}
        </select>
        <Input value={newName} onChange={(e) => setNewName(e.target.value)} placeholder="Novo fluxo…" className="max-w-[180px]" />
        <Button variant="outline" size="sm" onClick={createFlow}><Plus className="h-3.5 w-3.5" /> Novo</Button>
        <div className="flex-1" />
        <span className="text-[11px] text-muted-foreground hidden md:block">{nodes.length} nós · {edges.length} conexões</span>
        <Button variant="outline" size="sm" onClick={autoLayout}><LayoutGrid className="h-3.5 w-3.5" /> Organizar</Button>
        <Button variant="outline" size="sm" onClick={() => setTesterOpen(true)}><Play className="h-3.5 w-3.5" /> Testar</Button>
        <Button variant="outline" size="sm" onClick={() => save("rascunho")}><Save className="h-3.5 w-3.5" /> Salvar</Button>
        <Button size="sm" onClick={() => save("publicado")} className="glow-red-sm"><UploadCloud className="h-3.5 w-3.5" /> Publicar</Button>
      </div>

      <div className="flex flex-1 min-h-0">
        <NodePalette onAdd={addNode} />
        <FlowCanvas nodes={nodes} edges={edges} selectedId={selectedId} onSelect={setSelectedId} onMoveNode={moveNode} onConnect={connect} onDeleteEdge={deleteEdge} onAddNode={addNode} />
        <NodeEditorPanel node={selectedNode} onUpdate={updateNodeData} onDelete={deleteNode} />
      </div>

      <FlowTester open={testerOpen} onClose={() => setTesterOpen(false)} flow={{ ...flow, nodes, edges }} />
    </div>
  );
}