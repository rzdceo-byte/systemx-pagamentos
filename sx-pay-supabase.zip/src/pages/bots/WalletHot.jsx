import React, { useState, useMemo } from "react";
import { useApp } from "@/lib/AppContext";
import { useToast } from "@/components/ui/use-toast";
import { formatCurrency } from "@/lib/mockData";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import StatusBadge from "@/components/ui/status-badge";
import { Wallet, ArrowDownToLine, Clock, ShieldAlert } from "lucide-react";

export default function WalletHot() {
  const { hotWallets, hotTransactions, hotWithdrawals, requestHotWithdrawal, bots } = useApp();
  const { toast } = useToast();
  const [walletId, setWalletId] = useState(hotWallets[0]?.id || "");
  const [filterBot, setFilterBot] = useState("");
  const [wdOpen, setWdOpen] = useState(false);
  const [wdAmount, setWdAmount] = useState("");

  const wallet = hotWallets.find((w) => w.id === walletId) || hotWallets[0];

  const walletTx = useMemo(() => hotTransactions.filter((t) => (!wallet || t.walletId === wallet.id) && (!filterBot || t.botId === filterBot)), [hotTransactions, wallet, filterBot]);
  const walletWd = useMemo(() => hotWithdrawals.filter((w) => !wallet || w.walletId === wallet.id), [hotWithdrawals, wallet]);

  const submitWd = () => {
    const v = Number(wdAmount);
    if (!v || v <= 0) { toast({ title: "Informe um valor válido", variant: "destructive" }); return; }
    if (wallet && v > wallet.balance) { toast({ title: "Saldo insuficiente na Wallet Hot", variant: "destructive" }); return; }
    requestHotWithdrawal(wallet.id, v, "PIX");
    setWdOpen(false);
    setWdAmount("");
    toast({ title: "Saque solicitado", description: `${formatCurrency(v)} via PIX — processando.` });
  };

  return (
    <div className="p-4 lg:p-8 max-w-[1400px] mx-auto">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-heading font-bold text-white">Wallet Hot</h1>
          <p className="text-sm text-muted-foreground mt-1">Carteira dedicada para recebimentos dos bots — separada do saldo geral.</p>
        </div>
        <Button onClick={() => setWdOpen(true)} disabled={!wallet} className="glow-red-sm"><ArrowDownToLine className="h-4 w-4" /> Solicitar saque</Button>
      </div>

      <div className="flex flex-wrap items-center gap-3 mb-6">
        <select value={walletId} onChange={(e) => setWalletId(e.target.value)} className="h-9 rounded-md border border-input bg-transparent px-3 text-sm">
          {hotWallets.map((w) => <option key={w.id} value={w.id}>{w.name}</option>)}
        </select>
        <select value={filterBot} onChange={(e) => setFilterBot(e.target.value)} className="h-9 rounded-md border border-input bg-transparent px-3 text-sm">
          <option value="">Todos os bots</option>
          {bots.map((b) => <option key={b.id} value={b.id}>{b.name}</option>)}
        </select>
      </div>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3 mb-6">
        <div className="rounded-xl surface p-5 glow-soft">
          <div className="flex items-center gap-2 text-muted-foreground"><Wallet className="h-4 w-4 text-primary" /><span className="text-[11px] uppercase tracking-[0.12em]">Saldo disponível</span></div>
          <p className="text-3xl font-heading font-bold text-white mt-2">{formatCurrency(wallet?.balance || 0)}</p>
          <p className="text-[11px] text-muted-foreground mt-1">{(wallet?.botIds || []).length} bot(s) vinculados</p>
        </div>
        <div className="rounded-xl surface p-5">
          <div className="flex items-center gap-2 text-muted-foreground"><Clock className="h-4 w-4 text-warning" /><span className="text-[11px] uppercase tracking-[0.12em]">Saldo pendente</span></div>
          <p className="text-3xl font-heading font-bold text-white mt-2">{formatCurrency(wallet?.pending || 0)}</p>
          <p className="text-[11px] text-muted-foreground mt-1">Liberação em D+1 a D+2</p>
        </div>
        <div className="rounded-xl surface p-5">
          <div className="flex items-center gap-2 text-muted-foreground"><ShieldAlert className="h-4 w-4 text-warning" /><span className="text-[11px] uppercase tracking-[0.12em]">Reserva de risco</span></div>
          <p className="text-3xl font-heading font-bold text-white mt-2">{wallet?.reserveRate || 0}%</p>
          <p className="text-[11px] text-muted-foreground mt-1">Retenção sobre saques (proteção chargeback)</p>
        </div>
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        <div className="lg:col-span-2 rounded-xl surface overflow-hidden">
          <div className="px-4 py-3 border-b border-white/5 flex items-center justify-between">
            <h3 className="text-sm font-semibold text-white">Extrato de transações</h3>
            <span className="text-[11px] text-muted-foreground">{walletTx.length} registros</span>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="text-[11px] uppercase tracking-wide text-muted-foreground">
                <tr className="border-b border-white/5"><th className="text-left font-medium px-4 py-2.5">Data</th><th className="text-left font-medium px-4 py-2.5">Cliente</th><th className="text-left font-medium px-4 py-2.5">Bot</th><th className="text-left font-medium px-4 py-2.5">Método</th><th className="text-right font-medium px-4 py-2.5">Valor</th><th className="text-left font-medium px-4 py-2.5">Status</th></tr>
              </thead>
              <tbody>
                {walletTx.map((t) => (
                  <tr key={t.id} className="border-b border-white/[0.03] hover:bg-white/[0.02]">
                    <td className="px-4 py-2.5 text-[12px] text-muted-foreground whitespace-nowrap">{t.date}</td>
                    <td className="px-4 py-2.5 text-[12px] text-white">{t.customer}</td>
                    <td className="px-4 py-2.5 text-[12px] text-muted-foreground">{bots.find((b) => b.id === t.botId)?.name || "—"}</td>
                    <td className="px-4 py-2.5 text-[12px] text-muted-foreground">{t.method}</td>
                    <td className="px-4 py-2.5 text-[12px] text-white text-right tabular-nums">{formatCurrency(t.value)}</td>
                    <td className="px-4 py-2.5"><StatusBadge status={t.status} /></td>
                  </tr>
                ))}
                {walletTx.length === 0 && <tr><td colSpan={6} className="px-4 py-8 text-center text-muted-foreground text-sm">Nenhuma transação.</td></tr>}
              </tbody>
            </table>
          </div>
        </div>

        <div className="rounded-xl surface overflow-hidden">
          <div className="px-4 py-3 border-b border-white/5"><h3 className="text-sm font-semibold text-white">Histórico de saques</h3></div>
          <div className="p-3 space-y-2">
            {walletWd.map((w) => (
              <div key={w.id} className="rounded-lg bg-white/[0.02] border border-white/5 p-3">
                <div className="flex items-center justify-between">
                  <span className="text-[12px] text-white font-medium">{formatCurrency(w.value)}</span>
                  <StatusBadge status={w.status} />
                </div>
                <p className="text-[11px] text-muted-foreground mt-1">{w.date} · {w.method}</p>
              </div>
            ))}
            {walletWd.length === 0 && <p className="text-center text-muted-foreground text-sm py-6">Sem saques.</p>}
          </div>
        </div>
      </div>

      <Dialog open={wdOpen} onOpenChange={setWdOpen}>
        <DialogContent className="max-w-sm bg-[#0D0D0D] border-white/10">
          <DialogHeader><DialogTitle>Solicitar saque — {wallet?.name}</DialogTitle></DialogHeader>
          <div className="space-y-3">
            <div className="text-[12px] text-muted-foreground">Saldo disponível: <span className="text-white font-semibold">{formatCurrency(wallet?.balance || 0)}</span></div>
            <div className="space-y-1.5">
              <Label className="text-[11px] uppercase tracking-[0.1em] text-muted-foreground">Valor</Label>
              <Input type="number" value={wdAmount} onChange={(e) => setWdAmount(e.target.value)} placeholder="0,00" />
            </div>
            <div className="rounded-lg border border-warning/30 bg-warning/5 p-3 text-[11px] text-white/80 leading-relaxed">
              Reserva de risco de {wallet?.reserveRate || 0}% retida nos primeiros saques (prática comum para o nicho hot devido ao risco de chargeback). Liberação via PIX em até 1 dia útil.
            </div>
          </div>
          <DialogFooter><Button variant="outline" size="sm" onClick={() => setWdOpen(false)}>Cancelar</Button><Button size="sm" onClick={submitWd}>Confirmar saque</Button></DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}