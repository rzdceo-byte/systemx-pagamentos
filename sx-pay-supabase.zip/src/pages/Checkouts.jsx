import React, { useState, useEffect } from "react";
import { Plus, CreditCard, ExternalLink, Copy, Check, Eye, Power } from "lucide-react";
import { Button } from "@/components/ui/button";
import StatusBadge from "@/components/ui/status-badge";
import EmptyState from "@/components/ui/empty-state";
import { CardSkeleton } from "@/components/ui/loading-skeleton";
import { useApp } from "@/lib/AppContext";
import { formatCurrency } from "@/lib/mockData";
import { useToast } from "@/components/ui/use-toast";
import { Link } from "react-router-dom";
import { cn } from "@/lib/utils";
import CheckoutEditor from "@/components/checkout/CheckoutEditor";

export default function Checkouts() {
  const { checkouts, products, addCheckout, updateCheckout, deleteCheckout } = useApp();
  const { toast } = useToast();
  const [loading, setLoading] = useState(true);
  const [editing, setEditing] = useState(null);
  const [copiedId, setCopiedId] = useState(null);

  useEffect(() => {
    const t = setTimeout(() => setLoading(false), 500);
    return () => clearTimeout(t);
  }, []);

  const openNew = () => {
    const product = products[0];
    if (!product) { toast({ title: "Crie um produto primeiro", variant: "destructive" }); return; }
    setEditing({
      isNew: true,
      name: `Checkout ${product.name}`,
      productId: product.id,
      productName: product.name,
      productImage: product.image,
      price: product.promoPrice || product.price,
      accentColor: "#C10000",
      headline: product.name,
      description: product.shortDescription || "Acesso imediato após a confirmação do pagamento.",
      hasOrderBump: false, hasUpsell: false,
      methods: ["pix", "card", "boleto"], published: false
    });
  };

  const saveCheckout = (data) => {
    if (data.isNew) { addCheckout(data); toast({ title: "Checkout criado" }); }
    else { updateCheckout(data.id, data); toast({ title: data.published ? "Checkout publicado" : "Checkout salvo" }); }
    setEditing(null);
  };

  const copyLink = (id) => {
    navigator.clipboard.writeText(`${window.location.origin}/c/${id}`);
    setCopiedId(id);
    toast({ title: "Link copiado" });
    setTimeout(() => setCopiedId(null), 2000);
  };

  return (
    <div className="space-y-5 max-w-[1400px] mx-auto">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <span className="text-[10px] uppercase tracking-[0.2em] text-primary font-semibold">Builder</span>
          <h2 className="font-display font-bold text-white text-2xl tracking-tight-display">Checkouts</h2>
        </div>
        <Button onClick={openNew} className="bg-primary hover:bg-[#E10600] glow-red-sm gap-2">
          <Plus className="h-4 w-4" /> Criar novo checkout
        </Button>
      </div>

      {loading ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">{Array.from({ length: 4 }).map((_, i) => <CardSkeleton key={i} />)}</div>
      ) : checkouts.length === 0 ? (
        <div className="rounded-xl surface glow-soft"><EmptyState icon={CreditCard} title="Nenhum checkout" description="Crie seu primeiro checkout e publique em segundos." action={<Button onClick={openNew} className="bg-primary hover:bg-[#E10600] gap-2"><Plus className="h-4 w-4" /> Criar checkout</Button>} /></div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          {checkouts.map((c) => (
            <div key={c.id} className="rounded-xl surface glow-soft overflow-hidden transition-all hover:-translate-y-0.5">
              <div className="flex items-center justify-between px-5 py-4 border-b border-white/5">
                <div className="flex items-center gap-2.5 min-w-0">
                  <div className="h-2.5 w-2.5 rounded-full shrink-0" style={{ background: c.accentColor, boxShadow: `0 0 8px ${c.accentColor}` }} />
                  <h3 className="font-medium text-white text-sm truncate">{c.name}</h3>
                </div>
                <StatusBadge status={c.published ? "ativo" : "rascunho"} />
              </div>
              <div className="px-5 py-4">
                <div className="grid grid-cols-4 gap-2 mb-4">
                  {[
                    { label: "Visitas", value: c.visits || 0 },
                    { label: "Início", value: c.started || 0 },
                    { label: "Aprovado", value: c.approved || 0 },
                    { label: "Conv.", value: c.visits ? `${Math.round((c.approved / c.visits) * 100)}%` : "—" }
                  ].map((m) => (
                    <div key={m.label} className="text-center">
                      <div className="text-sm text-white font-semibold tabular-nums">{typeof m.value === "number" ? m.value.toLocaleString("pt-BR") : m.value}</div>
                      <div className="text-[10px] text-muted-foreground">{m.label}</div>
                    </div>
                  ))}
                </div>
                <div className="flex flex-wrap items-center gap-1.5">
                  <button onClick={() => setEditing({ ...c })} className="flex-1 min-w-[80px] flex items-center justify-center gap-1.5 rounded-md bg-white/5 hover:bg-white/10 py-1.5 text-xs text-white transition-colors"><Eye className="h-3.5 w-3.5" /> Editar</button>
                  <Link to={`/c/${c.id}`} className="flex h-8 w-8 items-center justify-center rounded-md bg-white/5 hover:bg-white/10 text-muted-foreground hover:text-white transition-colors"><ExternalLink className="h-3.5 w-3.5" /></Link>
                  <button onClick={() => copyLink(c.id)} className="flex h-8 w-8 items-center justify-center rounded-md bg-white/5 hover:bg-white/10 text-muted-foreground hover:text-white transition-colors">{copiedId === c.id ? <Check className="h-3.5 w-3.5 text-success" /> : <Copy className="h-3.5 w-3.5" />}</button>
                  <button onClick={() => { updateCheckout(c.id, { published: !c.published }); toast({ title: c.published ? "Checkout despublicado" : "Checkout publicado" }); }} className={cn("flex h-8 w-8 items-center justify-center rounded-md transition-colors", c.published ? "bg-primary/15 text-primary hover:bg-primary/25" : "bg-white/5 text-muted-foreground hover:text-white")}><Power className="h-3.5 w-3.5" /></button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {editing && <CheckoutEditor data={editing} products={products} onClose={() => setEditing(null)} onSave={saveCheckout} />}
    </div>
  );
}