import React, { useState, useEffect } from "react";
import {
  AreaChart, Area, BarChart, Bar, LineChart, Line, PieChart, Pie, Cell,
  XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend
} from "recharts";
import { BarChart3, TrendingUp, Target, Receipt, CreditCard, CheckCircle, RotateCcw } from "lucide-react";
import { ChartTooltip } from "@/components/charts/ChartTooltip";
import { CardSkeleton } from "@/components/ui/loading-skeleton";
import { revenueSeries, salesBars, chargebackSeries, formatCurrency } from "@/lib/mockData";
import TerritoryMap from "@/components/dashboard/TerritoryMap";
import { useApp } from "@/lib/AppContext";
import { cn } from "@/lib/utils";

const PERIODS = [
  { key: "today", label: "Hoje" },
  { key: "7d", label: "7 dias" },
  { key: "30d", label: "30 dias" },
  { key: "3m", label: "3 meses" },
  { key: "12m", label: "12 meses" }
];

export default function Reports() {
  const { products, transactions } = useApp();
  const [loading, setLoading] = useState(true);
  const [period, setPeriod] = useState("30d");

  useEffect(() => {
    const t = setTimeout(() => setLoading(false), 500);
    return () => clearTimeout(t);
  }, []);

  const topProducts = [...products].sort((a, b) => b.revenue - a.revenue).slice(0, 5);
  const methodData = [
    { name: "PIX", value: transactions.filter((t) => t.method === "PIX").length, color: "hsl(var(--chart-1))" },
    { name: "Cartão", value: transactions.filter((t) => t.method === "Cartão de crédito").length, color: "hsl(var(--chart-4))" },
    { name: "Boleto", value: transactions.filter((t) => t.method === "Boleto").length, color: "hsl(var(--chart-3))" }
  ];

  const ticketSeries = Array.from({ length: 12 }, (_, i) => ({ mes: ["Jan", "Fev", "Mar", "Abr", "Mai", "Jun", "Jul", "Ago", "Set", "Out", "Nov", "Dez"][i], ticket: Math.round(60 + Math.sin(i / 2) * 12 + i) }));

  return (
    <div className="space-y-5 max-w-[1400px] mx-auto">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <span className="text-[10px] uppercase tracking-[0.2em] text-primary font-semibold">Analytics</span>
          <h2 className="font-display font-bold text-white text-2xl tracking-tight-display">Relatórios</h2>
        </div>
        <div className="flex items-center gap-1 rounded-lg surface p-1">
          {PERIODS.map((p) => (
            <button key={p.key} onClick={() => setPeriod(p.key)} className={cn("rounded-md px-3 py-1.5 text-xs font-medium transition-colors", period === p.key ? "bg-primary/15 text-primary" : "text-muted-foreground hover:text-white")}>{p.label}</button>
          ))}
        </div>
      </div>

      {/* KPIs */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        {[
          { label: "Faturamento", value: formatCurrency(87920), icon: TrendingUp, trend: "+18,4%" },
          { label: "Vendas", value: "1.248", icon: BarChart3, trend: "+14,2%" },
          { label: "Ticket médio", value: formatCurrency(70.45), icon: Receipt, trend: "-2,1%" },
          { label: "Conversão", value: "8,42%", icon: Target, trend: "+1,3%" }
        ].map((k) => (
          <div key={k.label} className="rounded-xl surface p-4 glow-soft flex items-center gap-3">
            <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-black/40 border border-white/5"><k.icon className="h-4 w-4 text-primary" /></div>
            <div>
              <div className="text-[10px] uppercase tracking-[0.12em] text-muted-foreground">{k.label}</div>
              <div className="font-display font-bold text-white text-base tabular-nums">{k.value}</div>
              <div className={cn("text-[10px]", k.trend.startsWith("+") ? "text-success" : "text-[#FF6A4D]")}>{k.trend}</div>
            </div>
          </div>
        ))}
      </div>

      {/* Revenue + ticket */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <ChartCard title="Faturamento" subtitle="Evolução mensal" loading={loading}>
          <ResponsiveContainer width="100%" height={240}>
            <AreaChart data={revenueSeries} margin={{ top: 5, right: 5, left: -20, bottom: 0 }}>
              <defs><linearGradient id="r2" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor="#C10000" stopOpacity={0.3} /><stop offset="100%" stopColor="#C10000" stopOpacity={0} /></linearGradient></defs>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.04)" vertical={false} />
              <XAxis dataKey="day" tick={{ fill: "hsl(0 0% 45%)", fontSize: 10 }} axisLine={false} tickLine={false} interval={4} />
              <YAxis tick={{ fill: "hsl(0 0% 45%)", fontSize: 10 }} axisLine={false} tickLine={false} tickFormatter={(v) => `${v / 1000}k`} />
              <Tooltip content={<ChartTooltip currency />} />
              <Area type="monotone" dataKey="faturamento" stroke="#C10000" strokeWidth={2} fill="url(#r2)" />
            </AreaChart>
          </ResponsiveContainer>
        </ChartCard>

        <ChartCard title="Ticket médio" subtitle="12 meses" loading={loading}>
          <ResponsiveContainer width="100%" height={240}>
            <LineChart data={ticketSeries} margin={{ top: 5, right: 5, left: -20, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.04)" vertical={false} />
              <XAxis dataKey="mes" tick={{ fill: "hsl(0 0% 45%)", fontSize: 10 }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fill: "hsl(0 0% 45%)", fontSize: 10 }} axisLine={false} tickLine={false} tickFormatter={(v) => `R$${v}`} />
              <Tooltip content={<ChartTooltip prefix="R$ " />} />
              <Line type="monotone" dataKey="ticket" stroke="#C10000" strokeWidth={2} dot={{ fill: "#C10000", r: 3 }} activeDot={{ r: 5 }} />
            </LineChart>
          </ResponsiveContainer>
        </ChartCard>
      </div>

      {/* Sales + methods */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <ChartCard title="Vendas por dia" subtitle="Esta semana" loading={loading}>
          <ResponsiveContainer width="100%" height={240}>
            <BarChart data={salesBars} margin={{ top: 5, right: 5, left: -28, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.04)" vertical={false} />
              <XAxis dataKey="dia" tick={{ fill: "hsl(0 0% 45%)", fontSize: 10 }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fill: "hsl(0 0% 45%)", fontSize: 10 }} axisLine={false} tickLine={false} />
              <Tooltip content={<ChartTooltip />} cursor={{ fill: "rgba(255,255,255,0.02)" }} />
              <Bar dataKey="vendas" fill="#8A0303" radius={[4, 4, 0, 0]} maxBarSize={32} />
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>

        <ChartCard title="Métodos de pagamento" subtitle="Distribuição" loading={loading}>
          <ResponsiveContainer width="100%" height={240}>
            <PieChart>
              <Pie data={methodData} dataKey="value" nameKey="name" cx="50%" cy="50%" innerRadius={55} outerRadius={85} paddingAngle={3}>
                {methodData.map((entry, i) => <Cell key={i} fill={entry.color} stroke="none" />)}
              </Pie>
              <Tooltip content={<ChartTooltip />} />
              <Legend formatter={(v) => <span className="text-xs text-muted-foreground">{v}</span>} />
            </PieChart>
          </ResponsiveContainer>
        </ChartCard>
      </div>

      {/* Mapa de vendas por território */}
      <TerritoryMap period={period} expanded />

      {/* Top products + chargebacks */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <div className="rounded-xl surface glow-soft p-5">
          <h3 className="font-display font-semibold text-white text-sm mb-4">Produtos mais vendidos</h3>
          <div className="space-y-3">
            {topProducts.map((p, i) => (
              <div key={p.id} className="flex items-center gap-3">
                <span className="font-display font-bold text-muted-foreground/40 text-sm w-5">{String(i + 1).padStart(2, "0")}</span>
                <div className="flex-1 min-w-0">
                  <div className="flex justify-between mb-1">
                    <span className="text-sm text-white truncate">{p.name}</span>
                    <span className="text-xs text-white font-medium tabular-nums ml-2">{formatCurrency(p.revenue)}</span>
                  </div>
                  <div className="h-1.5 rounded-full bg-white/[0.04] overflow-hidden">
                    <div className="h-full rounded-full bg-gradient-to-r from-[#8A0303] to-[#E10600]" style={{ width: `${(p.revenue / topProducts[0].revenue) * 100}%` }} />
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        <ChartCard title="Aprovação e reembolsos" subtitle="6 meses" loading={loading}>
          <ResponsiveContainer width="100%" height={240}>
            <BarChart data={chargebackSeries} margin={{ top: 5, right: 5, left: -28, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.04)" vertical={false} />
              <XAxis dataKey="mes" tick={{ fill: "hsl(0 0% 45%)", fontSize: 10 }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fill: "hsl(0 0% 45%)", fontSize: 10 }} axisLine={false} tickLine={false} />
              <Tooltip content={<ChartTooltip />} cursor={{ fill: "rgba(255,255,255,0.02)" }} />
              <Legend formatter={(v) => <span className="text-xs text-muted-foreground">{v}</span>} />
              <Bar dataKey="chargebacks" fill="#C10000" radius={[3, 3, 0, 0]} maxBarSize={14} />
              <Bar dataKey="reembolsos" fill="rgba(255,255,255,0.15)" radius={[3, 3, 0, 0]} maxBarSize={14} />
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>
      </div>
    </div>
  );
}

function ChartCard({ title, subtitle, loading, children }) {
  return (
    <div className="rounded-xl surface glow-soft p-5">
      <div className="mb-4">
        <h3 className="font-display font-semibold text-white text-sm">{title}</h3>
        <p className="text-[11px] text-muted-foreground">{subtitle}</p>
      </div>
      {loading ? <CardSkeleton /> : children}
    </div>
  );
}