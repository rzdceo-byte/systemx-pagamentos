import React, { useState, useEffect, useMemo } from "react";
import { Search, Download, Calendar, TrendingUp } from "lucide-react";
import StatusBadge from "@/components/ui/status-badge";
import { DataTable } from "@/components/ui/data-table";
import EmptyState from "@/components/ui/empty-state";
import { TableSkeleton } from "@/components/ui/loading-skeleton";
import { formatCurrency } from "@/lib/mockData";
import { useApp } from "@/lib/AppContext";
import { cn } from "@/lib/utils";

const PERIODS = [
  { key: "today", label: "Hoje" },
  { key: "7d", label: "7 dias" },
  { key: "30d", label: "30 dias" },
  { key: "custom", label: "Personalizado" }
];

export default function Sales() {
  const { transactions } = useApp();
  const [loading, setLoading] = useState(true);
  const [period, setPeriod] = useState("7d");
  const [query, setQuery] = useState("");
  const [debounced, setDebounced] = useState("");

  useEffect(() => {
    const t = setTimeout(() => setLoading(false), 500);
    return () => clearTimeout(t);
  }, []);

  useEffect(() => {
    const t = setTimeout(() => setDebounced(query), 300);
    return () => clearTimeout(t);
  }, [query]);

  const filtered = useMemo(() => {
    return transactions.filter((tx) => {
      const q = debounced.toLowerCase().trim();
      if (!q) return true;
      return (
        tx.customer.toLowerCase().includes(q) ||
        tx.email.toLowerCase().includes(q) ||
        tx.cpf.toLowerCase().includes(q) ||
        tx.id.toLowerCase().includes(q) ||
        tx.product.toLowerCase().includes(q)
      );
    });
  }, [transactions, debounced]);

  const totalAprovado = filtered.filter((t) => t.status === "aprovado").reduce((s, t) => s + t.value, 0);

  const columns = [
    { key: "id", header: "ID", render: (r) => <span className="font-mono text-xs text-muted-foreground">{r.id}</span> },
    { key: "date", header: "Data", render: (r) => <span className="text-xs text-muted-foreground">{r.date}</span> },
    { key: "product", header: "Produto", render: (r) => <span className="text-sm truncate max-w-[180px] block">{r.product}</span> },
    { key: "customer", header: "Cliente", render: (r) => (
      <div>
        <div className="text-sm text-white">{r.customer}</div>
        <div className="text-[11px] text-muted-foreground">{r.email}</div>
      </div>
    ) },
    { key: "value", header: "Valor", align: "right", render: (r) => <span className="font-medium tabular-nums">{formatCurrency(r.value)}</span> },
    { key: "method", header: "Método", render: (r) => <span className="text-xs text-muted-foreground">{r.method}</span> },
    { key: "status", header: "Status", render: (r) => <StatusBadge status={r.status} /> }
  ];

  return (
    <div className="space-y-5 max-w-[1400px] mx-auto">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <span className="text-[10px] uppercase tracking-[0.2em] text-primary font-semibold">Vendas</span>
          <h2 className="font-display font-bold text-white text-2xl tracking-tight-display">Histórico de transações</h2>
        </div>
        <div className="flex items-center gap-2">
          <button className="inline-flex items-center gap-2 rounded-lg border border-white/10 px-3 py-2 text-xs text-muted-foreground hover:text-white hover:bg-white/5 transition-colors">
            <Download className="h-3.5 w-3.5" /> Exportar
          </button>
        </div>
      </div>

      {/* Summary */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        {[
          { label: "Total filtrado", value: formatCurrency(filtered.reduce((s, t) => s + t.value, 0)) },
          { label: "Aprovado", value: formatCurrency(totalAprovado) },
          { label: "Transações", value: filtered.length.toString() },
          { label: "Taxa aprovação", value: filtered.length ? `${Math.round(filtered.filter(t=>t.status==="aprovado").length/filtered.length*100)}%` : "—" }
        ].map((s) => (
          <div key={s.label} className="rounded-xl surface p-4 glow-soft">
            <div className="text-[10px] uppercase tracking-[0.12em] text-muted-foreground">{s.label}</div>
            <div className="font-display font-bold text-white text-lg mt-1 tabular-nums">{s.value}</div>
          </div>
        ))}
      </div>

      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-3 items-stretch sm:items-center justify-between">
        <div className="flex items-center gap-1 rounded-lg surface p-1">
          {PERIODS.map((p) => (
            <button
              key={p.key}
              onClick={() => setPeriod(p.key)}
              className={cn(
                "flex items-center gap-1.5 rounded-md px-3 py-1.5 text-xs font-medium transition-colors",
                period === p.key ? "bg-primary/15 text-primary" : "text-muted-foreground hover:text-white"
              )}
            >
              {p.key === "custom" && <Calendar className="h-3 w-3" />}
              {p.label}
            </button>
          ))}
        </div>

        <div className="relative flex-1 sm:max-w-xs">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Buscar por nome, e-mail, CPF, ID..."
            className="w-full rounded-lg surface pl-9 pr-3 py-2 text-sm text-white placeholder:text-muted-foreground focus:outline-none focus:border-primary/50 transition-colors"
          />
        </div>
      </div>

      {/* Table */}
      <div className="rounded-xl surface glow-soft overflow-hidden">
        {loading ? <TableSkeleton rows={8} cols={7} /> : filtered.length === 0 ? (
          <EmptyState icon={TrendingUp} title="Nenhuma venda encontrada" description="Ajuste os filtros ou o termo de busca para ver transações." />
        ) : (
          <DataTable columns={columns} data={filtered} />
        )}
      </div>
    </div>
  );
}