import React, { useState, useEffect, useMemo } from "react";
import { Search, Download, ArrowLeftRight } from "lucide-react";
import StatusBadge from "@/components/ui/status-badge";
import { DataTable } from "@/components/ui/data-table";
import EmptyState from "@/components/ui/empty-state";
import { TableSkeleton } from "@/components/ui/loading-skeleton";
import { formatCurrency } from "@/lib/mockData";
import { useApp } from "@/lib/AppContext";

export default function Transactions() {
  const { transactions } = useApp();
  const [loading, setLoading] = useState(true);
  const [query, setQuery] = useState("");
  const [debounced, setDebounced] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");

  useEffect(() => {
    const t = setTimeout(() => setLoading(false), 500);
    return () => clearTimeout(t);
  }, []);
  useEffect(() => {
    const t = setTimeout(() => setDebounced(query), 300);
    return () => clearTimeout(t);
  }, [query]);

  const statuses = ["all", "aprovado", "pendente", "recusado", "reembolsado", "chargeback"];

  const filtered = useMemo(() => {
    const q = debounced.toLowerCase().trim();
    return transactions.filter((t) => {
      if (statusFilter !== "all" && t.status !== statusFilter) return false;
      if (!q) return true;
      return t.customer.toLowerCase().includes(q) || t.email.toLowerCase().includes(q) || t.id.toLowerCase().includes(q) || t.product.toLowerCase().includes(q);
    });
  }, [transactions, debounced, statusFilter]);

  const columns = [
    { key: "id", header: "ID", render: (r) => <span className="font-mono text-xs text-muted-foreground">{r.id}</span> },
    { key: "date", header: "Data", render: (r) => <span className="text-xs text-muted-foreground">{r.date}</span> },
    { key: "product", header: "Produto", render: (r) => <span className="text-sm truncate max-w-[180px] block">{r.product}</span> },
    { key: "customer", header: "Cliente", render: (r) => (
      <div><div className="text-sm text-white">{r.customer}</div><div className="text-[11px] text-muted-foreground">{r.email}</div></div>
    ) },
    { key: "value", header: "Valor", align: "right", render: (r) => <span className="font-medium tabular-nums">{formatCurrency(r.value)}</span> },
    { key: "method", header: "Método", render: (r) => <span className="text-xs text-muted-foreground">{r.method}</span> },
    { key: "status", header: "Status", render: (r) => <StatusBadge status={r.status} /> }
  ];

  return (
    <div className="space-y-5 max-w-[1400px] mx-auto">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <span className="text-[10px] uppercase tracking-[0.2em] text-primary font-semibold">Log</span>
          <h2 className="font-display font-bold text-white text-2xl tracking-tight-display">Transações</h2>
        </div>
        <button className="inline-flex items-center gap-2 rounded-lg border border-white/10 px-3 py-2 text-xs text-muted-foreground hover:text-white hover:bg-white/5 transition-colors">
          <Download className="h-3.5 w-3.5" /> Exportar CSV
        </button>
      </div>

      <div className="flex flex-col sm:flex-row gap-3 items-stretch sm:items-center justify-between">
        <div className="flex flex-wrap items-center gap-1 rounded-lg surface p-1">
          {statuses.map((s) => (
            <button key={s} onClick={() => setStatusFilter(s)} className={`rounded-md px-3 py-1.5 text-xs font-medium transition-colors ${statusFilter === s ? "bg-primary/15 text-primary" : "text-muted-foreground hover:text-white"}`}>
              {s === "all" ? "Todos" : s.charAt(0).toUpperCase() + s.slice(1)}
            </button>
          ))}
        </div>
        <div className="relative sm:max-w-xs flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Buscar transação..." className="w-full rounded-lg surface pl-9 pr-3 py-2 text-sm text-white placeholder:text-muted-foreground focus:outline-none focus:border-primary/50" />
        </div>
      </div>

      <div className="rounded-xl surface glow-soft overflow-hidden">
        {loading ? <TableSkeleton rows={8} cols={7} /> : filtered.length === 0 ? (
          <EmptyState icon={ArrowLeftRight} title="Nenhuma transação" description="Nenhuma transação corresponde aos filtros." />
        ) : (
          <DataTable columns={columns} data={filtered} />
        )}
      </div>
    </div>
  );
}