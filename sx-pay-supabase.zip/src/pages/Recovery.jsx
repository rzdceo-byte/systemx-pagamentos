import React, { useMemo, useState, useEffect } from "react";
import { RotateCcw, Send, Clock, CheckCircle2, Mail, Users, Zap, MailOpen, AlertCircle, Loader2 } from "lucide-react";
import { useApp } from "@/lib/AppContext";
import { useToast } from "@/components/ui/use-toast";
import { CardSkeleton } from "@/components/ui/loading-skeleton";
import { Switch } from "@/components/ui/switch";
import { cn } from "@/lib/utils";
import { formatCurrency } from "@/lib/mockData";

function timeAgo(dateStr) {
  if (!dateStr) return "—";
  const d = new Date(dateStr);
  if (isNaN(d)) return "—";
  const mins = Math.floor((Date.now() - d.getTime()) / 60000);
  if (mins < 1) return "agora";
  if (mins < 60) return `${mins} min atrás`;
  const hrs = Math.floor(mins / 60);
  if (hrs < 24) return `${hrs}h atrás`;
  return `${Math.floor(hrs / 24)}d atrás`;
}

export default function Recovery() {
  const { customers, recoveryLog, buildRecoveryEmail, sendRecoveryEmail, bulkSendRecovery, autoRecovery, toggleAutoRecovery } = useApp();
  const { toast } = useToast();
  const [loading, setLoading] = useState(true);
  const [selectedId, setSelectedId] = useState(null);
  const [sending, setSending] = useState(false);
  const [bulkSending, setBulkSending] = useState(false);

  useEffect(() => { const t = setTimeout(() => setLoading(false), 350); return () => clearTimeout(t); }, []);

  const abandonedLeads = useMemo(() => customers.filter((c) => c.status === "lead"), [customers]);

  // Mapa: leadId -> último e-mail de recuperação enviado
  const lastEmailByLead = useMemo(() => {
    const map = {};
    for (const r of recoveryLog) if (!map[r.leadId] || r.sentAt > map[r.leadId].sentAt) map[r.leadId] = r;
    return map;
  }, [recoveryLog]);

  const recoveredCount = useMemo(
    () => recoveryLog.filter((r) => { const c = customers.find((x) => x.id === r.leadId); return c && c.status === "ativo"; }).length,
    [recoveryLog, customers]
  );

  const stats = [
    { label: "Carrinhos abandonados", value: abandonedLeads.length, icon: RotateCcw, accent: "text-primary" },
    { label: "E-mails enviados", value: recoveryLog.length, icon: Mail, accent: "text-white" },
    { label: "Leads recuperados", value: recoveredCount, icon: CheckCircle2, accent: "text-success" },
    { label: "Taxa de recuperação", value: abandonedLeads.length > 0 ? `${Math.round((recoveredCount / (recoveredLeadsBase())) * 100)}%` : "—", icon: Zap, accent: "text-warning" }
  ];
  function recoveredLeadsBase() { return Math.max(abandonedLeads.length + recoveredCount, recoveryLog.length, 1); }

  // Recuperação automática: quando ativa, envia para leads abandonados ainda não e-mailed
  useEffect(() => {
    if (!autoRecovery) return;
    const pending = abandonedLeads.filter((l) => !lastEmailByLead[l.id]);
    if (pending.length === 0) return;
    (async () => {
      for (const l of pending.slice(0, 5)) await sendRecoveryEmail(l);
      toast({ title: "Recuperação automática", description: `${pending.length} e-mail(is) disparados para leads abandonados.` });
    })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [autoRecovery]);

  const handleSend = async (lead) => {
    setSending(true);
    const res = await sendRecoveryEmail(lead);
    setSending(false);
    toast({
      title: res.status === "enviado" ? "E-mail enviado" : "E-mail registrado (simulado)",
      description: res.status === "enviado" ? `Recuperação enviada para ${lead.email}.` : "Destinatário não registrado no app — entrega simulada.",
      variant: res.status === "enviado" ? "default" : "destructive"
    });
  };

  const handleBulk = async () => {
    if (abandonedLeads.length === 0) return;
    setBulkSending(true);
    await bulkSendRecovery(abandonedLeads);
    setBulkSending(false);
    toast({ title: "Disparo em lote concluído", description: `${abandonedLeads.length} e-mails de recuperação processados.` });
  };

  const selected = abandonedLeads.find((l) => l.id === selectedId) || abandonedLeads[0] || null;
  const preview = selected ? buildRecoveryEmail(selected) : null;

  return (
    <div className="space-y-6 animate-fade-in">
      <header className="flex flex-col lg:flex-row lg:items-end lg:justify-between gap-4">
        <div>
          <h1 className="font-display font-bold text-white text-2xl lg:text-3xl tracking-tight-display">Recuperação de Carrinho</h1>
          <p className="text-sm text-muted-foreground mt-1">Recupere leads que abandonaram o checkout com e-mails personalizados e automáticos.</p>
        </div>
        <div className="flex flex-wrap items-center gap-3">
          <div className="flex items-center gap-3 rounded-xl surface px-4 py-2.5">
            <div className="text-right">
              <div className="text-[11px] text-muted-foreground">Recuperação automática</div>
              <div className="text-[10px] text-muted-foreground/70">{autoRecovery ? "Ativa · dispara para novos leads" : "Desativada"}</div>
            </div>
            <Switch checked={autoRecovery} onCheckedChange={toggleAutoRecovery} />
          </div>
          <button onClick={handleBulk} disabled={bulkSending || abandonedLeads.length === 0} className="inline-flex items-center gap-2 rounded-lg bg-primary px-4 py-2.5 text-sm font-bold text-white disabled:opacity-50 hover:bg-[#E10600] transition-colors">
            {bulkSending ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
            Disparar para todos ({abandonedLeads.length})
          </button>
        </div>
      </header>

      {/* Alerta de limitação */}
      <div className="rounded-lg border border-warning/30 bg-warning/[0.06] px-4 py-3 flex items-start gap-2.5">
        <AlertCircle className="h-4 w-4 text-warning shrink-0 mt-0.5" />
        <p className="text-xs text-muted-foreground leading-relaxed">
          O envio de e-mail da plataforma entrega apenas para <span className="text-white font-medium">usuários registrados no app</span>. Leads externos (compradores finais) terão o e-mail composto e registrado como <span className="text-white">simulado</span>, sem entrega real — próprio de um ambiente de pagamentos simulado.
        </p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        {loading ? (
          Array.from({ length: 4 }).map((_, i) => <CardSkeleton key={i} />)
        ) : (
          stats.map((s) => (
            <div key={s.label} className="rounded-xl surface glow-soft p-5">
              <div className="flex items-center justify-between mb-3">
                <span className="text-[11px] text-muted-foreground uppercase tracking-wider">{s.label}</span>
                <s.icon className={cn("h-4 w-4", s.accent)} />
              </div>
              <div className="font-display font-bold text-white text-2xl tracking-tight-display tabular-nums">{s.value}</div>
            </div>
          ))
        )}
      </div>

      <div className="grid lg:grid-cols-[1fr_420px] gap-4 lg:gap-6">
        {/* Lista de leads abandonados */}
        <div className="rounded-xl surface glow-soft overflow-hidden">
          <div className="flex items-center justify-between px-5 py-3.5 border-b border-white/5">
            <h2 className="font-display font-bold text-white text-sm flex items-center gap-2"><Users className="h-4 w-4 text-primary" /> Leads com carrinho abandonado</h2>
            <span className="text-[11px] text-muted-foreground">{abandonedLeads.length} leads</span>
          </div>
          {loading ? (
            <div className="p-5 space-y-3">{Array.from({ length: 5 }).map((_, i) => <div key={i} className="h-14 rounded-lg bg-white/[0.03] animate-pulse" />)}</div>
          ) : abandonedLeads.length === 0 ? (
            <div className="p-10 text-center">
              <CheckCircle2 className="h-10 w-10 mx-auto text-success/40 mb-3" />
              <p className="text-sm text-muted-foreground">Nenhum carrinho abandonado no momento. 🎉</p>
            </div>
          ) : (
            <div className="divide-y divide-white/[0.04]">
              {abandonedLeads.map((lead) => {
                const last = lastEmailByLead[lead.id];
                const isSelected = selected?.id === lead.id;
                return (
                  <button key={lead.id} onClick={() => setSelectedId(lead.id)} className={cn("w-full text-left px-5 py-3.5 flex items-center gap-3 transition-colors", isSelected ? "bg-primary/[0.06]" : "hover:bg-white/[0.02]")}>
                    <div className="h-9 w-9 rounded-full bg-white/10 flex items-center justify-center text-sm font-bold text-white shrink-0">{(lead.name || "?")[0]}</div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="text-sm text-white font-medium truncate">{lead.name || "Lead"}</span>
                        {lead.productName && <span className="text-[10px] text-muted-foreground truncate hidden sm:inline">· {lead.productName}</span>}
                      </div>
                      <div className="text-[11px] text-muted-foreground truncate">{lead.email}</div>
                    </div>
                    <div className="text-right shrink-0">
                      <div className="text-[10px] text-muted-foreground flex items-center gap-1 justify-end"><Clock className="h-3 w-3" /> {timeAgo(lead.abandonedAt || lead.lastPurchase)}</div>
                      {lead.price != null && <div className="text-[11px] text-white font-medium">{formatCurrency(lead.price)}</div>}
                    </div>
                    {last ? (
                      <span className={cn("shrink-0 inline-flex items-center gap-1 rounded-md px-2 py-1 text-[10px] font-medium", last.status === "enviado" ? "bg-success/15 text-success" : "bg-white/5 text-muted-foreground")}>
                        {last.status === "enviado" ? <MailOpen className="h-3 w-3" /> : <Mail className="h-3 w-3" />} {last.status}
                      </span>
                    ) : (
                      <span className="shrink-0 inline-flex items-center gap-1 rounded-md bg-primary/10 text-primary px-2 py-1 text-[10px] font-medium"><Send className="h-3 w-3" /> enviar</span>
                    )}
                  </button>
                );
              })}
            </div>
          )}
        </div>

        {/* Preview do e-mail */}
        <div className="rounded-xl surface glow-soft overflow-hidden lg:sticky lg:top-6 h-fit">
          <div className="flex items-center justify-between px-5 py-3.5 border-b border-white/5">
            <h2 className="font-display font-bold text-white text-sm flex items-center gap-2"><Mail className="h-4 w-4 text-primary" /> Pré-visualização</h2>
            {selected && (
              <button onClick={() => handleSend(selected)} disabled={sending} className="inline-flex items-center gap-1.5 rounded-md bg-primary px-3 py-1.5 text-xs font-bold text-white disabled:opacity-60 hover:bg-[#E10600] transition-colors">
                {sending ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Send className="h-3.5 w-3.5" />} Enviar agora
              </button>
            )}
          </div>
          {!selected ? (
            <div className="p-10 text-center text-sm text-muted-foreground">Selecione um lead para visualizar o e-mail.</div>
          ) : (
            <div className="p-5 space-y-4">
              <div className="space-y-1.5">
                <div className="text-[10px] text-muted-foreground uppercase tracking-wider">Para</div>
                <div className="text-sm text-white">{selected.name} &lt;{selected.email}&gt;</div>
              </div>
              <div className="space-y-1.5">
                <div className="text-[10px] text-muted-foreground uppercase tracking-wider">Assunto</div>
                <div className="text-sm text-white font-medium">{preview.subject}</div>
              </div>
              <div className="space-y-1.5">
                <div className="text-[10px] text-muted-foreground uppercase tracking-wider">Corpo</div>
                <div className="rounded-lg bg-black/40 border border-white/5 p-4 text-[13px] text-muted-foreground leading-relaxed whitespace-pre-wrap font-body">{preview.body}</div>
              </div>
              {preview.link && (
                <div className="rounded-lg border border-primary/30 bg-primary/[0.06] px-3 py-2.5 flex items-center gap-2">
                  <Zap className="h-3.5 w-3.5 text-primary shrink-0" />
                  <span className="text-[11px] text-muted-foreground truncate">Link de retomada: <span className="text-white font-mono">{preview.link}</span></span>
                </div>
              )}
              <div className="flex items-center gap-1.5 text-[10px] text-muted-foreground/70 pt-1">
                <AlertCircle className="h-3 w-3" /> Entrega real apenas para usuários registrados no app.
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}