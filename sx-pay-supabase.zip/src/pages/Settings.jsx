import React, { useState } from "react";
import { User, Building2, Landmark, Webhook, KeyRound, Plug, Globe, Bell, Shield, Copy, Check, Eye, EyeOff, Plus, Trash2, ChevronRight, RotateCcw } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import StatusBadge from "@/components/ui/status-badge";
import { account, bankData, apiKeys, webhooks, requestLogs } from "@/lib/mockData";
import { useToast } from "@/components/ui/use-toast";
import { restartOnboarding } from "@/components/tour/OnboardingTour";
import { cn } from "@/lib/utils";

const SECTIONS = [
  { key: "profile", label: "Perfil", icon: User },
  { key: "company", label: "Dados da empresa", icon: Building2 },
  { key: "bank", label: "Dados bancários", icon: Landmark },
  { key: "webhooks", label: "Webhooks", icon: Webhook },
  { key: "api", label: "API & Desenvolvedores", icon: KeyRound },
  { key: "integrations", label: "Integrações", icon: Plug },
  { key: "domains", label: "Domínios", icon: Globe },
  { key: "notifications", label: "Notificações", icon: Bell },
  { key: "security", label: "Segurança", icon: Shield }
];

export default function Settings() {
  const [active, setActive] = useState("profile");

  return (
    <div className="max-w-[1100px] mx-auto space-y-5">
      <div>
        <span className="text-[10px] uppercase tracking-[0.2em] text-primary font-semibold">Conta</span>
        <h2 className="font-display font-bold text-white text-2xl tracking-tight-display">Configurações</h2>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-[220px_1fr] gap-5">
        {/* Section nav */}
        <div className="flex lg:flex-col gap-1 overflow-x-auto lg:overflow-visible pb-2 lg:pb-0">
          {SECTIONS.map((s) => (
            <button key={s.key} onClick={() => setActive(s.key)} className={cn("flex items-center gap-2.5 rounded-lg px-3 py-2 text-sm font-medium transition-colors whitespace-nowrap shrink-0 lg:w-full", active === s.key ? "bg-primary/10 text-white" : "text-muted-foreground hover:text-white hover:bg-white/[0.03]")}>
              <s.icon className={cn("h-4 w-4", active === s.key && "text-primary")} />
              <span className="hidden sm:inline">{s.label}</span>
              <ChevronRight className="hidden lg:block h-3.5 w-3.5 ml-auto text-muted-foreground/40" />
            </button>
          ))}
        </div>

        {/* Content */}
        <div className="rounded-xl surface glow-soft p-5 lg:p-6">
          {active === "profile" && <ProfileSection />}
          {active === "company" && <CompanySection />}
          {active === "bank" && <BankSection />}
          {active === "webhooks" && <WebhooksSection />}
          {active === "api" && <ApiSection />}
          {active === "integrations" && <IntegrationsSection />}
          {active === "domains" && <DomainsSection />}
          {active === "notifications" && <NotificationsSection />}
          {active === "security" && <SecuritySection />}
        </div>
      </div>
    </div>
  );
}

function SectionHeader({ title, desc }) {
  return (
    <div className="mb-5 pb-4 border-b border-white/5">
      <h3 className="font-display font-semibold text-white text-base">{title}</h3>
      {desc && <p className="text-xs text-muted-foreground mt-0.5">{desc}</p>}
    </div>
  );
}

function Row({ label, children }) {
  return (
    <div className="space-y-1.5">
      <Label className="text-muted-foreground text-xs">{label}</Label>
      {children}
    </div>
  );
}

function ProfileSection() {
  const { toast } = useToast();
  return (
    <div>
      <SectionHeader title="Perfil" desc="Suas informações pessoais de acesso." />
      <div className="flex items-center gap-4 mb-6">
        <div className="flex h-16 w-16 items-center justify-center rounded-xl bg-gradient-to-br from-[#8A0303] to-[#1a1a1a] text-white text-lg font-semibold border border-primary/30 glow-red-sm">
          {account.name.split(" ").map(n => n[0]).join("").slice(0, 2)}
        </div>
        <div>
          <div className="text-sm text-white font-medium">{account.name}</div>
          <div className="text-xs text-primary">{account.plan}</div>
        </div>
      </div>
      <div className="grid sm:grid-cols-2 gap-4">
        <Row label="Nome completo"><Input defaultValue={account.name} className="bg-background border-white/10" /></Row>
        <Row label="E-mail"><Input defaultValue={account.email} className="bg-background border-white/10" /></Row>
      </div>
      <div className="flex items-center gap-2 mt-5">
        <Button onClick={() => toast({ title: "Perfil salvo" })} className="bg-primary hover:bg-[#E10600]">Salvar alterações</Button>
        <Button variant="outline" onClick={() => { restartOnboarding(); toast({ title: "Tutorial reiniciado", description: "O tour de boas-vindas vai aparecer agora." }); }} className="gap-2 border-white/10">
          <RotateCcw className="h-4 w-4" /> Refazer tutorial
        </Button>
      </div>
    </div>
  );
}

function CompanySection() {
  const { toast } = useToast();
  return (
    <div>
      <SectionHeader title="Dados da empresa" desc="Informações usadas em notas fiscais e recebíveis." />
      <div className="grid sm:grid-cols-2 gap-4">
        <Row label="Razão social"><Input defaultValue={account.company} className="bg-background border-white/10" /></Row>
        <Row label="CNPJ"><Input defaultValue={account.cnpj} className="bg-background border-white/10" /></Row>
      </div>
      <div className="mt-5"><Button onClick={() => toast({ title: "Dados salvos" })} className="bg-primary hover:bg-[#E10600]">Salvar</Button></div>
    </div>
  );
}

function BankSection() {
  const { toast } = useToast();
  return (
    <div>
      <SectionHeader title="Dados bancários" desc="Conta para recebimento de saques." />
      <div className="grid sm:grid-cols-2 gap-4">
        <Row label="Banco"><Input defaultValue={bankData.bank} className="bg-background border-white/10" /></Row>
        <Row label="Tipo de conta"><Input defaultValue={bankData.type} className="bg-background border-white/10" /></Row>
        <Row label="Agência"><Input defaultValue={bankData.agency} className="bg-background border-white/10" /></Row>
        <Row label="Conta"><Input defaultValue={bankData.account} className="bg-background border-white/10" /></Row>
        <Row label="Titular"><Input defaultValue={bankData.holder} className="bg-background border-white/10" /></Row>
        <Row label="Documento"><Input defaultValue={bankData.document} className="bg-background border-white/10" /></Row>
      </div>
      <div className="mt-5"><Button onClick={() => toast({ title: "Dados bancários salvos" })} className="bg-primary hover:bg-[#E10600]">Salvar</Button></div>
    </div>
  );
}

function WebhooksSection() {
  const { toast } = useToast();
  return (
    <div>
      <SectionHeader title="Webhooks" desc="Receba eventos de pagamento em tempo real." />
      <div className="space-y-2 mb-4">
        {webhooks.map((w) => (
          <div key={w.id} className="flex items-center justify-between rounded-lg bg-white/[0.02] border border-white/5 p-3">
            <div className="min-w-0">
              <div className="text-sm text-white font-mono truncate">{w.url}</div>
              <div className="flex gap-1 mt-1">{w.events.map((e) => <span key={e} className="text-[10px] px-1.5 py-0.5 rounded bg-white/5 text-muted-foreground">{e}</span>)}</div>
            </div>
            <StatusBadge status={w.status} />
          </div>
        ))}
      </div>
      <Button variant="outline" onClick={() => toast({ title: "Em breve" })} className="gap-2 border-white/10"><Plus className="h-4 w-4" /> Novo webhook</Button>
    </div>
  );
}

function ApiSection() {
  const { toast } = useToast();
  const [revealed, setRevealed] = useState({});
  const [copied, setCopied] = useState(null);

  const copyKey = (key, id) => {
    navigator.clipboard.writeText(key);
    setCopied(id);
    toast({ title: "Chave copiada" });
    setTimeout(() => setCopied(null), 2000);
  };

  return (
    <div>
      <SectionHeader title="API & Desenvolvedores" desc="Integre a SXPay via API. Chaves são SIMULADAS." />

      <div className="space-y-3 mb-6">
        <Label className="text-muted-foreground text-xs uppercase tracking-[0.1em]">API Keys</Label>
        {apiKeys.map((k) => (
          <div key={k.id} className="rounded-lg bg-white/[0.02] border border-white/5 p-4">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm text-white font-medium">{k.name}</span>
              <span className="text-[10px] text-muted-foreground">{k.created}</span>
            </div>
            <div className="flex items-center gap-2">
              <code className="flex-1 rounded-md bg-black/40 border border-white/5 px-3 py-2 text-xs text-muted-foreground font-mono truncate">
                {revealed[k.id] ? k.key : k.key.slice(0, 12) + "••••••••••••••••••••••••••••••"}
              </code>
              <button onClick={() => setRevealed((r) => ({ ...r, [k.id]: !r[k.id] }))} className="flex h-8 w-8 items-center justify-center rounded-md bg-white/5 hover:bg-white/10 text-muted-foreground hover:text-white">
                {revealed[k.id] ? <EyeOff className="h-3.5 w-3.5" /> : <Eye className="h-3.5 w-3.5" />}
              </button>
              <button onClick={() => copyKey(k.key, k.id)} className="flex h-8 w-8 items-center justify-center rounded-md bg-white/5 hover:bg-white/10 text-muted-foreground hover:text-white">
                {copied === k.id ? <Check className="h-3.5 w-3.5 text-success" /> : <Copy className="h-3.5 w-3.5" />}
              </button>
              <button onClick={() => toast({ title: "Chave revogada", variant: "destructive" })} className="flex h-8 w-8 items-center justify-center rounded-md bg-white/5 hover:bg-[#E10600]/15 text-muted-foreground hover:text-[#FF6A4D]">
                <Trash2 className="h-3.5 w-3.5" />
              </button>
            </div>
            <div className="text-[10px] text-muted-foreground mt-2">Último uso: {k.lastUsed}</div>
          </div>
        ))}
        <Button variant="outline" onClick={() => toast({ title: "Chave gerada (simulada)" })} className="gap-2 border-white/10"><Plus className="h-4 w-4" /> Gerar nova chave</Button>
      </div>

      <div className="mb-6">
        <Label className="text-muted-foreground text-xs uppercase tracking-[0.1em] mb-2 block">Base URL</Label>
        <code className="block rounded-md bg-black/40 border border-white/5 px-3 py-2 text-xs text-muted-foreground font-mono">https://api.sxpay.com/v1</code>
      </div>

      <div>
        <Label className="text-muted-foreground text-xs uppercase tracking-[0.1em] mb-2 block">Logs de requisições</Label>
        <div className="rounded-lg bg-white/[0.02] border border-white/5 overflow-hidden">
          <table className="w-full">
            <thead>
              <tr className="border-b border-white/5">
                {["Horário", "Método", "Endpoint", "Status", "Tempo"].map((h) => (
                  <th key={h} className="text-left text-[10px] uppercase tracking-[0.1em] text-muted-foreground font-semibold py-2 px-3">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {requestLogs.map((l) => (
                <tr key={l.id} className="border-b border-white/[0.03]">
                  <td className="py-2 px-3 text-[11px] text-muted-foreground font-mono">{l.time}</td>
                  <td className="py-2 px-3"><span className={cn("text-[10px] font-mono font-semibold px-1.5 py-0.5 rounded", l.method === "GET" ? "bg-blue-500/10 text-blue-400" : "bg-primary/10 text-primary")}>{l.method}</span></td>
                  <td className="py-2 px-3 text-[11px] text-white font-mono">{l.endpoint}</td>
                  <td className="py-2 px-3"><span className={cn("text-[11px] font-mono font-semibold", l.status < 300 ? "text-success" : "text-[#FF6A4D]")}>{l.status}</span></td>
                  <td className="py-2 px-3 text-[11px] text-muted-foreground tabular-nums">{l.ms}ms</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

function IntegrationsSection() {
  const items = [
    { name: "Zapier", desc: "Automatize fluxos", connected: true },
    { name: "Google Analytics", desc: "Tracking de conversão", connected: true },
    { name: "Facebook Pixel", desc: "Anúncios e retargeting", connected: false },
    { name: "Slack", desc: "Notificações de venda", connected: false },
    { name: "Make (Integromat)", desc: "Automações", connected: false }
  ];
  return (
    <div>
      <SectionHeader title="Integrações" desc="Conecte ferramentas que você já usa." />
      <div className="grid sm:grid-cols-2 gap-3">
        {items.map((i) => (
          <div key={i.name} className="rounded-lg bg-white/[0.02] border border-white/5 p-4 flex items-center justify-between">
            <div>
              <div className="text-sm text-white font-medium">{i.name}</div>
              <div className="text-[11px] text-muted-foreground">{i.desc}</div>
            </div>
            {i.connected ? <StatusBadge status="ativo" /> : <Button variant="outline" size="sm" className="h-7 text-xs border-white/10">Conectar</Button>}
          </div>
        ))}
      </div>
    </div>
  );
}

function DomainsSection() {
  const { toast } = useToast();
  return (
    <div>
      <SectionHeader title="Domínios" desc="Use seu próprio domínio nos checkouts." />
      <div className="space-y-2 mb-4">
        {["checkout.sxpay.com", "pay.minhaloja.com.br"].map((d) => (
          <div key={d} className="flex items-center justify-between rounded-lg bg-white/[0.02] border border-white/5 p-3">
            <span className="text-sm text-white font-mono">{d}</span>
            <StatusBadge status="ativo" />
          </div>
        ))}
      </div>
      <div className="flex gap-2">
        <Input placeholder="meudominio.com.br" className="bg-background border-white/10 flex-1" />
        <Button onClick={() => toast({ title: "Domínio em verificação" })} className="bg-primary hover:bg-[#E10600]">Adicionar</Button>
      </div>
    </div>
  );
}

function NotificationsSection() {
  const items = [
    { label: "Venda aprovada", desc: "Receba notificação a cada venda", on: true },
    { label: "Chargeback aberto", desc: "Alerta de contestação", on: true },
    { label: "Saque processado", desc: "Status de saques", on: true },
    { label: "Resumo diário", desc: "E-mail com resumo do dia", on: false },
    { label: "Novo cliente", desc: "Quando um novo cliente compra", on: false }
  ];
  return (
    <div>
      <SectionHeader title="Notificações" desc="Escolha o que deseja receber." />
      <div className="space-y-2">
        {items.map((n) => (
          <div key={n.label} className="flex items-center justify-between rounded-lg bg-white/[0.02] border border-white/5 p-3">
            <div><div className="text-sm text-white">{n.label}</div><div className="text-[11px] text-muted-foreground">{n.desc}</div></div>
            <Toggle defaultOn={n.on} />
          </div>
        ))}
      </div>
    </div>
  );
}

function SecuritySection() {
  const { toast } = useToast();
  return (
    <div>
      <SectionHeader title="Segurança" desc="Proteja sua conta." />
      <div className="space-y-4">
        <Row label="Senha atual"><Input type="password" placeholder="••••••••" className="bg-background border-white/10" /></Row>
        <div className="grid sm:grid-cols-2 gap-4">
          <Row label="Nova senha"><Input type="password" placeholder="••••••••" className="bg-background border-white/10" /></Row>
          <Row label="Confirmar senha"><Input type="password" placeholder="••••••••" className="bg-background border-white/10" /></Row>
        </div>
        <div className="flex items-center justify-between rounded-lg bg-white/[0.02] border border-white/5 p-3">
          <div><div className="text-sm text-white">Autenticação em dois fatores</div><div className="text-[11px] text-muted-foreground">Proteção extra via app autenticador</div></div>
          <Toggle defaultOn={true} />
        </div>
        <div><Button onClick={() => toast({ title: "Segurança atualizada" })} className="bg-primary hover:bg-[#E10600]">Atualizar</Button></div>
      </div>
    </div>
  );
}

function Toggle({ defaultOn = false }) {
  const [on, setOn] = useState(defaultOn);
  return (
    <button onClick={() => setOn(!on)} className={cn("relative h-5 w-9 rounded-full transition-colors", on ? "bg-primary" : "bg-white/10")}>
      <span className="absolute top-0.5 h-4 w-4 rounded-full bg-white transition-all" style={{ left: on ? "18px" : "2px" }} />
    </button>
  );
}