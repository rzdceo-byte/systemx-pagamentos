import React, { useState, useEffect } from "react";
import { Plus, Pencil, Trash2, Copy, Check, Package, Image as ImageIcon } from "lucide-react";
import { Button } from "@/components/ui/button";
import StatusBadge from "@/components/ui/status-badge";
import EmptyState from "@/components/ui/empty-state";
import { CardSkeleton } from "@/components/ui/loading-skeleton";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { useApp } from "@/lib/AppContext";
import { formatCurrency } from "@/lib/mockData";
import { useToast } from "@/components/ui/use-toast";
import ProductEditor from "@/components/products/ProductEditor";
import { Image } from "@/components/ui/image";

export default function Products() {
  const { products, addProduct, updateProduct, deleteProduct } = useApp();
  const { toast } = useToast();
  const [loading, setLoading] = useState(true);
  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState(null);
  const [copiedId, setCopiedId] = useState(null);
  const [confirmDelete, setConfirmDelete] = useState(null);

  useEffect(() => {
    const t = setTimeout(() => setLoading(false), 500);
    return () => clearTimeout(t);
  }, []);

  const openNew = () => { setEditing(null); setModalOpen(true); };
  const openEdit = (p) => { setEditing(p); setModalOpen(true); };

  const copyLink = (id) => {
    const url = `${window.location.origin}/c/${id}`;
    navigator.clipboard.writeText(url);
    setCopiedId(id);
    toast({ title: "Link copiado", description: "Link de checkout copiado para a área de transferência." });
    setTimeout(() => setCopiedId(null), 2000);
  };

  return (
    <div className="space-y-5 max-w-[1400px] mx-auto">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <span className="text-[10px] uppercase tracking-[0.2em] text-primary font-semibold">Catálogo</span>
          <h2 className="font-display font-bold text-white text-2xl tracking-tight-display">Produtos</h2>
        </div>
        <Button onClick={openNew} className="bg-primary hover:bg-[#E10600] glow-red-sm gap-2">
          <Plus className="h-4 w-4" /> Novo produto
        </Button>
      </div>

      {loading ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {Array.from({ length: 6 }).map((_, i) => <CardSkeleton key={i} />)}
        </div>
      ) : products.length === 0 ? (
        <div className="rounded-xl surface glow-soft">
          <EmptyState icon={Package} title="Nenhum produto ainda" description="Crie seu primeiro produto e gere um link de checkout em segundos." action={<Button onClick={openNew} className="bg-primary hover:bg-[#E10600] gap-2"><Plus className="h-4 w-4" /> Criar produto</Button>} />
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {products.map((p) => (
            <div key={p.id} className="group rounded-xl surface glow-soft overflow-hidden transition-all hover:-translate-y-0.5 hover:glow-red-sm">
              <div className="relative h-40 bg-black/40 overflow-hidden">
                {p.image ? (
                  <Image src={p.image} alt={p.name} fittingType="fill" className="block h-full w-full opacity-80 group-hover:opacity-100 transition-opacity" />
                ) : (
                  <div className="h-full w-full flex items-center justify-center text-muted-foreground/40"><ImageIcon className="h-10 w-10" /></div>
                )}
                <div className="absolute inset-0 bg-gradient-to-t from-[#0D0D0D] via-transparent to-transparent" />
                <div className="absolute top-3 right-3"><StatusBadge status={p.status} /></div>
                <div className="absolute bottom-3 left-3">
                  <span className="font-display font-bold text-white text-xl tracking-tight-display">{formatCurrency(p.price)}</span>
                </div>
              </div>
              <div className="p-4">
                <h3 className="font-medium text-white text-sm leading-tight mb-3 line-clamp-2 min-h-[2.5rem]">{p.name}</h3>
                <div className="grid grid-cols-3 gap-2 mb-3 text-center">
                  <div><div className="text-xs text-white font-semibold tabular-nums">{p.sales}</div><div className="text-[10px] text-muted-foreground">Vendas</div></div>
                  <div><div className="text-xs text-white font-semibold tabular-nums">{formatCurrency(p.revenue).replace("R$", "").trim()}</div><div className="text-[10px] text-muted-foreground">Faturado</div></div>
                  <div><div className="text-xs text-success font-semibold tabular-nums">{p.conversion}%</div><div className="text-[10px] text-muted-foreground">Conv.</div></div>
                </div>
                <div className="flex items-center gap-1.5">
                  <button onClick={() => copyLink(p.id)} className="flex-1 flex items-center justify-center gap-1.5 rounded-md bg-white/5 hover:bg-white/10 py-1.5 text-xs text-white transition-colors">
                    {copiedId === p.id ? <Check className="h-3.5 w-3.5 text-success" /> : <Copy className="h-3.5 w-3.5" />}
                    {copiedId === p.id ? "Copiado" : "Link"}
                  </button>
                  <button onClick={() => openEdit(p)} className="flex h-8 w-8 items-center justify-center rounded-md bg-white/5 hover:bg-white/10 text-muted-foreground hover:text-white transition-colors"><Pencil className="h-3.5 w-3.5" /></button>
                  <button onClick={() => setConfirmDelete(p)} className="flex h-8 w-8 items-center justify-center rounded-md bg-white/5 hover:bg-[#E10600]/15 hover:text-[#FF6A4D] text-muted-foreground transition-colors"><Trash2 className="h-3.5 w-3.5" /></button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      <ProductEditor open={modalOpen} onOpenChange={setModalOpen} product={editing} onSave={(data) => {
        if (editing) { updateProduct(editing.id, data); toast({ title: "Produto atualizado" }); }
        else { addProduct(data); toast({ title: "Produto criado", description: "Gere o link de checkout na área de Checkout." }); }
        setModalOpen(false);
      }} />

      <Dialog open={!!confirmDelete} onOpenChange={(o) => !o && setConfirmDelete(null)}>
        <DialogContent className="bg-popover border-white/10">
          <DialogHeader><DialogTitle className="text-white">Excluir produto</DialogTitle></DialogHeader>
          <p className="text-sm text-muted-foreground">Tem certeza que deseja excluir <span className="text-white font-medium">{confirmDelete?.name}</span>? Esta ação não pode ser desfeita.</p>
          <DialogFooter>
            <Button variant="ghost" onClick={() => setConfirmDelete(null)}>Cancelar</Button>
            <Button variant="destructive" onClick={() => { deleteProduct(confirmDelete.id); toast({ title: "Produto excluído" }); setConfirmDelete(null); }}>Excluir</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}