import React, { useEffect, useState } from "react";
import { X, ChevronLeft, ChevronRight } from "lucide-react";

// Engine reutilizável de tour guiado (onboarding geral + ajuda por área).
// Overlay centralizado com backdrop escuro, card explicativo, progresso,
// navegação Anterior/Próximo e botão Pular (skip) sempre disponível.
export default function Tour({ open, steps, onClose, onComplete }) {
  const [index, setIndex] = useState(0);

  useEffect(() => { if (open) setIndex(0); }, [open]);

  useEffect(() => {
    if (!open) return;
    const onKey = (e) => {
      if (e.key === "Escape") onClose();
      else if (e.key === "ArrowRight") setIndex((i) => Math.min((steps?.length || 1) - 1, i + 1));
      else if (e.key === "ArrowLeft") setIndex((i) => Math.max(0, i - 1));
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open, steps, onClose]);

  if (!open || !steps?.length) return null;

  const total = steps.length;
  const step = steps[index];
  const isLast = index === total - 1;
  const Icon = step.icon;

  const finish = () => { onComplete?.(); onClose(); };
  const next = () => (isLast ? finish() : setIndex((i) => i + 1));

  return (
    <div className="fixed inset-0 z-[120] flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/82 backdrop-blur-[2px] animate-fade-in" onClick={onClose} />
      <div className="relative w-full max-w-md rounded-2xl border border-white/12 bg-[#0D0D0D] glow-soft p-6 animate-fade-in">
        <button onClick={onClose} className="absolute right-3 top-3 text-muted-foreground hover:text-white transition-colors" aria-label="Pular tour">
          <X className="h-4 w-4" />
        </button>

        <div className="flex items-center gap-3 mb-4">
          {Icon && (
            <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-primary/12 border border-primary/25 text-primary">
              <Icon className="h-4 w-4" />
            </span>
          )}
          <div>
            <div className="text-[10px] uppercase tracking-[0.2em] text-primary font-semibold">{step.kicker || "SXPay"}</div>
            <div className="text-[11px] text-muted-foreground">{index + 1} de {total}</div>
          </div>
        </div>

        <h3 className="font-display font-bold text-white text-lg tracking-tight-display mb-2 pr-6">{step.title}</h3>
        <p className="text-sm text-muted-foreground leading-relaxed">{step.body}</p>

        <div className="flex items-center gap-1.5 mt-5">
          {steps.map((_, i) => (
            <span key={i} className={`h-1.5 rounded-full transition-all ${i === index ? "w-6 bg-primary" : i < index ? "w-1.5 bg-primary/50" : "w-1.5 bg-white/15"}`} />
          ))}
        </div>

        <div className="flex items-center justify-between mt-5 pt-4 border-t border-white/8">
          <button onClick={onClose} className="text-xs text-muted-foreground hover:text-white transition-colors">Pular</button>
          <div className="flex items-center gap-2">
            <button onClick={() => setIndex((i) => Math.max(0, i - 1))} disabled={index === 0} className="inline-flex items-center gap-1 rounded-lg border border-white/10 px-3 py-1.5 text-xs text-muted-foreground hover:text-white hover:border-white/25 disabled:opacity-40 disabled:pointer-events-none transition-colors">
              <ChevronLeft className="h-3.5 w-3.5" /> Anterior
            </button>
            <button onClick={next} className="inline-flex items-center gap-1 rounded-lg bg-primary px-4 py-1.5 text-xs font-semibold text-white glow-red-sm hover:bg-[#E10600] transition-colors">
              {isLast ? "Concluir" : "Próximo"} {!isLast && <ChevronRight className="h-3.5 w-3.5" />}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}