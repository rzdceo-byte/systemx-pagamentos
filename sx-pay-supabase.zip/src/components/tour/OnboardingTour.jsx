import React, { useEffect, useState } from "react";
import Tour from "./Tour";
import { onboardingSteps } from "./tourContent";

const KEY = "sxp_onboarding_done";

export function isOnboardingDone() {
  try { return localStorage.getItem(KEY) === "1"; } catch { return false; }
}
export function markOnboardingDone() {
  try { localStorage.setItem(KEY, "1"); } catch { /* ignore */ }
}
// Dispara um evento que o OnboardingTour escuta para reabrir o tour a qualquer momento.
export function restartOnboarding() {
  try { localStorage.setItem(KEY, "0"); } catch { /* ignore */ }
  window.dispatchEvent(new Event("sxp:onboarding-restart"));
}

// Tour de primeiro acesso. Abre sozinho apenas quando a flag não está marcada;
// depois de concluir ou pular, nunca mais aparece automaticamente.
export default function OnboardingTour() {
  const [open, setOpen] = useState(false);

  useEffect(() => {
    if (!isOnboardingDone()) setOpen(true);
    const handler = () => setOpen(true);
    window.addEventListener("sxp:onboarding-restart", handler);
    return () => window.removeEventListener("sxp:onboarding-restart", handler);
  }, []);

  const close = () => { markOnboardingDone(); setOpen(false); };

  return (
    <Tour
      open={open}
      steps={onboardingSteps}
      onClose={close}
      onComplete={() => markOnboardingDone()}
    />
  );
}