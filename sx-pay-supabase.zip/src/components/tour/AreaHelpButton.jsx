import React, { useState } from "react";
import { useLocation } from "react-router-dom";
import Tour from "./Tour";
import { areaHelp } from "./tourContent";

const ROUTE_HELP = {
  "/": "dashboard",
  "/vendas": "vendas",
  "/checkout": "checkout",
  "/produtos": "produtos",
  "/clientes": "clientes",
  "/transacoes": "transacoes",
  "/recuperacao": "recuperacao",
  "/financeiro": "financeiro",
  "/relatorios": "relatorios",
  "/configuracoes": "configuracoes",
  "/bots/meus-bots": "bots",
  "/bots/fluxos": "fluxos",
  "/bots/wallet": "wallet",
  "/bots/relatorios": "botreports"
};

// Botão de ajuda contextual: círculo com "?" que abre um mini-tour específico da área atual.
// Disponível em todas as telas internas — pode ser acionado quantas vezes quiser.
export default function AreaHelpButton() {
  const location = useLocation();
  const [open, setOpen] = useState(false);
  const helpId = ROUTE_HELP[location.pathname];
  const help = helpId ? areaHelp[helpId] : null;
  if (!help) return null;

  return (
    <>
      <button
        onClick={() => setOpen(true)}
        title={`Ajuda — ${help.label}`}
        className="flex h-9 w-9 items-center justify-center rounded-full border border-white/12 text-muted-foreground hover:text-white hover:border-primary/50 hover:bg-white/5 transition-colors"
      >
        <span className="font-display font-bold text-sm leading-none">?</span>
      </button>
      <Tour open={open} steps={help.steps} onClose={() => setOpen(false)} />
    </>
  );
}