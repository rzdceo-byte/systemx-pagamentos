import {
  Sparkles, LayoutDashboard, ShoppingBag, CreditCard, Package, Users,
  Wallet, BarChart3, Bot, Settings as SettingsIcon, Receipt, LifeBuoy,
  Workflow, TrendingUp, Plug, MessageSquare
} from "lucide-react";

// Tour de primeiro acesso — 10 passos cobrindo toda a plataforma.
export const onboardingSteps = [
  {
    kicker: "Bem-vindo", icon: Sparkles,
    title: "Bem-vindo à SXPay",
    body: "A plataforma de pagamentos e checkout premium para produtores digitais. Vamos um rápido passeio pelas áreas principais — você pode pular quando quiser."
  },
  {
    kicker: "Cockpit", icon: LayoutDashboard,
    title: "Dashboard",
    body: "Seu painel de comando. Acompanhe o saldo disponível, faturamento, vendas e conversão. O botão \"Printar faturamento\" gera um card compartilhável da sua performance."
  },
  {
    kicker: "Vendas", icon: ShoppingBag,
    title: "Vendas",
    body: "Consulte todas as vendas com filtros por período, método e status. Acompanhe aprovações, recuperações e o desempenho por canal de origem."
  },
  {
    kicker: "Checkout", icon: CreditCard,
    title: "Checkout",
    body: "Crie checkouts a partir de templates (Clássico, Minimalista, Urgência, Vídeo) e personalize cores, ofertas, order bump e entrega digital."
  },
  {
    kicker: "Produtos", icon: Package,
    title: "Produtos",
    body: "Cadastre produtos com imagens, preços, planos e regras comerciais. Configure a entrega digital (links e mensagem) que o cliente recebe após a compra."
  },
  {
    kicker: "Clientes", icon: Users,
    title: "Clientes",
    body: "Veja clientes e leads, histórico de compras e origem. Reenvie o link de entrega de um produto digital direto pelo perfil do cliente."
  },
  {
    kicker: "Financeiro", icon: Wallet,
    title: "Financeiro",
    body: "Acompanhe saldo, recebível futuro e saques. Solicite retiradas e acompanhe o status de cada solicitação."
  },
  {
    kicker: "Relatórios", icon: BarChart3,
    title: "Relatórios",
    body: "Mapa de território de vendas, gráficos de receita, volume por método de pagamento e ranking de produtos para entender onde o dinheiro nasce."
  },
  {
    kicker: "Automação", icon: Bot,
    title: "Bots & Fluxos",
    body: "Gerencie bots do Telegram, construa fluxos visuais no canvas estilo n8n e acompanhe a Wallet Hot com extrato e saques separados do financeiro geral."
  },
  {
    kicker: "Conta", icon: SettingsIcon,
    title: "Configurações & Integrações",
    body: "Dados de perfil, empresa e banco, webhooks, chaves de API, integrações (Zapier, Analytics, Pixel) e domínios próprios para os checkouts."
  }
];

// Ajuda contextual por área — acionada pelo botão "?" no header. Conteúdo específico de cada tela.
export const areaHelp = {
  dashboard: {
    label: "Dashboard",
    steps: [
      { kicker: "Dashboard", icon: LayoutDashboard, title: "Saldo e KPIs", body: "O card de saldo disponível é o protagonista. Abaixo, KPIs de faturamento, vendas, conversão e ticket médio com indicadores de tendência." },
      { kicker: "Dashboard", icon: Sparkles, title: "Printar faturamento", body: "Gere um card compartilhável do seu resultado: escolha wallpaper, métrica protagonista, período e exporte em PNG ou compartilhe direto." },
      { kicker: "Dashboard", icon: TrendingUp, title: "Gráficos e feed", body: "Acompanhe a curva de faturamento, volume diário de vendas e o feed ao vivo de transações recentes." }
    ]
  },
  vendas: {
    label: "Vendas",
    steps: [
      { kicker: "Vendas", icon: ShoppingBag, title: "Lista de vendas", body: "Cada linha é uma venda com produto, cliente, valor, método e status. Use os filtros de período e método para refinar a visão." },
      { kicker: "Vendas", icon: TrendingUp, title: "Origem e canais", body: "A coluna de origem mostra de onde a venda veio (Direto, Tráfego, Bot) — útil para atribuir resultado a cada canal." }
    ]
  },
  checkout: {
    label: "Checkout",
    steps: [
      { kicker: "Checkout", icon: CreditCard, title: "Criar checkout", body: "Escolha um produto e um template (Clássico, Minimalista, Urgência, Vídeo). O template define a estrutura base da página." },
      { kicker: "Checkout", icon: Sparkles, title: "Personalizar", body: "Edite cores, tipografia, oferta, order bump, garantia e depoimentos. A pré-visualização reflete as mudanças em tempo real." },
      { kicker: "Checkout", icon: Package, title: "Publicar", body: "Publique o checkout para gerar o link público (/c/:id) que você divulga. Métricas de visitas e conversão são atualizadas sozinhas." }
    ]
  },
  produtos: {
    label: "Produtos",
    steps: [
      { kicker: "Produtos", icon: Package, title: "Cadastrar produto", body: "Defina nome, descrição, imagens (galeria) e preço. Você pode criar planos de assinatura e regras de afiliado." },
      { kicker: "Produtos", icon: MessageSquare, title: "Entrega digital", body: "Cadastre links de acesso e uma mensagem de entrega — o cliente recebe por e-mail após o pagamento aprovado." },
      { kicker: "Produtos", icon: CreditCard, title: "Checkout vinculado", body: "Cada produto pode ter vários checkouts. Gere um novo checkout direto pelo editor do produto." }
    ]
  },
  clientes: {
    label: "Clientes",
    steps: [
      { kicker: "Clientes", icon: Users, title: "Clientes e leads", body: "A lista mistura clientes que compraram e leads que abandonaram o checkout. O status mostra a diferença." },
      { kicker: "Clientes", icon: Package, title: "Reenviar entrega", body: "No detalhe do cliente, reenvie o link de entrega de um produto digital específico comprado por ele." }
    ]
  },
  transacoes: {
    label: "Transações",
    steps: [
      { kicker: "Transações", icon: Receipt, title: "Todas as transações", body: "Visão completa de transações (aprovadas, recusadas, estornadas) com busca e filtros. Use para conciliação e investigação de chargebacks." }
    ]
  },
  recuperacao: {
    label: "Recuperação",
    steps: [
      { kicker: "Recuperação", icon: LifeBuoy, title: "Carrinho abandonado", body: "Leads que preencheram dados mas não finalizaram aparecem aqui. Dispare e-mails de recuperação individualmente ou em lote." },
      { kicker: "Recuperação", icon: Sparkles, title: "Recuperação automática", body: "Ative a recuperação automática para enviar a sequência sozinha. O histórico mostra status de cada envio (enviado / simulado)." }
    ]
  },
  financeiro: {
    label: "Financeiro",
    steps: [
      { kicker: "Financeiro", icon: Wallet, title: "Saldo e recebível", body: "Veja o saldo disponível para saque e o recebível futuro (liberações programadas)." },
      { kicker: "Financeiro", icon: TrendingUp, title: "Solicitar saque", body: "Solicite retiradas para a conta bancária cadastrada. O status de cada saque é acompanhado nesta mesma tela." }
    ]
  },
  relatorios: {
    label: "Relatórios",
    steps: [
      { kicker: "Relatórios", icon: BarChart3, title: "Mapa de território", body: "Veja onde suas vendas acontecem no mapa, com volume por região." },
      { kicker: "Relatórios", icon: TrendingUp, title: "Gráficos", body: "Receita ao longo do tempo, volume por método de pagamento (PIX, cartão, boleto) e ranking de produtos mais vendidos." }
    ]
  },
  bots: {
    label: "Bots",
    steps: [
      { kicker: "Bots", icon: Bot, title: "Criar um bot", body: "Cadastre um bot do Telegram com nome, handle e avatar. Defina o compliance obrigatório (confirmação 18+ e termos de uso)." },
      { kicker: "Bots", icon: Workflow, title: "Vincular um fluxo", body: "Associe um fluxo do construtor ao bot para definir a conversa automatizada que ele executa." },
      { kicker: "Bots", icon: Wallet, title: "Wallet Hot", body: "Cada bot alimenta a Wallet Hot, com extrato e saques separados do financeiro geral da conta." }
    ]
  },
  fluxos: {
    label: "Fluxos",
    steps: [
      { kicker: "Fluxos", icon: Workflow, title: "Construtor visual", body: "Canvas infinito estilo n8n: arraste nós do painel, conecte e organize o fluxo de conversa do bot." },
      { kicker: "Fluxos", icon: Sparkles, title: "Tipos de nó", body: "Gatilhos (entrada), lógica (condição, atraso), conteúdo (mensagem, mídia) e comercial (oferta, pagamento)." },
      { kicker: "Fluxos", icon: Bot, title: "Testar e salvar", body: "Use o testador para simular a conversa e salve o fluxo para vincular a um bot." }
    ]
  },
  wallet: {
    label: "Wallet Hot",
    steps: [
      { kicker: "Wallet Hot", icon: Wallet, title: "Saldo da Wallet", body: "Saldo separado das vendas originadas por bots. Acompanhe a evolução e o total movimentado." },
      { kicker: "Wallet Hot", icon: Receipt, title: "Extrato e saque", body: "Veja cada transação de entrada e solicite saques diretamente da Wallet Hot." }
    ]
  },
  botreports: {
    label: "Relatórios do Bot",
    steps: [
      { kicker: "Relatórios do Bot", icon: BarChart3, title: "Funil do bot", body: "Métricas de funil: alcance, interação, conversão e receita por bot." },
      { kicker: "Relatórios do Bot", icon: TrendingUp, title: "Performance", body: "Compare bots e identifique quais fluxos geram mais resultado." }
    ]
  },
  configuracoes: {
    label: "Configurações",
    steps: [
      { kicker: "Configurações", icon: SettingsIcon, title: "Seções", body: "Navegue entre Perfil, Empresa, Banco, Webhooks, API, Integrações, Domínios, Notificações e Segurança pela coluna lateral." },
      { kicker: "Configurações", icon: Plug, title: "Integrações", body: "Conecte Zapier, Google Analytics, Facebook Pixel e Slack. Domínios próprios são configurados aqui para uso nos checkouts." },
      { kicker: "Configurações", icon: Sparkles, title: "Refazer tutorial", body: "No perfil há um botão para refazer o tutorial de primeiro acesso quando quiser rever a plataforma." }
    ]
  }
};