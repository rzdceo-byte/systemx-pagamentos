import React, { useState, useEffect } from "react";
import { Layout, Palette, MessageSquare, Flame, Package, CreditCard, Film, Users, Eye, Monitor, Smartphone, X } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import CheckoutPreview from "@/components/checkout/CheckoutPreview";
import { TabBar } from "@/components/shared/EditorControls";
import { TabModelo, TabIdentidade, TabMidia, TabCopy, TabGatilhos, TabOferta, TabLead, TabPagamento } from "@/components/checkout/CheckoutTabs";

const CHECKOUT_DEFAULTS = {
  template: "classico", mediaPosition: "topo",
  sections: { testimonials: false, warranty: true, faq: false, counter: false },
  colors: { background: "#0D0D0D", button: "#C10000", text: "#FFFFFF" },
  logoUrl: "", bannerUrl: "", fontFamily: "Space Grotesk",
  buttonText: "COMPRAR AGORA",
  warrantyText: "Garantia incondicional de 7 dias. Risco zero para você.",
  media: { type: "none", imageUrl: "", imageRatio: "paisagem", vslUrl: "", vslThumb: "", vslAutoplay: true, mediaOrder: "media-first" },
  leadCapture: { twoStep: false, consentRequired: true, consentText: "Li e concordo com os Termos de Uso e a Política de Privacidade." },
  testimonials: [], trustSeals: { secure: true, privacy: true, fast: true, warranty: true, verified: false }, faq: [],
  urgencyCounter: { enabled: false, minutes: 15, text: "Oferta expira em" },
  stockBar: { enabled: false, qty: 7, text: "Restam apenas 7 unidades" },
  socialProof: { enabled: false, text: "12 pessoas compraram nas últimas 2 horas" },
  coupon: { enabled: false, code: "", type: "percent", value: 10, expires: "" },
  orderBump: { name: "", price: 0, text: "", image: "", prechecked: true },
  upsell: { name: "", price: 0, discount: 0 },
  downsell: { enabled: false, name: "", price: 0, discount: 0 },
  payments: { maxInstallments: 12, pixDiscount: 0, requiredFields: { name: true, email: true, phone: true, cpf: true } }
};

const TABS = [
  { id: "modelo", label: "Modelo", icon: Layout },
  { id: "identidade", label: "Identidade", icon: Palette },
  { id: "midia", label: "Mídia", icon: Film },
  { id: "copy", label: "Copy & Confiança", icon: MessageSquare },
  { id: "gatilhos", label: "Gatilhos", icon: Flame },
  { id: "oferta", label: "Oferta", icon: Package },
  { id: "lead", label: "Leads", icon: Users },
  { id: "pagamento", label: "Pagamento", icon: CreditCard }
];

export default function CheckoutEditor({ data, products, onClose, onSave }) {
  const [form, setForm] = useState({ ...CHECKOUT_DEFAULTS, ...data });
  const [tab, setTab] = useState("modelo");
  const [device, setDevice] = useState("desktop");

  useEffect(() => { setForm({ ...CHECKOUT_DEFAULTS, ...data }); setTab("modelo"); }, [data]);

  const set = (key, value) => setForm((f) => ({ ...f, [key]: value }));
  const product = products.find((p) => p.id === form.productId);

  const save = (publish) => {
    onSave({ ...form, published: publish !== null ? publish : form.published });
  };

  return (
    <Dialog open onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="bg-popover border-white/10 max-w-6xl p-0 max-h-[92vh] overflow-y-auto lg:overflow-hidden">
        <div className="grid lg:grid-cols-[1fr_420px] lg:max-h-[88vh]">
          {/* Editor */}
          <div className="flex flex-col min-h-0">
            <DialogHeader className="px-6 pt-5 pb-3 flex-row items-center justify-between space-y-0">
              <DialogTitle className="text-white text-base">{form.isNew ? "Novo checkout" : "Editar checkout"}</DialogTitle>
              <button onClick={onClose} className="text-muted-foreground hover:text-white"><X className="h-4 w-4" /></button>
            </DialogHeader>

            <div className="px-6">
              <div className="grid grid-cols-2 gap-3 mb-4">
                <div className="space-y-1">
                  <span className="text-[11px] text-muted-foreground font-medium">Nome do checkout</span>
                  <input value={form.name} onChange={(e) => set("name", e.target.value)} className="w-full rounded-md bg-background border border-white/10 px-2.5 py-1.5 text-xs text-white focus:outline-none focus:border-primary/50" />
                </div>
                <div className="space-y-1">
                  <span className="text-[11px] text-muted-foreground font-medium">Produto</span>
                  <select value={form.productId} onChange={(e) => { const p = products.find((x) => x.id === e.target.value); setForm((f) => ({ ...f, productId: p.id, productName: p.name, productImage: p.image, price: p.promoPrice || p.price, headline: p.name })); }} className="w-full rounded-md bg-background border border-white/10 px-2.5 py-1.5 text-xs text-white focus:outline-none focus:border-primary/50">
                    {products.map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}
                  </select>
                </div>
              </div>
              <TabBar tabs={TABS} active={tab} onChange={setTab} />
            </div>

            <div className="overflow-y-auto px-6 py-4 space-y-3 lg:flex-1 min-h-0">
              {tab === "modelo" && <TabModelo form={form} set={set} />}
              {tab === "identidade" && <TabIdentidade form={form} set={set} />}
              {tab === "midia" && <TabMidia form={form} set={set} />}
              {tab === "copy" && <TabCopy form={form} set={set} />}
              {tab === "gatilhos" && <TabGatilhos form={form} set={set} />}
              {tab === "oferta" && <TabOferta form={form} set={set} />}
              {tab === "lead" && <TabLead form={form} set={set} />}
              {tab === "pagamento" && <TabPagamento form={form} set={set} />}
            </div>

            <div className="flex gap-2 px-6 py-4 border-t border-white/5">
              <Button variant="ghost" onClick={() => save(null)} className="flex-1">Salvar rascunho</Button>
              <Button onClick={() => save(true)} className="flex-1 bg-primary hover:bg-[#E10600]">Salvar e publicar</Button>
            </div>
          </div>

          {/* Preview ao vivo */}
          <div className="bg-black/40 flex flex-col min-h-0 border-l border-white/5">
            <div className="sticky top-0 z-10 flex items-center justify-between px-4 py-2.5 border-b border-white/5 bg-black/60 backdrop-blur">
              <span className="text-[10px] uppercase tracking-[0.15em] text-muted-foreground flex items-center gap-1.5"><Eye className="h-3 w-3" /> Preview ao vivo</span>
              <div className="flex gap-1 rounded-md bg-white/5 p-0.5">
                <button onClick={() => setDevice("desktop")} className={cn("flex h-6 w-7 items-center justify-center rounded transition-colors", device === "desktop" ? "bg-primary text-white" : "text-muted-foreground")}><Monitor className="h-3.5 w-3.5" /></button>
                <button onClick={() => setDevice("mobile")} className={cn("flex h-6 w-7 items-center justify-center rounded transition-colors", device === "mobile" ? "bg-primary text-white" : "text-muted-foreground")}><Smartphone className="h-3.5 w-3.5" /></button>
              </div>
            </div>
            <div className="overflow-y-auto p-4 lg:flex-1 min-h-0">
              <CheckoutPreview form={form} product={product} device={device} />
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}