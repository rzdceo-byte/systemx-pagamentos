import React from "react";
import { SectionCard, Field, Toggle, ColorField, ChipSelect, AddButton } from "@/components/shared/EditorControls";
import { Trash2, Image as ImageIcon, Film, Users } from "lucide-react";

const TEMPLATES = [
  { v: "classico", l: "Clássico" },
  { v: "minimalista", l: "Minimalista" },
  { v: "urgencia", l: "Urgência/Escassez" },
  { v: "video", l: "Vídeo em destaque" }
];
const FONTS = ["Space Grotesk", "Inter", "Roboto", "Montserrat"];
const SECTIONS = [
  { v: "testimonials", l: "Depoimentos" },
  { v: "warranty", l: "Garantia" },
  { v: "faq", l: "Perguntas frequentes" },
  { v: "counter", l: "Contador" }
];

// Aba 1 — Modelo e Layout
export function TabModelo({ form, set }) {
  const toggleSection = (v) => set("sections", { ...(form.sections || {}), [v]: !(form.sections || {})[v] });
  return (
    <>
      <SectionCard title="Template">
        <ChipSelect options={TEMPLATES} value={form.template} onChange={(v) => set("template", v)} />
      </SectionCard>
      <SectionCard title="Posição da mídia">
        <ChipSelect options={[{ v: "topo", l: "Topo" }, { v: "lateral", l: "Lateral" }]} value={form.mediaPosition || "topo"} onChange={(v) => set("mediaPosition", v)} />
      </SectionCard>
      <SectionCard title="Seções ativas">
        <div className="space-y-2">
          {SECTIONS.map((s) => (
            <Toggle key={s.v} checked={(form.sections || {})[s.v]} onChange={() => toggleSection(s.v)} label={s.l} />
          ))}
        </div>
      </SectionCard>
    </>
  );
}

// Aba 2 — Identidade Visual
export function TabIdentidade({ form, set }) {
  return (
    <>
      <div className="grid grid-cols-2 gap-3">
        <ColorField label="Cor primária (destaque)" value={form.accentColor} onChange={(v) => set("accentColor", v)} />
        <ColorField label="Cor de fundo" value={form.colors?.background} onChange={(v) => set("colors", { ...(form.colors || {}), background: v })} />
        <ColorField label="Cor do botão" value={form.colors?.button} onChange={(v) => set("colors", { ...(form.colors || {}), button: v })} />
        <ColorField label="Cor do texto" value={form.colors?.text} onChange={(v) => set("colors", { ...(form.colors || {}), text: v })} />
      </div>
      <Field label="Logo próprio (URL)" value={form.logoUrl} onChange={(v) => set("logoUrl", v)} placeholder="https://... Substitui o logo padrão" />
      <Field label="Banner / imagem de topo (URL)" value={form.bannerUrl} onChange={(v) => set("bannerUrl", v)} placeholder="https://..." />
      <SectionCard title="Fonte do checkout">
        <ChipSelect options={FONTS.map((f) => ({ v: f, l: f }))} value={form.fontFamily} onChange={(v) => set("fontFamily", v)} />
      </SectionCard>
    </>
  );
}

// Aba 2.5 — Mídia principal (VSL / Imagem)
const VSL_PROVIDERS = [
  { v: "youtube", l: "YouTube" },
  { v: "vimeo", l: "Vimeo" },
  { v: "panda", l: "Panda Video" },
  { v: "vturb", l: "VTurb" },
  { v: "file", l: "Arquivo direto (MP4)" },
  { v: "iframe", l: "iframe genérico" }
];

function parseVideoId(url) {
  if (!url) return null;
  const yt = url.match(/(?:youtube\.com\/(?:watch\?v=|embed\/)|youtu\.be\/)([\w-]{6,})/);
  if (yt) return { provider: "youtube", id: yt[1] };
  const vm = url.match(/vimeo\.com\/(\d+)/);
  if (vm) return { provider: "vimeo", id: vm[1] };
  return null;
}

export function TabMidia({ form, set }) {
  const media = form.media || {};
  const setMedia = (k, v) => set("media", { ...media, [k]: v });
  const parsed = parseVideoId(media.vslUrl);
  return (
    <>
      <SectionCard title="Tipo de mídia" icon={Film}>
        <ChipSelect
          options={[{ v: "none", l: "Nenhuma" }, { v: "image", l: "Imagem" }, { v: "vsl", l: "VSL (vídeo)" }]}
          value={media.type || "none"}
          onChange={(v) => setMedia("type", v)}
        />
        {media.type !== "none" && (
          <div className="pt-2">
            <span className="text-[11px] text-muted-foreground font-medium block mb-1">Ordem de exibição</span>
            <ChipSelect
              options={[{ v: "media-first", l: "Mídia acima da oferta" }, { v: "offer-first", l: "Oferta acima da mídia" }]}
              value={media.mediaOrder || "media-first"}
              onChange={(v) => setMedia("mediaOrder", v)}
            />
          </div>
        )}
      </SectionCard>

      {media.type === "image" && (
        <SectionCard title="Imagem principal" icon={ImageIcon}>
          <Field label="URL da imagem (JPG, PNG, WEBP, GIF)" value={media.imageUrl} onChange={(v) => setMedia("imageUrl", v)} placeholder="https://..." />
          {media.imageUrl && <img src={media.imageUrl} alt="" className="h-24 w-full object-cover rounded-md border border-white/10" />}
          <div>
            <span className="text-[11px] text-muted-foreground font-medium block mb-1">Proporção</span>
            <ChipSelect options={[{ v: "quadrada", l: "Quadrada" }, { v: "retrato", l: "Retrato" }, { v: "paisagem", l: "Paisagem" }]} value={media.imageRatio || "paisagem"} onChange={(v) => setMedia("imageRatio", v)} />
          </div>
        </SectionCard>
      )}

      {media.type === "vsl" && (
        <SectionCard title="VSL — Vídeo de vendas" icon={Film}>
          <Field label="Link do vídeo (YouTube, Vimeo, Panda, VTurb, iframe)" value={media.vslUrl} onChange={(v) => setMedia("vslUrl", v)} placeholder="https://youtube.com/watch?v=..." mono />
          <div>
            <span className="text-[11px] text-muted-foreground font-medium block mb-1">Provedor</span>
            <ChipSelect options={VSL_PROVIDERS} value={parsed?.provider || media.vslProvider || "youtube"} onChange={(v) => setMedia("vslProvider", v)} />
          </div>
          <Field label="Capa / thumbnail (URL) — opcional" value={media.vslThumb} onChange={(v) => setMedia("vslThumb", v)} placeholder="https://..." />
          <Toggle checked={media.vslAutoplay} onChange={(v) => setMedia("vslAutoplay", v)} label="Autoplay mudo" description="Inicia o vídeo automaticamente sem som" />
          {parsed?.provider === "youtube" && (
            <div className="rounded-md overflow-hidden border border-white/10">
              <div className="aspect-video bg-black">
                <iframe src={`https://www.youtube.com/embed/${parsed.id}?mute=1&autoplay=${media.vslAutoplay ? 1 : 0}&playsinline=1`} className="w-full h-full" allow="autoplay; encrypted-media" title="VSL preview" />
              </div>
            </div>
          )}
        </SectionCard>
      )}

      {media.type === "none" && <p className="text-[11px] text-muted-foreground rounded-md bg-background border border-white/10 p-3">Nenhuma mídia definida — o checkout funcionará normalmente sem quebrar o layout.</p>}
    </>
  );
}

// Aba 6.5 — Captura de Leads
export function TabLead({ form, set }) {
  const lead = form.leadCapture || {};
  const setLead = (k, v) => set("leadCapture", { ...lead, [k]: v });
  return (
    <>
      <SectionCard title="Checkout em etapas" icon={Users}>
        <Toggle checked={lead.twoStep} onChange={(v) => setLead("twoStep", v)} label="Checkout em 2 etapas" description="1: dados do lead → 2: pagamento. Quando ativo, o lead é capturado antes do pagamento." />
        {!lead.twoStep && <p className="text-[11px] text-muted-foreground">Em etapa única, nome/e-mail/telefone/CPF ficam na mesma tela do pagamento.</p>}
      </SectionCard>
      <SectionCard title="Consentimento">
        <Toggle checked={lead.consentRequired} onChange={(v) => setLead("consentRequired", v)} label="Exigir aceite de termos" description="Checkbox de Termos e Política de Privacidade obrigatório" />
        {lead.consentRequired && <Field label="Texto do consentimento" value={lead.consentText} onChange={(v) => setLead("consentText", v)} rows={2} />}
      </SectionCard>
      <div className="rounded-md bg-primary/[0.06] border border-primary/20 p-3">
        <div className="flex items-center gap-1.5 text-[11px] text-primary font-medium mb-1"><Users className="h-3.5 w-3.5" /> Recuperação de vendas</div>
        <p className="text-[11px] text-muted-foreground leading-relaxed">Todo lead que preencher os dados — mesmo sem finalizar a compra — é registrado na área de Clientes/Leads com status "Lead" (carrinho abandonado), permitindo futura recuperação.</p>
      </div>
    </>
  );
}

// Aba 3 — Copywriting e Confiança
export function TabCopy({ form, set }) {
  const addTestimonial = () => set("testimonials", [...(form.testimonials || []), { name: "Cliente", photo: "", rating: 5, text: "" }]);
  const addFaq = () => set("faq", [...(form.faq || []), { q: "Pergunta?", a: "Resposta." }]);
  return (
    <>
      <Field label="Texto do botão principal" value={form.buttonText} onChange={(v) => set("buttonText", v)} placeholder="Quero garantir minha vaga" />
      <Field label="Texto de garantia" value={form.warrantyText} onChange={(v) => set("warrantyText", v)} rows={2} />
      <SectionCard title="Depoimentos" action={<AddButton onClick={addTestimonial} />}>
        {(form.testimonials || []).length === 0 ? <p className="text-[11px] text-muted-foreground">Nenhum depoimento.</p> : (
          <div className="space-y-2">
            {(form.testimonials || []).map((t, i) => (
              <div key={i} className="rounded-md bg-background border border-white/10 p-2.5 space-y-2">
                <div className="grid grid-cols-[1fr_70px_auto] gap-2">
                  <Field label="Nome" value={t.name} onChange={(v) => set("testimonials", form.testimonials.map((x, idx) => idx === i ? { ...x, name: v } : x))} />
                  <Field label="Nota" type="number" value={t.rating} onChange={(v) => set("testimonials", form.testimonials.map((x, idx) => idx === i ? { ...x, rating: v } : x))} />
                  <button onClick={() => set("testimonials", form.testimonials.filter((_, idx) => idx !== i))} className="self-end h-8 w-8 rounded-md bg-white/5 hover:bg-[#E10600]/15 text-muted-foreground flex items-center justify-center"><Trash2 className="h-3.5 w-3.5" /></button>
                </div>
                <Field label="Foto (URL)" value={t.photo} onChange={(v) => set("testimonials", form.testimonials.map((x, idx) => idx === i ? { ...x, photo: v } : x))} />
                <Field label="Depoimento" value={t.text} onChange={(v) => set("testimonials", form.testimonials.map((x, idx) => idx === i ? { ...x, text: v } : x))} rows={2} />
              </div>
            ))}
          </div>
        )}
      </SectionCard>
      <SectionCard title="Selos de confiança">
        <div className="grid grid-cols-1 gap-2">
          {[{ v: "secure", l: "Pagamento seguro" }, { v: "privacy", l: "Dados protegidos" }, { v: "fast", l: "Aprovação rápida" }, { v: "warranty", l: "Garantia" }, { v: "verified", l: "Compra verificada" }].map((s) => (
            <Toggle key={s.v} checked={(form.trustSeals || {})[s.v]} onChange={() => set("trustSeals", { ...(form.trustSeals || {}), [s.v]: !(form.trustSeals || {})[s.v] })} label={s.l} />
          ))}
        </div>
      </SectionCard>
      <SectionCard title="Perguntas frequentes" action={<AddButton onClick={addFaq} />}>
        {(form.faq || []).length === 0 ? <p className="text-[11px] text-muted-foreground">Nenhuma pergunta.</p> : (
          <div className="space-y-2">
            {(form.faq || []).map((f, i) => (
              <div key={i} className="rounded-md bg-background border border-white/10 p-2.5 space-y-2">
                <div className="grid grid-cols-[1fr_auto] gap-2">
                  <Field label="Pergunta" value={f.q} onChange={(v) => set("faq", form.faq.map((x, idx) => idx === i ? { ...x, q: v } : x))} />
                  <button onClick={() => set("faq", form.faq.filter((_, idx) => idx !== i))} className="self-end h-8 w-8 rounded-md bg-white/5 hover:bg-[#E10600]/15 text-muted-foreground flex items-center justify-center"><Trash2 className="h-3.5 w-3.5" /></button>
                </div>
                <Field label="Resposta" value={f.a} onChange={(v) => set("faq", form.faq.map((x, idx) => idx === i ? { ...x, a: v } : x))} rows={2} />
              </div>
            ))}
          </div>
        )}
      </SectionCard>
    </>
  );
}

// Aba 4 — Gatilhos de Conversão
export function TabGatilhos({ form, set }) {
  return (
    <>
      <Toggle checked={form.urgencyCounter?.enabled} onChange={(v) => set("urgencyCounter", { ...(form.urgencyCounter || {}), enabled: v })} label="Contador de urgência" description="Cronômetro regressivo na página" />
      {form.urgencyCounter?.enabled && (
        <div className="grid grid-cols-2 gap-3">
          <Field label="Minutos" type="number" value={form.urgencyCounter?.minutes} onChange={(v) => set("urgencyCounter", { ...form.urgencyCounter, minutes: v })} />
          <Field label="Texto" value={form.urgencyCounter?.text} onChange={(v) => set("urgencyCounter", { ...form.urgencyCounter, text: v })} />
        </div>
      )}
      <Toggle checked={form.stockBar?.enabled} onChange={(v) => set("stockBar", { ...(form.stockBar || {}), enabled: v })} label="Barra de estoque limitado" description="Mostra unidades restantes" />
      {form.stockBar?.enabled && (
        <div className="grid grid-cols-2 gap-3">
          <Field label="Quantidade" type="number" value={form.stockBar?.qty} onChange={(v) => set("stockBar", { ...form.stockBar, qty: v })} />
          <Field label="Texto" value={form.stockBar?.text} onChange={(v) => set("stockBar", { ...form.stockBar, text: v })} />
        </div>
      )}
      <Toggle checked={form.socialProof?.enabled} onChange={(v) => set("socialProof", { ...(form.socialProof || {}), enabled: v })} label="Notificação de prova social" description="Ex: 12 pessoas compraram nas últimas 2h (simulado)" />
      {form.socialProof?.enabled && <Field label="Texto" value={form.socialProof?.text} onChange={(v) => set("socialProof", { ...form.socialProof, text: v })} />}
      <Toggle checked={form.coupon?.enabled} onChange={(v) => set("coupon", { ...(form.coupon || {}), enabled: v })} label="Cupom de desconto" />
      {form.coupon?.enabled && (
        <div className="grid grid-cols-2 gap-3">
          <Field label="Código" value={form.coupon?.code} onChange={(v) => set("coupon", { ...form.coupon, code: v })} />
          <div className="space-y-1">
            <span className="text-[11px] text-muted-foreground font-medium">Tipo</span>
            <ChipSelect options={[{ v: "percent", l: "%" }, { v: "fixed", l: "R$" }]} value={form.coupon?.type} onChange={(v) => set("coupon", { ...form.coupon, type: v })} />
          </div>
          <Field label="Valor" type="number" value={form.coupon?.value} onChange={(v) => set("coupon", { ...form.coupon, value: v })} />
          <Field label="Validade" value={form.coupon?.expires} onChange={(v) => set("coupon", { ...form.coupon, expires: v })} placeholder="2026-12-31" />
        </div>
      )}
    </>
  );
}

// Aba 5 — Oferta
export function TabOferta({ form, set }) {
  return (
    <>
      <SectionCard title="Order Bump">
        <Toggle checked={form.hasOrderBump} onChange={(v) => set("hasOrderBump", v)} label="Ativar order bump" />
        {form.hasOrderBump && (
          <div className="space-y-2">
            <Field label="Nome da oferta" value={form.orderBump?.name} onChange={(v) => set("orderBump", { ...form.orderBump, name: v })} />
            <Field label="Texto da oferta" value={form.orderBump?.text} onChange={(v) => set("orderBump", { ...form.orderBump, text: v })} />
            <div className="grid grid-cols-2 gap-2">
              <Field label="Preço" type="number" value={form.orderBump?.price} onChange={(v) => set("orderBump", { ...form.orderBump, price: v })} />
              <Field label="Imagem (URL)" value={form.orderBump?.image} onChange={(v) => set("orderBump", { ...form.orderBump, image: v })} />
            </div>
            <Toggle checked={form.orderBump?.prechecked} onChange={(v) => set("orderBump", { ...form.orderBump, prechecked: v })} label="Checkbox pré-marcado" />
          </div>
        )}
      </SectionCard>
      <SectionCard title="Upsell pós-compra">
        <Toggle checked={form.hasUpsell} onChange={(v) => set("hasUpsell", v)} label="Ativar upsell" />
        {form.hasUpsell && (
          <div className="grid grid-cols-2 gap-2">
            <Field label="Produto" value={form.upsell?.name} onChange={(v) => set("upsell", { ...form.upsell, name: v })} />
            <Field label="Preço" type="number" value={form.upsell?.price} onChange={(v) => set("upsell", { ...form.upsell, price: v })} />
            <Field label="Desconto especial (%)" type="number" value={form.upsell?.discount} onChange={(v) => set("upsell", { ...form.upsell, discount: v })} />
          </div>
        )}
      </SectionCard>
      <SectionCard title="Downsell (se upsell recusado)">
        <Toggle checked={form.downsell?.enabled} onChange={(v) => set("downsell", { ...(form.downsell || {}), enabled: v })} label="Ativar downsell" />
        {form.downsell?.enabled && (
          <div className="grid grid-cols-2 gap-2">
            <Field label="Produto alternativo" value={form.downsell?.name} onChange={(v) => set("downsell", { ...form.downsell, name: v })} />
            <Field label="Preço" type="number" value={form.downsell?.price} onChange={(v) => set("downsell", { ...form.downsell, price: v })} />
            <Field label="Desconto (%)" type="number" value={form.downsell?.discount} onChange={(v) => set("downsell", { ...form.downsell, discount: v })} />
          </div>
        )}
      </SectionCard>
    </>
  );
}

// Aba 6 — Pagamento
export function TabPagamento({ form, set }) {
  const toggleMethod = (m) => set("methods", (form.methods || []).includes(m) ? form.methods.filter((x) => x !== m) : [...(form.methods || []), m]);
  const toggleReq = (f) => set("payments", { ...(form.payments || {}), requiredFields: { ...(form.payments?.requiredFields || {}), [f]: !(form.payments?.requiredFields || {})[f] } });
  return (
    <>
      <SectionCard title="Métodos habilitados">
        <ChipSelect multi options={[{ v: "pix", l: "PIX" }, { v: "card", l: "Cartão de crédito" }, { v: "boleto", l: "Boleto" }]} value={form.methods} onChange={toggleMethod} />
      </SectionCard>
      <div className="grid grid-cols-2 gap-3">
        <Field label="Parcelamento máximo (x)" type="number" value={form.payments?.maxInstallments} onChange={(v) => set("payments", { ...(form.payments || {}), maxInstallments: v })} />
        <Field label="Desconto PIX (%)" type="number" value={form.payments?.pixDiscount} onChange={(v) => set("payments", { ...(form.payments || {}), pixDiscount: v })} />
      </div>
      <SectionCard title="Campos obrigatórios do formulário">
        <div className="grid grid-cols-2 gap-2">
          {[{ v: "name", l: "Nome" }, { v: "email", l: "E-mail" }, { v: "phone", l: "Telefone" }, { v: "cpf", l: "CPF" }].map((f) => (
            <Toggle key={f.v} checked={(form.payments?.requiredFields || {})[f.v]} onChange={() => toggleReq(f.v)} label={f.l} />
          ))}
        </div>
      </SectionCard>
    </>
  );
}