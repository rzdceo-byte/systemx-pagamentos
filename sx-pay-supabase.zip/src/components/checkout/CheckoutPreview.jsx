import React from "react";
import { Lock, Shield, Zap, Check, QrCode, CreditCard, Barcode, Star, Clock, Users, Film, ChevronRight } from "lucide-react";
import { formatCurrency } from "@/lib/mockData";
import { cn } from "@/lib/utils";

function parseVideoId(url) {
  if (!url) return null;
  const yt = url.match(/(?:youtube\.com\/(?:watch\?v=|embed\/)|youtu\.be\/)([\w-]{6,})/);
  if (yt) return { provider: "youtube", id: yt[1] };
  const vm = url.match(/vimeo\.com\/(\d+)/);
  if (vm) return { provider: "vimeo", id: vm[1] };
  return null;
}

// Preview ao vivo do checkout — reflete TODAS as abas do builder e o template escolhido
export default function CheckoutPreview({ form, product, device = "desktop" }) {
  const template = form.template || "classico";
  const accent = form.accentColor || "#C10000";
  const bg = form.colors?.background || "#0D0D0D";
  const textColor = form.colors?.text || "#FFFFFF";
  const btnColor = form.colors?.button || accent;
  const font = form.fontFamily || "Space Grotesk";
  const fontFamily = `'${font}', sans-serif`;
  const media = form.media || {};
  const lead = form.leadCapture || {};

  const effectivePrice = form.promoPrice || form.price;
  const discountPct = form.promoPrice && form.price > form.promoPrice ? Math.round((1 - form.promoPrice / form.price) * 100) : 0;

  const showTestimonials = form.sections?.testimonials && (form.testimonials || []).length > 0;
  const showFaq = form.sections?.faq && (form.faq || []).length > 0;
  const showWarranty = form.sections?.warranty;
  const showCounter = form.sections?.counter && form.urgencyCounter?.enabled;
  const showStock = form.stockBar?.enabled;
  const showSocial = form.socialProof?.enabled;
  const isTwoStep = lead.twoStep;
  const headline = form.headline || form.productName || form.name;

  const containerCls = device === "mobile" ? "max-w-[320px] mx-auto pb-14" : "w-full";

  const MediaBlock = media.type === "vsl" ? (
    <VslBlock media={media} accent={accent} />
  ) : media.type === "image" ? (
    <img src={media.imageUrl} alt="" className="w-full object-cover rounded-lg" style={{ height: media.imageRatio === "retrato" ? 220 : media.imageRatio === "quadrada" ? 150 : 120 }} />
  ) : null;

  const OfferBlock = (
    <>
      <div className="flex gap-3">
        {form.mediaPosition === "lateral" && form.productImage && (
          <img src={form.productImage} alt="" className="w-24 h-24 object-cover rounded-lg shrink-0" />
        )}
        <div className="min-w-0">
          <h3 className="font-bold text-sm leading-tight mb-1">{headline}</h3>
          {form.description && <p className="text-[11px] opacity-60 mb-2 leading-relaxed">{form.description}</p>}
        </div>
      </div>

      <div className="flex items-baseline gap-2 mb-2 mt-2">
        {discountPct > 0 && <span className="text-[11px] line-through opacity-40">{formatCurrency(form.price)}</span>}
        <span className="font-bold text-2xl tracking-tight" style={{ color: accent }}>{formatCurrency(effectivePrice)}</span>
        {discountPct > 0 && <span className="text-[10px] px-1.5 py-0.5 rounded font-bold" style={{ background: accent + "22", color: accent }}>{discountPct}% OFF</span>}
      </div>
      {form.payments?.maxInstallments > 1 && (
        <p className="text-[10px] opacity-50 mb-2">ou {form.payments.maxInstallments}x de {formatCurrency(effectivePrice / form.payments.maxInstallments)}</p>
      )}

      {form.hasOrderBump && (
        <div className="rounded-lg border p-2.5 mb-3 flex items-start gap-2" style={{ borderColor: accent + "40", background: accent + "0A" }}>
          <input type="checkbox" defaultChecked={form.orderBump?.prechecked} className="mt-0.5 h-3.5 w-3.5" style={{ accentColor: accent }} />
          <div className="flex-1 min-w-0">
            <div className="text-[11px] font-medium">{form.orderBump?.name}</div>
            {form.orderBump?.text && <div className="text-[10px] opacity-60">{form.orderBump.text}</div>}
            <div className="text-[10px] opacity-60">+ {formatCurrency(form.orderBump?.price || 0)}</div>
          </div>
          {form.orderBump?.image && <img src={form.orderBump.image} alt="" className="h-10 w-10 rounded object-cover shrink-0" />}
        </div>
      )}

      <div className="flex flex-wrap gap-1.5 mb-3">
        {form.methods?.includes("pix") && <Pill icon={QrCode} label="PIX" accent={accent} />}
        {form.methods?.includes("card") && <Pill icon={CreditCard} label="Cartão" accent={accent} />}
        {form.methods?.includes("boleto") && <Pill icon={Barcode} label="Boleto" accent={accent} />}
      </div>

      {/* Formulário de lead — sempre presente (4 campos) */}
      <div className="rounded-lg border border-white/10 bg-white/[0.02] p-2.5 mb-3 space-y-1.5">
        <div className="flex items-center gap-1 text-[9px] opacity-50 mb-0.5"><span className="h-4 w-4 rounded-full flex items-center justify-center text-[8px] font-bold" style={{ background: accent, color: "#fff" }}>1</span> Seus dados</div>
        <input readOnly placeholder="Nome completo" className="w-full rounded-md bg-white/5 border border-white/10 px-2 py-1.5 text-[10px]" />
        <input readOnly placeholder="E-mail" className="w-full rounded-md bg-white/5 border border-white/10 px-2 py-1.5 text-[10px]" />
        <div className="flex gap-1.5">
          <input readOnly placeholder="Telefone" className="flex-1 rounded-md bg-white/5 border border-white/10 px-2 py-1.5 text-[10px]" />
          <input readOnly placeholder="CPF" className="flex-1 rounded-md bg-white/5 border border-white/10 px-2 py-1.5 text-[10px]" />
        </div>
        {isTwoStep && lead.consentRequired && <div className="flex items-center gap-1.5 text-[9px] opacity-50"><input type="checkbox" className="h-2.5 w-2.5" /> Aceito os termos</div>}
      </div>

      <button className="w-full rounded-lg py-2.5 text-xs font-bold text-white flex items-center justify-center gap-1.5" style={{ background: btnColor, boxShadow: `0 0 20px -4px ${btnColor}` }}>
        {form.buttonText || "COMPRAR AGORA"}
        {isTwoStep && <><ChevronRight className="h-3.5 w-3.5" /> Pagamento</>}
      </button>

      <div className="flex flex-wrap items-center justify-center gap-2 mt-3 text-[8px] opacity-50">
        {form.trustSeals?.secure && <span className="flex items-center gap-0.5"><Lock className="h-2.5 w-2.5" /> Pagamento seguro</span>}
        {form.trustSeals?.privacy && <span className="flex items-center gap-0.5"><Shield className="h-2.5 w-2.5" /> Dados protegidos</span>}
        {form.trustSeals?.fast && <span className="flex items-center gap-0.5"><Zap className="h-2.5 w-2.5" /> Aprovação rápida</span>}
        {form.trustSeals?.verified && <span className="flex items-center gap-0.5"><Check className="h-2.5 w-2.5" /> Compra verificada</span>}
      </div>

      {showWarranty && (
        <div className="rounded-lg border border-white/5 bg-white/[0.02] p-2.5 mt-3 text-center">
          <Shield className="h-4 w-4 mx-auto mb-1" style={{ color: accent }} />
          <p className="text-[9px] opacity-60 leading-tight">{form.warrantyText}</p>
        </div>
      )}

      {showTestimonials && (
        <div className="mt-3 space-y-2">
          {(form.testimonials || []).slice(0, 2).map((t, i) => (
            <div key={i} className="rounded-lg bg-white/[0.02] border border-white/5 p-2.5">
              <div className="flex items-center gap-2 mb-1">
                {t.photo ? <img src={t.photo} alt="" className="h-6 w-6 rounded-full object-cover" /> : <div className="h-6 w-6 rounded-full bg-white/10 flex items-center justify-center text-[9px]">{t.name?.[0]}</div>}
                <div className="flex-1 min-w-0"><div className="text-[10px] font-medium truncate">{t.name}</div><div className="flex">{Array.from({ length: t.rating || 5 }).map((_, s) => <Star key={s} className="h-2.5 w-2.5" style={{ color: accent, fill: accent }} />)}</div></div>
              </div>
              <p className="text-[9px] opacity-60 leading-tight">"{t.text}"</p>
            </div>
          ))}
        </div>
      )}

      {showFaq && (
        <div className="mt-3 space-y-1.5">
          {(form.faq || []).slice(0, 3).map((f, i) => (
            <div key={i} className="rounded-md bg-white/[0.02] border border-white/5 p-2">
              <div className="text-[10px] font-medium">{f.q}</div>
              <div className="text-[9px] opacity-60 mt-0.5 leading-tight">{f.a}</div>
            </div>
          ))}
        </div>
      )}

      {form.coupon?.enabled && (
        <div className="mt-3 flex gap-1.5">
          <input readOnly value={form.coupon.code} placeholder="Cupom" className="flex-1 rounded-md bg-white/5 border border-white/10 px-2 py-1.5 text-[10px] font-mono" />
          <button className="rounded-md px-2.5 py-1.5 text-[10px] font-bold text-white" style={{ background: accent }}>Aplicar</button>
        </div>
      )}
    </>
  );

  const UrgencyTop = (
    <div className="space-y-2 p-3 border-b" style={{ borderColor: "rgba(255,255,255,0.06)" }}>
      {showCounter && (
        <div className="rounded-lg border px-2.5 py-1.5 flex items-center gap-1.5" style={{ borderColor: accent + "40", background: accent + "0A" }}>
          <Clock className="h-3 w-3" style={{ color: accent }} />
          <span className="text-[10px] font-medium" style={{ color: accent }}>{form.urgencyCounter.text} <b>14:59</b></span>
        </div>
      )}
      {showStock && (
        <div>
          <div className="flex justify-between text-[9px] opacity-60 mb-1"><span>{form.stockBar.text}</span><span>{form.stockBar.qty} un.</span></div>
          <div className="h-1.5 rounded-full bg-white/10 overflow-hidden"><div className="h-full rounded-full" style={{ width: "30%", background: accent }} /></div>
        </div>
      )}
      {showSocial && (
        <div className="rounded-md bg-white/[0.03] border border-white/5 px-2.5 py-1.5 flex items-center gap-1.5">
          <Users className="h-3 w-3" style={{ color: accent }} />
          <span className="text-[9px] opacity-70">{form.socialProof.text}</span>
        </div>
      )}
    </div>
  );

  const HeaderBar = form.bannerUrl && template !== "minimalista" ? (
    <img src={form.bannerUrl} alt="" className="w-full h-20 object-cover" />
  ) : (
    <div className="flex items-center justify-between px-4 py-3 border-b" style={{ borderColor: "rgba(255,255,255,0.06)" }}>
      {form.logoUrl ? (
        <img src={form.logoUrl} alt="" className="h-6 object-contain" />
      ) : (
        <div className="flex items-center gap-2">
          <div className="h-6 w-6 rounded flex items-center justify-center font-bold text-[10px]" style={{ background: accent, color: "#fff" }}>69</div>
          <span className="font-bold text-xs">SX<span style={{ color: accent }}>Pay</span></span>
        </div>
      )}
      <Lock className="h-3 w-3" style={{ opacity: 0.5 }} />
    </div>
  );

  const Footer = (
    <div className="px-4 pb-4 pt-3 border-t text-center text-[8px] opacity-30" style={{ borderColor: "rgba(255,255,255,0.06)" }}>
      Processado com segurança por <span className="font-bold">SXPay</span>
    </div>
  );

  const StickyCta = device === "mobile" && (
    <div className="sticky bottom-0 -mx-px mt-2 rounded-b-xl border border-t-0 border-white/10 px-3 py-2 flex items-center justify-between gap-2" style={{ background: bg }}>
      <div>
        <div className="text-[9px] opacity-50">{headline}</div>
        <div className="font-bold text-sm" style={{ color: accent }}>{formatCurrency(effectivePrice)}</div>
      </div>
      <button className="rounded-lg px-4 py-2 text-[11px] font-bold text-white flex items-center gap-1" style={{ background: btnColor }}>
        {form.buttonText || "COMPRAR"} <ChevronRight className="h-3.5 w-3.5" />
      </button>
    </div>
  );

  // --- Layout por template ---
  let body;
  if (template === "minimalista") {
    body = (
      <div className="rounded-xl overflow-hidden border border-white/10 relative" style={{ background: bg, color: textColor }}>
        {HeaderBar}
        <div className="px-4 pt-5 pb-4">
          <div className="text-center mb-3">
            <h3 className="font-bold text-base leading-tight">{headline}</h3>
            {form.description && <p className="text-[10px] opacity-60 mt-1">{form.description}</p>}
          </div>
          {OfferBlock}
        </div>
        {Footer}
      </div>
    );
  } else if (template === "video") {
    body = (
      <div className="rounded-xl overflow-hidden border border-white/10 relative" style={{ background: bg, color: textColor }}>
        {HeaderBar}
        {media.type === "vsl" && (
          <div className="px-3 pt-3"><VslBlock media={media} accent={accent} full /></div>
        )}
        {showSocial && (
          <div className="px-4 pt-3">
            <div className="rounded-md bg-white/[0.03] border border-white/5 px-2.5 py-1.5 flex items-center gap-1.5">
              <Users className="h-3 w-3" style={{ color: accent }} />
              <span className="text-[9px] opacity-70">{form.socialProof.text}</span>
            </div>
          </div>
        )}
        <div className="p-4">{OfferBlock}</div>
        {Footer}
      </div>
    );
  } else if (template === "urgencia") {
    body = (
      <div className="rounded-xl overflow-hidden border border-white/10 relative" style={{ background: bg, color: textColor }}>
        {UrgencyTop}
        {HeaderBar}
        <div className="p-4">
          {media.type !== "none" && media.mediaOrder !== "offer-first" && MediaBlock && <div className="mb-3">{MediaBlock}</div>}
          {OfferBlock}
          {media.type !== "none" && media.mediaOrder === "offer-first" && MediaBlock && <div className="mt-3">{MediaBlock}</div>}
        </div>
        {Footer}
      </div>
    );
  } else {
    // clássico
    const mediaOrder = media.mediaOrder || "media-first";
    body = (
      <div className="rounded-xl overflow-hidden border border-white/10 relative" style={{ background: bg, color: textColor }}>
        {HeaderBar}
        {showCounter && (
          <div className="px-4 pt-3">
            <div className="rounded-lg border px-2.5 py-1.5 flex items-center gap-1.5" style={{ borderColor: accent + "40", background: accent + "0A" }}>
              <Clock className="h-3 w-3" style={{ color: accent }} />
              <span className="text-[10px]" style={{ color: accent }}>{form.urgencyCounter.text} <b>14:59</b></span>
            </div>
          </div>
        )}
        {showSocial && (
          <div className="px-4 pt-3">
            <div className="rounded-md bg-white/[0.03] border border-white/5 px-2.5 py-1.5 flex items-center gap-1.5">
              <Users className="h-3 w-3" style={{ color: accent }} />
              <span className="text-[9px] opacity-70">{form.socialProof.text}</span>
            </div>
          </div>
        )}
        <div className="p-4">
          {mediaOrder === "media-first" && MediaBlock && <div className="mb-3">{MediaBlock}</div>}
          {media.type === "none" && form.productImage && form.mediaPosition !== "lateral" && (
            <img src={form.productImage} alt="" className="w-full h-32 object-cover rounded-lg mb-3" />
          )}
          {OfferBlock}
          {mediaOrder === "offer-first" && MediaBlock && <div className="mt-3">{MediaBlock}</div>}
        </div>
        {Footer}
      </div>
    );
  }

  return (
    <div className={containerCls} style={{ fontFamily }}>
      {body}
      {StickyCta}
    </div>
  );
}

function VslBlock({ media, accent, full }) {
  const parsed = parseVideoId(media.vslUrl);
  return (
    <div className={cn("relative rounded-lg overflow-hidden border border-white/10 bg-black", full && "border-0")}>
      <div className="aspect-video relative">
        {media.vslThumb && !parsed && <img src={media.vslThumb} alt="" className="absolute inset-0 w-full h-full object-cover opacity-60" />}
        {parsed?.provider === "youtube" ? (
          <iframe src={`https://www.youtube.com/embed/${parsed.id}?mute=1&autoplay=${media.vslAutoplay ? 1 : 0}&playsinline=1`} className="w-full h-full" allow="autoplay; encrypted-media" title="VSL" />
        ) : (
          <div className="absolute inset-0 flex flex-col items-center justify-center gap-1.5">
            <div className="h-9 w-9 rounded-full flex items-center justify-center" style={{ background: accent }}>
              <Film className="h-4 w-4 text-white" />
            </div>
            <span className="text-[9px] opacity-50">VSL · {parsed?.provider || "player"}</span>
          </div>
        )}
      </div>
    </div>
  );
}

function Pill({ icon: Icon, label, accent }) {
  return <span className="text-[9px] px-2 py-0.5 rounded bg-white/5 flex items-center gap-1"><Icon className="h-2.5 w-2.5" style={{ color: accent }} /> {label}</span>;
}