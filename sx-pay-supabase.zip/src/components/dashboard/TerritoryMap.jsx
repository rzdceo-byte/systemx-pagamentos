import React, { useEffect, useMemo, useState } from "react";
import { MapContainer, GeoJSON, useMap } from "react-leaflet";
import L from "leaflet";
import "leaflet/dist/leaflet.css";
import { Globe2, ArrowLeft, Users, MapPin, Settings2 } from "lucide-react";
import { Link } from "react-router-dom";
import { getTerritoryData, formatCurrency } from "@/lib/mockData";
import { cn } from "@/lib/utils";

// GeoJSON simplificado (baixado em runtime e cacheado).
const WORLD_URL =
  "https://cdn.jsdelivr.net/gh/nvkelso/natural-earth-vector@master/geojson/ne_110m_admin_0_countries.geojson";
const BRA_URL =
  "https://cdn.jsdelivr.net/gh/codeforgermany/click_that_hood@main/public/data/brazil-states.geojson";

const _geoCache = {};
async function loadGeo(url) {
  if (_geoCache[url]) return _geoCache[url];
  const res = await fetch(url);
  if (!res.ok) throw new Error("mapa indisponível");
  const json = await res.json();
  _geoCache[url] = json;
  return json;
}

function countryName(feat) {
  const p = feat.properties || {};
  return p.ADMIN || p.NAME || p.name || p.SOVEREIGNT || "";
}
function stateName(feat) {
  const p = feat.properties || {};
  return p.name || p.NAME_1 || p.NM_ESTADO || p.estado || "";
}

// Gradiente vermelho sangue #8A0303 -> #E10600 conforme intensidade (0..1)
function heatColor(ratio) {
  const r = Math.round(138 + (225 - 138) * ratio);
  const g = Math.round(3 + (6 - 3) * ratio);
  const b = Math.round(3 * (1 - ratio));
  return `rgb(${r}, ${g}, ${b})`;
}

const NO_SALE = { fillColor: "#141414", weight: 0.5, color: "#242424", fillOpacity: 1 };

function filterFeatures(geo, pred) {
  if (!geo) return null;
  return { ...geo, features: geo.features.filter(pred) };
}

function FitBounds({ geo, maxZoom = 6 }) {
  const map = useMap();
  useEffect(() => {
    if (geo && geo.features.length) {
      const b = L.geoJSON(geo).getBounds();
      map.fitBounds(b, { padding: [18, 18], maxZoom });
      const t = setTimeout(() => map.invalidateSize(), 120);
      return () => clearTimeout(t);
    }
  }, [geo, map, maxZoom]);
  return null;
}

export default function TerritoryMap({ period = "30d", expanded = false }) {
  const data = useMemo(() => getTerritoryData(period), [period]);

  const totalSales = data.countries.reduce((s, c) => s + c.sales, 0);
  const totalRev = data.countries.reduce((s, c) => s + c.revenue, 0);
  const dominant = useMemo(
    () => [...data.countries].sort((a, b) => b.sales - a.sales)[0],
    [data]
  );

  const scenario = useMemo(() => {
    if (totalSales === 0) return "empty";
    return dominant && dominant.sales / totalSales >= 0.85 ? "single" : "multi";
  }, [totalSales, dominant]);

  const [view, setView] = useState(scenario === "single" ? "country" : "world");
  const [selected, setSelected] = useState(dominant?.name || null);
  useEffect(() => {
    setView(scenario === "single" ? "country" : "world");
    setSelected(dominant?.name || null);
  }, [scenario, dominant]);

  const [worldGeo, setWorldGeo] = useState(null);
  const [statesGeo, setStatesGeo] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);

  useEffect(() => {
    let active = true;
    setLoading(true);
    Promise.all([loadGeo(WORLD_URL), loadGeo(BRA_URL)])
      .then(([w, s]) => {
        if (!active) return;
        setWorldGeo(w);
        setStatesGeo(s);
        setLoading(false);
      })
      .catch(() => {
        if (active) {
          setError(true);
          setLoading(false);
        }
      });
    return () => {
      active = false;
    };
  }, []);

  const countryBy = useMemo(() => {
    const m = {};
    data.countries.forEach((c) => (m[c.name] = c));
    return m;
  }, [data]);

  const states = data.statesByCountry[selected] || [];
  const stateBy = useMemo(() => {
    const m = {};
    states.forEach((s) => (m[s.name] = s));
    return m;
  }, [states]);

  const maxCountryRev = Math.max(1, ...data.countries.map((c) => c.revenue));
  const maxStateRev = Math.max(1, ...states.map((s) => s.revenue));

  const activeGeo = useMemo(() => {
    if (scenario === "empty") return worldGeo;
    if (view === "world") return worldGeo;
    if (selected === "Brazil") return statesGeo;
    return filterFeatures(worldGeo, (f) => countryName(f) === selected);
  }, [view, worldGeo, statesGeo, selected, scenario]);

  const styleFn = useMemo(() => {
    if (scenario === "empty") return () => NO_SALE;
    if (view === "world") {
      return (feat) => {
        const c = countryBy[countryName(feat)];
        if (!c || c.sales === 0) return NO_SALE;
        return {
          fillColor: heatColor(c.revenue / maxCountryRev),
          weight: 0.6,
          color: "#3a0a0a",
          fillOpacity: 0.92
        };
      };
    }
    if (selected === "Brazil") {
      return (feat) => {
        const s = stateBy[stateName(feat)];
        if (!s || s.sales === 0) return NO_SALE;
        return {
          fillColor: heatColor(s.revenue / maxStateRev),
          weight: 0.8,
          color: "#3a0a0a",
          fillOpacity: 0.95
        };
      };
    }
    return () => ({ fillColor: heatColor(0.7), weight: 0.8, color: "#3a0a0a", fillOpacity: 0.92 });
  }, [view, selected, countryBy, stateBy, maxCountryRev, maxStateRev, scenario]);

  const oefFn = useMemo(() => {
    if (scenario === "empty") return () => {};
    if (view === "world") {
      return (feat, layer) => {
        const name = countryName(feat);
        const c = countryBy[name];
        if (!c) return;
        const pct = totalRev ? ((c.revenue / totalRev) * 100).toFixed(1) : 0;
        layer.bindTooltip(
          `<div class="text-[12px] font-semibold text-white">${name}</div>` +
            `<div class="text-[11px] text-muted-foreground mt-0.5">${c.sales} vendas · ${formatCurrency(c.revenue)}</div>` +
            `<div class="text-[11px] text-primary">${pct}% do total</div>`,
          { sticky: true, className: "sxp-map-tooltip", direction: "top" }
        );
        layer.on("click", () => {
          setSelected(name);
          setView("country");
        });
      };
    }
    if (selected === "Brazil") {
      return (feat, layer) => {
        const name = stateName(feat);
        const s = stateBy[name] || {};
        const sales = s.sales || 0;
        const rev = s.revenue || 0;
        const pct = totalRev ? ((rev / totalRev) * 100).toFixed(1) : 0;
        layer.bindTooltip(
          `<div class="text-[12px] font-semibold text-white">${name}</div>` +
            `<div class="text-[11px] text-muted-foreground mt-0.5">${sales} vendas · ${formatCurrency(rev)}</div>` +
            `<div class="text-[11px] text-primary">${pct}% do total</div>`,
          { sticky: true, className: "sxp-map-tooltip", direction: "top" }
        );
      };
    }
    return () => {};
  }, [view, selected, countryBy, stateBy, totalRev, scenario]);

  const ranking = useMemo(() => {
    if (scenario === "empty") return [];
    const list = view === "world" ? data.countries : states;
    return [...list].filter((x) => x.sales > 0).sort((a, b) => b.revenue - a.revenue);
  }, [view, data, states, scenario]);
  const rankingMax = ranking.length ? ranking[0].revenue : 1;

  const height = expanded ? 460 : 360;
  const mapReady = !loading && !error && worldGeo;

  return (
    <div className="rounded-2xl surface glow-soft overflow-hidden">
      {/* Header */}
      <div className="flex items-center justify-between px-5 py-4 border-b border-white/5">
        <div className="flex items-center gap-2">
          <Globe2 className="h-4 w-4 text-primary" />
          <div>
            <h3 className="font-display font-semibold text-white text-sm">Mapa de vendas</h3>
            <p className="text-[11px] text-muted-foreground">
              {scenario === "empty"
                ? "Aguardando primeira venda"
                : view === "world"
                ? "Distribuição por país"
                : `Detalhamento · ${selected}`}
            </p>
          </div>
        </div>
        {scenario === "multi" && view === "country" && (
          <button
            onClick={() => setView("world")}
            className="inline-flex items-center gap-1.5 rounded-lg surface px-3 py-1.5 text-xs text-white hover:bg-white/5 transition-colors"
          >
            <ArrowLeft className="h-3.5 w-3.5" /> Voltar ao mapa mundial
          </button>
        )}
        {scenario === "single" && (
          <div className="flex items-center gap-1 rounded-lg surface p-1">
            <button
              onClick={() => setView("country")}
              className={cn(
                "rounded-md px-3 py-1 text-xs font-medium transition-colors",
                view === "country" ? "bg-primary/15 text-primary" : "text-muted-foreground hover:text-white"
              )}
            >
              Território
            </button>
            <button
              onClick={() => setView("world")}
              className={cn(
                "rounded-md px-3 py-1 text-xs font-medium transition-colors",
                view === "world" ? "bg-primary/15 text-primary" : "text-muted-foreground hover:text-white"
              )}
            >
              Mundo
            </button>
          </div>
        )}
      </div>

      {/* Body */}
      <div className="grid grid-cols-1 lg:grid-cols-[1fr_220px]">
        <div className="relative bg-[#0a0a0a]" style={{ height }}>
          {loading ? (
            <div className="absolute inset-0">
              <div className="animate-pulse h-full w-full bg-white/[0.03]" />
            </div>
          ) : error ? (
            <div className="absolute inset-0 flex flex-col items-center justify-center text-center px-6">
              <MapPin className="h-6 w-6 text-muted-foreground/50 mb-2" />
              <p className="text-sm text-muted-foreground">Não foi possível carregar o mapa de territórios.</p>
            </div>
          ) : (
            <>
              <MapContainer
                center={[-14, -51]}
                zoom={3}
                minZoom={2}
                maxZoom={8}
                zoomControl
                scrollWheelZoom={false}
                attributionControl={false}
                style={{ height: "100%", width: "100%", background: "#0a0a0a" }}
              >
                <FitBounds geo={activeGeo} maxZoom={scenario === "empty" || view === "world" ? 3 : 6} />
                {activeGeo && (
                  <GeoJSON
                    key={`${scenario}-${view}-${selected}-${period}`}
                    data={activeGeo}
                    style={styleFn}
                    onEachFeature={oefFn}
                  />
                )}
              </MapContainer>

              {scenario === "empty" && <EmptyPeopleOverlay />}

              {view === "country" && selected !== "Brazil" && (
                <div className="absolute bottom-3 left-3 right-3 rounded-lg bg-black/70 border border-white/10 px-3 py-2 text-[11px] text-muted-foreground text-center">
                  Sem detalhamento regional disponível para {selected}.
                </div>
              )}
            </>
          )}
        </div>

        {/* Ranking / empty-state copy */}
        <div className="border-t lg:border-t-0 lg:border-l border-white/5 p-4">
          <div className="text-[10px] uppercase tracking-[0.12em] text-muted-foreground mb-3">
            {scenario === "empty" ? "Potencial global" : view === "world" ? "Top 5 países" : "Top 5 regiões"}
          </div>
          {scenario === "empty" ? (
            <div className="space-y-3">
              <p className="text-xs text-muted-foreground leading-relaxed">
                Assim que você começar a vender, este mapa vai mostrar de onde vêm seus clientes.
              </p>
              <Link
                to="/configuracoes"
                className="inline-flex items-center gap-1.5 rounded-lg surface px-3 py-2 text-xs text-white hover:bg-white/5 transition-colors"
              >
                <Settings2 className="h-3.5 w-3.5 text-primary" /> Configurar país de operação
              </Link>
            </div>
          ) : ranking.length === 0 ? (
            <p className="text-xs text-muted-foreground">Sem vendas registradas neste período.</p>
          ) : (
            <div className="space-y-3">
              {ranking.slice(0, 5).map((r) => (
                <div key={r.name}>
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-xs text-white truncate pr-2">{r.name}</span>
                    <span className="text-xs text-white font-medium tabular-nums">{formatCurrency(r.revenue)}</span>
                  </div>
                  <div className="h-1.5 rounded-full bg-white/[0.04] overflow-hidden">
                    <div
                      className="h-full rounded-full bg-gradient-to-r from-[#8A0303] to-[#E10600]"
                      style={{ width: `${(r.revenue / rankingMax) * 100}%` }}
                    />
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

// Silhuetas de pessoas flutuando sobre o globo (estado vazio)
function EmptyPeopleOverlay() {
  const people = [
    { top: "24%", left: "18%", d: "0s" },
    { top: "30%", left: "42%", d: "0.6s" },
    { top: "38%", left: "68%", d: "1.2s" },
    { top: "50%", left: "28%", d: "0.3s" },
    { top: "56%", left: "54%", d: "0.9s" },
    { top: "28%", left: "76%", d: "1.5s" },
    { top: "44%", left: "12%", d: "1.8s" },
    { top: "60%", left: "78%", d: "0.4s" },
    { top: "36%", left: "88%", d: "2.1s" },
    { top: "48%", left: "82%", d: "1.1s" }
  ];
  return (
    <div className="absolute inset-0 pointer-events-none">
      {people.map((p, i) => (
        <div
          key={i}
          className="absolute sxp-float"
          style={{ top: p.top, left: p.left, animationDelay: p.d }}
        >
          <div className="rounded-full bg-black/50 border border-[#C10000]/60 flex items-center justify-center h-8 w-8">
            <Users className="h-4 w-4 text-white/70" />
          </div>
        </div>
      ))}
    </div>
  );
}