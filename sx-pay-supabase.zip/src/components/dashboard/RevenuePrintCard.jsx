import React, { forwardRef } from "react";

export const CARD_W = 600;

// Lockup de marca: [símbolo 69] [usuário] [barra diagonal] [SXPay]
function WatermarkLockup({ userName, ink, faint }) {
  const sep = { width: 1, height: 11, background: faint, transform: "skewX(-16deg)", display: "inline-block" };
  return (
    <div style={{ position: "absolute", left: 0, right: 0, bottom: 22, display: "flex", justifyContent: "center", alignItems: "center", gap: 9 }}>
      <span style={{ fontFamily: "var(--font-display)", fontWeight: 800, fontSize: 13, letterSpacing: "-0.05em", color: ink, fontStyle: "italic" }}>69</span>
      <span style={sep} />
      <span style={{ fontFamily: "var(--font-display)", fontWeight: 600, fontSize: 11, letterSpacing: "0.22em", textTransform: "uppercase", color: ink }}>{userName}</span>
      <span style={sep} />
      <span style={{ fontFamily: "var(--font-display)", fontWeight: 700, fontSize: 11, letterSpacing: "0.24em", textTransform: "uppercase", color: ink }}>SXPay</span>
    </div>
  );
}

const RevenuePrintCard = forwardRef(function RevenuePrintCard({
  wallpaper,
  metricLabel,
  metricValue,
  growth = 0,
  growthLabel = "este mês",
  period = "Mês atual",
  secondary = [],
  includeSecondary = false,
  userName = "usuario",
  aspect = "square",
  watermarkLight = true,
  purpose = ""
}, ref) {
  const isVertical = aspect === "vertical";
  const cardH = isVertical ? 1067 : 600;
  const ink = watermarkLight ? "rgba(255,255,255,0.82)" : "rgba(12,12,12,0.82)";
  const faint = watermarkLight ? "rgba(255,255,255,0.28)" : "rgba(12,12,12,0.4)";
  const patternInk = watermarkLight ? "rgba(255,255,255,0.22)" : "rgba(12,12,12,0.18)";

  const bg = wallpaper?.type === "image"
    ? `url(${wallpaper.value}) center / cover no-repeat`
    : (wallpaper?.value || "#0a0a0a");

  // auto-size do número protagonista
  const len = String(metricValue).length;
  const numberSize = len > 12 ? 48 : len > 10 ? 58 : isVertical ? 70 : 66;

  const marks = Array.from({ length: 16 });
  const padX = isVertical ? 56 : 52;

  // Zonas determinísticas — cada bloco tem sua própria posição vertical.
  const sealTop = isVertical ? 56 : 40;
  const contentTop = sealTop + 34;
  const bottomReserve = 64; // reserva fixa para a marca d'água (nunca invade)
  const phraseMaxHeight = Math.round(13 * 1.5 * 2); // no máx. 2 linhas

  return (
    <div ref={ref} style={{ width: CARD_W, height: cardH, position: "relative", overflow: "hidden", background: bg, borderRadius: 24, color: "#fff", fontFamily: "var(--font-body)" }}>
      {/* textura de circuito sutil */}
      <div style={{ position: "absolute", inset: 0, backgroundImage: "radial-gradient(circle at 1px 1px, rgba(255,255,255,0.05) 1px, transparent 0)", backgroundSize: "26px 26px", opacity: 0.5 }} />
      {/* vinheta de profundidade */}
      <div style={{ position: "absolute", inset: 0, background: "radial-gradient(ellipse at 50% 36%, rgba(0,0,0,0) 26%, rgba(0,0,0,0.6) 100%)" }} />
      {/* glow vermelho no topo */}
      <div style={{ position: "absolute", inset: 0, background: "radial-gradient(circle at 50% -6%, rgba(193,0,0,0.32) 0%, transparent 42%)", pointerEvents: "none" }} />

      {/* padrão diagonal anti-cópia (sempre atrás do conteúdo) */}
      {marks.map((_, i) => {
        const cols = 4;
        const col = i % cols;
        const row = Math.floor(i / cols);
        const x = -60 + col * 200 + (row % 2) * 100;
        const y = -30 + row * 210;
        return (
          <span key={i} style={{ position: "absolute", left: x, top: y, transform: "rotate(-28deg)", transformOrigin: "left top", fontFamily: "var(--font-display)", fontWeight: 700, fontSize: 32, letterSpacing: "0.32em", color: patternInk, whiteSpace: "nowrap", pointerEvents: "none" }}>SXPay</span>
        );
      })}

      {/* 1) Selo da marca — topo, posição fixa própria */}
      <div style={{ position: "absolute", top: sealTop, left: 0, right: 0, display: "flex", justifyContent: "center", alignItems: "center", gap: 9 }}>
        <span style={{ width: 6, height: 6, borderRadius: 99, background: "#C10000", boxShadow: "0 0 12px #C10000" }} />
        <span style={{ fontFamily: "var(--font-display)", fontWeight: 700, fontSize: 12, letterSpacing: "0.34em", textTransform: "uppercase", color: "rgba(255,255,255,0.78)" }}>SXPay</span>
      </div>

      {/* 2..6) Pilha de conteúdo — flui de cima para baixo, cada bloco após o anterior.
              Área delimitada (top = abaixo do selo, bottom = reserva da marca d'água),
              então nada colide com o selo nem com a marca d'água. */}
      <div style={{ position: "absolute", top: contentTop, left: padX, right: padX, bottom: bottomReserve, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center" }}>
        <div style={{ position: "relative", width: "100%", borderRadius: 20, padding: isVertical ? "34px 30px" : "28px 30px", background: "rgba(8,8,8,0.4)", border: "1px solid rgba(255,255,255,0.12)", boxShadow: "0 24px 60px -18px rgba(0,0,0,0.7), inset 0 1px 0 rgba(255,255,255,0.08)" }}>
          {/* 2) rótulo da métrica */}
          <div style={{ display: "flex", alignItems: "center", justifyContent: "center", gap: 10, marginBottom: 14 }}>
            <span style={{ width: 6, height: 6, borderRadius: 99, background: "#C10000", boxShadow: "0 0 12px #C10000" }} />
            <span style={{ fontFamily: "var(--font-display)", fontSize: 13, letterSpacing: "0.28em", textTransform: "uppercase", color: "rgba(255,255,255,0.72)", fontWeight: 600 }}>{metricLabel}</span>
          </div>
          {/* 3) número protagonista */}
          <div style={{ textAlign: "center", fontFamily: "var(--font-display)", fontWeight: 800, fontSize: numberSize, lineHeight: 1.04, letterSpacing: "-0.03em", color: "#fff", textShadow: "0 16px 64px rgba(0,0,0,0.68), 0 4px 14px rgba(0,0,0,0.5)" }}>
            {metricValue}
          </div>
          {/* 4) indicador de crescimento */}
          <div style={{ display: "flex", justifyContent: "center", marginTop: 16 }}>
            <div style={{ display: "inline-flex", alignItems: "center", gap: 8, padding: "7px 14px", borderRadius: 99, background: "rgba(193,0,0,0.2)", border: "1px solid rgba(193,0,0,0.48)", boxShadow: "0 0 26px -6px rgba(193,0,0,0.55)" }}>
              <span style={{ fontFamily: "var(--font-display)", fontWeight: 700, fontSize: 15, color: "#FF4D4D" }}>{growth >= 0 ? "+" : ""}{growth}%</span>
              <span style={{ fontSize: 11, letterSpacing: "0.12em", textTransform: "uppercase", color: "rgba(255,255,255,0.55)" }}>{growthLabel}</span>
            </div>
          </div>
          {/* período de referência */}
          <div style={{ textAlign: "center", marginTop: 12, fontSize: 11, letterSpacing: "0.22em", textTransform: "uppercase", color: "rgba(255,255,255,0.42)" }}>{period}</div>
          {/* 5) métricas secundárias (opcional) */}
          {includeSecondary && secondary.length > 0 && (
            <div style={{ display: "flex", justifyContent: "center", gap: isVertical ? 44 : 28, marginTop: 20, paddingTop: 16, borderTop: "1px solid rgba(255,255,255,0.09)" }}>
              {secondary.map((s) => (
                <div key={s.label} style={{ textAlign: "center" }}>
                  <div style={{ fontFamily: "var(--font-display)", fontWeight: 700, fontSize: 20, color: "#fff" }}>{s.value}</div>
                  <div style={{ fontSize: 10, letterSpacing: "0.18em", textTransform: "uppercase", color: "rgba(255,255,255,0.46)", marginTop: 2 }}>{s.label}</div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* 6) frase da marca — no máx. 2 linhas, nunca invade a reserva da marca d'água */}
        {purpose && (
          <div style={{ marginTop: 18, maxWidth: 380, textAlign: "center", fontFamily: "var(--font-body)", fontStyle: "italic", fontSize: 13, lineHeight: 1.5, letterSpacing: "0.01em", color: watermarkLight ? "rgba(255,255,255,0.72)" : "rgba(12,12,12,0.74)", textShadow: "0 2px 14px rgba(0,0,0,0.55), 0 1px 3px rgba(0,0,0,0.45)", maxHeight: phraseMaxHeight, overflow: "hidden" }}>{purpose}</div>
        )}
      </div>

      {/* 7) marca d'água — rodapé, em zona reservada fixa (nunca sobreposta) */}
      <WatermarkLockup userName={userName} ink={ink} faint={faint} />
    </div>
  );
});

export default RevenuePrintCard;