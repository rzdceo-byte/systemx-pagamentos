import React, { useState } from "react";
import { Package } from "lucide-react";
import { useToast } from "@/components/ui/use-toast";
import { createZip, collectPublishedAssets } from "@/lib/zipExporter";

// Botão do Dashboard que empacota os assets publicados do app em um ZIP baixável no navegador.
export default function ExportZipButton() {
  const { toast } = useToast();
  const [busy, setBusy] = useState(false);

  const handleExport = async () => {
    if (busy) return;
    setBusy(true);
    try {
      const files = await collectPublishedAssets();
      const blob = createZip(files);
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `sxpay-assets-${Date.now()}.zip`;
      a.click();
      setTimeout(() => URL.revokeObjectURL(url), 5000);
      toast({
        title: "ZIP gerado",
        description: `${files.length} arquivos empacotados (${(blob.size / 1024).toFixed(0)} KB).`,
      });
    } catch (e) {
      toast({
        title: "Falha ao gerar ZIP",
        description: String(e?.message || e),
        variant: "destructive",
      });
    } finally {
      setBusy(false);
    }
  };

  return (
    <button
      onClick={handleExport}
      disabled={busy}
      className="inline-flex items-center gap-2 rounded-lg border border-white/12 bg-white/[0.02] px-4 py-2.5 text-sm font-medium text-white/90 hover:border-primary/40 hover:text-white transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
    >
      <Package className={`h-4 w-4 text-primary ${busy ? "animate-pulse" : ""}`} />
      {busy ? "Compactando..." : "Exportar ZIP"}
    </button>
  );
}