import React, { useState, useEffect } from "react";
import { Radio } from "lucide-react";
import { formatCurrency } from "@/lib/mockData";

// Painel "SXPay ao vivo" — feed compacto das últimas vendas chegando, com bolinha pulsante.
export default function LiveFeedPanel({ transactions, accent = "#C10000" }) {
  const [feed, setFeed] = useState(() => (transactions || []).slice(0, 6));
  const [pulse, setPulse] = useState(true);

  // Simula novas vendas chegando em tempo real
  useEffect(() => {
    const pool = transactions || [];
    if (pool.length === 0) return;
    const t = setInterval(() => {
      setPulse(true);
      const tx = pool[Math.floor(Math.random() * pool.length)];
      setFeed((prev) => [{ ...tx, _live: Date.now() }, ...prev].slice(0, 6));
      setTimeout(() => setPulse(false), 600);
    }, 5000 + Math.random() * 4000);
    return () => clearInterval(t);
  }, [transactions]);

  return (
    <div className="rounded-xl surface glow-soft p-4">
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          <span className="relative flex h-2.5 w-2.5">
            <span className="absolute inline-flex h-full w-full rounded-full animate-ping" style={{ background: accent, opacity: 0.6 }} />
            <span className="relative inline-flex h-2.5 w-2.5 rounded-full" style={{ background: accent, boxShadow: `0 0 8px ${accent}` }} />
          </span>
          <span className="text-[10px] uppercase tracking-[0.2em] text-white font-semibold">SXPay ao vivo</span>
        </div>
        <span className="text-[10px] text-muted-foreground">{pulse ? "nova venda" : "monitorando"}</span>
      </div>
      <div className="space-y-1.5">
        {feed.map((tx, i) => (
          <div key={tx.id + "-" + (tx._live || i)} className={`flex items-center justify-between rounded-md px-2.5 py-2 transition-all ${i === 0 && tx._live ? "bg-primary/10 border border-primary/20 animate-fade-in" : "bg-white/[0.02] border border-transparent"}`}>
            <div className="flex items-center gap-2 min-w-0">
              <div className="flex h-7 w-7 items-center justify-center rounded-md bg-black/40 border border-white/5 text-[10px] font-bold text-white shrink-0">
                {tx.customer?.split(" ").map((n) => n[0]).join("").slice(0, 2)}
              </div>
              <div className="min-w-0">
                <div className="text-xs text-white truncate">{tx.customer}</div>
                <div className="text-[10px] text-muted-foreground truncate">{tx.product}</div>
              </div>
            </div>
            <div className="text-right shrink-0 ml-2">
              <div className="text-xs font-semibold tabular-nums" style={{ color: accent }}>{formatCurrency(tx.value)}</div>
              <div className="text-[10px] text-muted-foreground">{tx.method}</div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}