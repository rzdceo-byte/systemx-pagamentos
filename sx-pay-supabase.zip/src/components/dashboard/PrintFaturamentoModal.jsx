import React, { useState, useRef, useEffect, useLayoutEffect, useMemo } from "react";
import html2canvas from "html2canvas";
import { Dialog, DialogContent } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { useToast } from "@/components/ui/use-toast";
import { useAuth } from "@/lib/AuthContext";
import RevenuePrintCard, { CARD_W } from "@/components/dashboard/RevenuePrintCard";
import { dashboardStats, formatCurrency } from "@/lib/mockData";
import { pickRandomPhrase } from "@/lib/systemxPhrases";
import { Camera, Download, Share2, Check, ChevronRight, ChevronLeft, ImageOff, Sparkles, Upload } from "lucide-react";

// Wallpapers padrão (placeholders premium).
const DEFAULT_WALLPAPERS = [
  { id: "noir", type: "gradient", label: "Noir", value: "linear-gradient(135deg, #0a0a0a 0%, #160404 55%, #050505 100%)", tone: "dark" },
  { id: "sangue", type: "gradient", label: "Sangue", value: "radial-gradient(circle at 26% 16%, rgba(193,0,0,0.85) 0%, #2a0000 22%, #0a0a0a 70%)", tone: "dark" },
  { id: "grafite", type: "gradient", label: "Grafite", value: "linear-gradient(160deg, #0D0D0D 0%, #1f1f1f 100%)", tone: "dark" },
  { id: "bruixo", type: "gradient", label: "Bruixo", value: "linear-gradient(135deg, #8A0303 0%, #1a0303 45%, #050505 100%)", tone: "dark" },
  { id: "vinho", type: "gradient", label: "Vinho", value: "radial-gradient(circle at 72% 82%, rgba(120,0,0,0.7) 0%, #0a0a0a 65%)", tone: "dark" }
];

const METRICS = [
  { id: "month", label: "Faturamento do mês", currency: true },
  { id: "balance", label: "Saldo disponível", currency: true },
  { id: "today", label: "Vendas hoje", currency: true },
  { id: "ticket", label: "Ticket médio", currency: true },
  { id: "approved", label: "Pedidos aprovados", currency: false }
].map((m) => ({ ...m, stat: dashboardStats.find((s) => s.id === m.id) })).filter((m) => m.stat);

const PERIODS = ["Hoje", "7 dias", "30 dias", "Mês atual", "Personalizado"];
const STEPS = ["Wallpaper", "Conteúdo", "Pré-visualização", "Exportar"];

const CACHE_KEY = "sxp_print_config";

function formatMetric(stat, currency) {
  if (currency) return formatCurrency(stat.value);
  return stat.isCount ? stat.value.toLocaleString("pt-BR") : `${stat.value}${stat.suffix || ""}`;
}

// Detecção de luminância para contraste automático da marca d'água
function detectLuminance(wallpaper) {
  return new Promise((resolve) => {
    if (!wallpaper) return resolve(0.12);
    if (wallpaper.type !== "image") return resolve(wallpaper.tone === "dark" ? 0.12 : 0.86);
    const img = new Image();
    img.crossOrigin = "anonymous";
    img.onload = () => {
      try {
        const c = document.createElement("canvas");
        c.width = 40; c.height = 40;
        const ctx = c.getContext("2d");
        ctx.drawImage(img, img.width - 120, img.height - 120, 120, 120, 0, 0, 40, 40);
        const d = ctx.getImageData(0, 0, 40, 40).data;
        let sum = 0;
        for (let i = 0; i < d.length; i += 4) sum += (d[i] * 0.299 + d[i + 1] * 0.587 + d[i + 2] * 0.114);
        resolve(sum / (40 * 40 * 255));
      } catch { resolve(0.12); }
    };
    img.onerror = () => resolve(0.12);
    img.src = wallpaper.value;
  });
}

function normalizeHandle(name) {
  const base = (name || "usuario").split(" ")[0] || "usuario";
  return base.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "");
}

export default function PrintFaturamentoModal({ open, onOpenChange, wallpapers = DEFAULT_WALLPAPERS }) {
  const { toast } = useToast();
  const { user } = useAuth();
  const userName = useMemo(() => normalizeHandle(user?.full_name || "Márcio Almeida"), [user]);

  const [step, setStep] = useState(1);
  const [wallpaperId, setWallpaperId] = useState(DEFAULT_WALLPAPERS[0].id);
  const [metricId, setMetricId] = useState("month");
  const [period, setPeriod] = useState("Mês atual");
  const [includeSecondary, setIncludeSecondary] = useState(true);
  const [aspect, setAspect] = useState("square");
  const [watermarkLight, setWatermarkLight] = useState(true);
  const [exporting, setExporting] = useState(false);
  // Wallpapers enviados pelo usuário (object URLs locais — imediatos para preview e exportação).
  const [customWalls, setCustomWalls] = useState([]);
  const fileInputRef = useRef(null);
  // Frase SYSTEMX sorteada a cada abertura do modal.
  const [phrase, setPhrase] = useState(() => pickRandomPhrase());

  const cardRef = useRef(null);
  const previewWrapRef = useRef(null);
  const [scale, setScale] = useState(0.4);

  const baseWalls = wallpapers.length ? wallpapers : DEFAULT_WALLPAPERS;
  const allWalls = [...customWalls, ...baseWalls];
  const wallpaper = allWalls.find((w) => w.id === wallpaperId) || allWalls[0];
  const metric = METRICS.find((m) => m.id === metricId) || METRICS[0];
  const cardH = aspect === "vertical" ? 1067 : 600;

  // cache
  useEffect(() => {
    if (!open) return;
    try {
      const cached = JSON.parse(localStorage.getItem(CACHE_KEY) || "null");
      if (cached) {
        if (cached.wallpaperId) setWallpaperId(cached.wallpaperId);
        if (cached.metricId) setMetricId(cached.metricId);
        if (cached.period) setPeriod(cached.period);
        if (typeof cached.includeSecondary === "boolean") setIncludeSecondary(cached.includeSecondary);
        if (cached.aspect) setAspect(cached.aspect);
      }
    } catch { /* ignore */ }
  }, [open]);

  // Frase SYSTEMX: sorteio independente a cada abertura do modal.
  useEffect(() => {
    if (open) setPhrase(pickRandomPhrase());
  }, [open]);

  useEffect(() => {
    if (!open) return;
    try {
      localStorage.setItem(CACHE_KEY, JSON.stringify({ wallpaperId, metricId, period, includeSecondary, aspect }));
    } catch { /* ignore */ }
  }, [open, wallpaperId, metricId, period, includeSecondary, aspect]);

  // contraste automático
  useEffect(() => {
    let active = true;
    detectLuminance(wallpaper).then((lum) => { if (active) setWatermarkLight(lum < 0.5); });
    return () => { active = false; };
  }, [wallpaper]);

  // escala do preview
  useLayoutEffect(() => {
    const el = previewWrapRef.current;
    if (!el) return;
    const compute = () => {
      const cw = el.clientWidth;
      const ch = el.clientHeight;
      setScale(Math.min(cw / CARD_W, ch / cardH, 0.7));
    };
    compute();
    const ro = new ResizeObserver(compute);
    ro.observe(el);
    return () => ro.disconnect();
  }, [aspect, cardH, open]);

  const metricValue = formatMetric(metric.stat, metric.currency);
  const growth = metric.stat.trend || 0;
  const growthLabel = metric.stat.trendLabel || "este mês";
  const secondary = [
    { label: "Vendas", value: dashboardStats.find((s) => s.id === "approved").value.toLocaleString("pt-BR") },
    { label: "Conversão", value: `${dashboardStats.find((s) => s.id === "conversion").value.toString().replace(".", ",")}%` }
  ];

  const handleFiles = (e) => {
    const files = Array.from(e.target.files || []);
    if (!files.length) return;
    const valid = [];
    let invalid = 0;
    files.forEach((f) => { if (f.type.startsWith("image/")) valid.push(f); else invalid++; });
    if (invalid > 0) toast({ title: "Formato inválido", description: "Apenas arquivos de imagem são aceitos.", variant: "destructive" });
    if (!valid.length) { e.target.value = ""; return; }
    const created = valid.map((f) => ({
      id: `up-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
      type: "image",
      label: (f.name.replace(/\.[^.]+$/, "").slice(0, 18) || "Wallpaper"),
      value: URL.createObjectURL(f),
      tone: "dark"
    }));
    setCustomWalls((prev) => [...created, ...prev]);
    setWallpaperId(created[0].id);
    e.target.value = "";
  };

  const renderThumb = (w, isCustom) => (
    <button key={w.id} onClick={() => setWallpaperId(w.id)} className={`group relative rounded-xl overflow-hidden aspect-[3/4] border-2 transition-all ${wallpaperId === w.id ? "border-primary glow-red-sm" : "border-white/10 hover:border-white/25"}`}>
      <div className="absolute inset-0" style={{ background: w.type === "image" ? `url(${w.value}) center/cover` : w.value }} />
      <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
      <span className="absolute bottom-1.5 left-2 text-[10px] font-medium text-white/90 truncate max-w-[80%]">{w.label}</span>
      {isCustom && <span className="absolute top-1.5 left-1.5 text-[8px] uppercase tracking-wide px-1 py-0.5 rounded bg-black/60 text-white/80">Sua</span>}
      {wallpaperId === w.id && <span className="absolute top-1.5 right-1.5 h-5 w-5 rounded-full bg-primary flex items-center justify-center"><Check className="h-3 w-3 text-white" /></span>}
    </button>
  );

  const renderPreview = () => (
    <div style={{ width: CARD_W * scale, height: cardH * scale }}>
      <div style={{ width: CARD_W, height: cardH, transform: `scale(${scale})`, transformOrigin: "top left" }}>
        <RevenuePrintCard
          ref={cardRef}
          wallpaper={wallpaper}
          metricLabel={metric.label}
          metricValue={metricValue}
          growth={growth}
          growthLabel={growthLabel}
          period={period}
          secondary={secondary}
          includeSecondary={includeSecondary}
          userName={userName}
          aspect={aspect}
          watermarkLight={watermarkLight}
          purpose={phrase}
        />
      </div>
    </div>
  );

  const capture = async () => {
    try { await document.fonts.ready; } catch { /* ignore */ }
    return await html2canvas(cardRef.current, { scale: 3, useCORS: true, backgroundColor: null, logging: false });
  };

  const handleDownload = async () => {
    if (!cardRef.current) return;
    setExporting(true);
    try {
      const canvas = await capture();
      canvas.toBlob((blob) => {
        if (!blob) return;
        const url = URL.createObjectURL(blob);
        const a = document.createElement("a");
        a.href = url;
        a.download = `faturamento-sxpay-${Date.now()}.png`;
        a.click();
        setTimeout(() => URL.revokeObjectURL(url), 4000);
        toast({ title: "Imagem exportada", description: "PNG em alta resolução salvo." });
      }, "image/png");
    } catch (e) {
      toast({ title: "Falha ao gerar imagem", description: String(e?.message || e), variant: "destructive" });
    } finally {
      setExporting(false);
    }
  };

  const handleShare = async () => {
    if (!cardRef.current) return;
    setExporting(true);
    try {
      const canvas = await capture();
      canvas.toBlob(async (blob) => {
        if (!blob) { setExporting(false); return; }
        const file = new File([blob], "faturamento-sxpay.png", { type: "image/png" });
        if (navigator.canShare && navigator.canShare({ files: [file] })) {
          try {
            await navigator.share({ files: [file], title: "Faturamento SXPay" });
          } catch { /* cancelado */ }
        } else {
          const url = URL.createObjectURL(blob);
          const a = document.createElement("a");
          a.href = url; a.download = `faturamento-sxpay-${Date.now()}.png`; a.click();
          setTimeout(() => URL.revokeObjectURL(url), 4000);
          toast({ title: "Compartilhamento nativo indisponível", description: "Imagem baixada para você compartilhar manualmente." });
        }
      }, "image/png");
    } catch (e) {
      toast({ title: "Falha ao compartilhar", description: String(e?.message || e), variant: "destructive" });
    } finally {
      setExporting(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-5xl w-full h-[92vh] max-h-[94vh] bg-[#0A0A0A] border-white/10 p-0 overflow-hidden flex flex-col">
        {/* Cabeçalho fixo */}
        <div className="flex items-center gap-2 px-5 py-3 border-b border-white/8 shrink-0">
          <Camera className="h-4 w-4 text-primary" />
          <h2 className="font-display font-bold text-white text-base">Printar faturamento</h2>
        </div>

        {/* Corpo: grid com colunas de config e preview, cada uma com rolagem própria */}
        <div className="flex-1 min-h-0 grid grid-cols-1 grid-rows-[1fr] lg:grid-cols-[1fr_380px]">
          {/* Coluna de configuração */}
          <div className="flex flex-col min-h-0 border-b lg:border-b-0 lg:border-r border-white/8">
            {/* Stepper (fixo no topo da coluna) */}
            <div className="flex items-center gap-1 px-5 pt-4 pb-3 shrink-0">
              {STEPS.map((s, i) => {
                const idx = i + 1;
                const active = step === idx;
                const done = step > idx;
                return (
                  <React.Fragment key={s}>
                    <button onClick={() => setStep(idx)} className={`flex items-center gap-1.5 text-[11px] font-medium transition-colors ${active ? "text-white" : "text-muted-foreground"}`}>
                      <span className={`h-5 w-5 rounded-full flex items-center justify-center text-[10px] border ${active ? "bg-primary border-primary text-white" : done ? "border-primary/50 text-primary" : "border-white/15 text-muted-foreground"}`}>{done ? <Check className="h-3 w-3" /> : idx}</span>
                      <span className="hidden sm:inline">{s}</span>
                    </button>
                    {i < STEPS.length - 1 && <span className="h-px flex-1 bg-white/10 min-w-[8px]" />}
                  </React.Fragment>
                );
              })}
            </div>

            {/* Conteúdo do meio — rolagem própria, independente da página */}
            <div className="flex-1 min-h-0 overflow-y-auto px-5 pb-4">
              {/* Step 1 — Wallpaper */}
              {step === 1 && (
                <div className="space-y-5">
                  {/* Upload */}
                  <div>
                    <p className="text-[11px] uppercase tracking-[0.16em] text-muted-foreground mb-2.5">Envie seu próprio wallpaper</p>
                    <button
                      type="button"
                      onClick={() => fileInputRef.current?.click()}
                      className="w-full flex flex-col items-center justify-center gap-1.5 rounded-xl border-2 border-dashed border-white/12 hover:border-primary/50 hover:bg-white/[0.02] transition-colors py-5 text-center"
                    >
                      <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-primary/10 text-primary"><Upload className="h-4 w-4" /></span>
                      <span className="text-sm text-white font-medium">Enviar imagem</span>
                      <span className="text-[11px] text-muted-foreground">PNG, JPG ou WEBP · você pode enviar várias</span>
                    </button>
                    <input ref={fileInputRef} type="file" accept="image/*" multiple className="hidden" onChange={handleFiles} />
                  </div>

                  {/* Seus wallpapers */}
                  <div>
                    <p className="text-[11px] uppercase tracking-[0.16em] text-muted-foreground mb-2.5">Seus wallpapers</p>
                    {customWalls.length === 0 ? (
                      <div className="flex flex-col items-center justify-center py-7 text-center border border-dashed border-white/10 rounded-xl">
                        <ImageOff className="h-5 w-5 text-muted-foreground mb-1.5" />
                        <p className="text-xs text-muted-foreground">Nenhum wallpaper enviado ainda</p>
                        <p className="text-[10px] text-muted-foreground/70 mt-0.5">Use o botão acima para enviar uma imagem.</p>
                      </div>
                    ) : (
                      <div className="grid grid-cols-3 gap-3">
                        {customWalls.map((w) => renderThumb(w, true))}
                      </div>
                    )}
                  </div>

                  {/* Padrões */}
                  <div>
                    <p className="text-[11px] uppercase tracking-[0.16em] text-muted-foreground mb-2.5">Padrões</p>
                    {baseWalls.length === 0 ? (
                      <p className="text-xs text-muted-foreground">Nenhum wallpaper disponível.</p>
                    ) : (
                      <div className="grid grid-cols-3 gap-3">
                        {baseWalls.map((w) => renderThumb(w, false))}
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* Step 2 — Conteúdo */}
              {step === 2 && (
                <div className="space-y-5">
                  <div>
                    <p className="text-[11px] uppercase tracking-[0.16em] text-muted-foreground mb-2.5">Métrica protagonista</p>
                    <div className="grid grid-cols-1 gap-2">
                      {METRICS.map((m) => (
                        <button key={m.id} onClick={() => setMetricId(m.id)} className={`flex items-center justify-between rounded-lg border px-3 py-2.5 text-left transition-colors ${metricId === m.id ? "border-primary bg-primary/10" : "border-white/10 hover:border-white/20"}`}>
                          <span className="text-sm text-white">{m.label}</span>
                          <span className="text-xs text-muted-foreground tabular-nums">{formatMetric(m.stat, m.currency)}</span>
                        </button>
                      ))}
                    </div>
                  </div>
                  <div>
                    <p className="text-[11px] uppercase tracking-[0.16em] text-muted-foreground mb-2.5">Período de referência</p>
                    <div className="flex flex-wrap gap-2">
                      {PERIODS.map((p) => (
                        <button key={p} onClick={() => setPeriod(p)} className={`px-3 py-1.5 rounded-md text-xs border transition-colors ${period === p ? "border-primary bg-primary/10 text-white" : "border-white/10 text-muted-foreground hover:border-white/20"}`}>{p}</button>
                      ))}
                    </div>
                  </div>
                  <div onClick={() => setIncludeSecondary((v) => !v)} className="flex items-center justify-between rounded-lg border border-white/10 px-3 py-2.5 cursor-pointer hover:border-white/20 transition-colors">
                    <div>
                      <span className="text-sm text-white">Métricas secundárias</span>
                      <p className="text-[11px] text-muted-foreground">Vendas e conversão no rodapé do card</p>
                    </div>
                    <span className={`relative h-5 w-9 rounded-full transition-colors ${includeSecondary ? "bg-primary" : "bg-white/10"}`}>
                      <span className={`absolute top-0.5 h-4 w-4 rounded-full bg-white transition-all ${includeSecondary ? "left-[18px]" : "left-0.5"}`} />
                    </span>
                  </div>
                </div>
              )}

              {/* Step 3 — Pré-visualização */}
              {step === 3 && (
                <div className="space-y-3">
                  <div className="flex items-center gap-2 text-primary"><Sparkles className="h-4 w-4" /><p className="text-sm font-medium text-white">Composição em camadas</p></div>
                  <p className="text-[12px] text-muted-foreground leading-relaxed">O número protagonista flutua sobre o wallpaper com sombra desfocada, vidro semi-transparente atrás do bloco e vinheta de profundidade. A marca d'água "69 · {userName} · SXPay" fica fixa no rodapé da imagem.</p>
                  <div className="rounded-lg border border-white/10 p-3 space-y-2">
                    <div className="flex items-center justify-between text-[11px]"><span className="text-muted-foreground">Wallpaper</span><span className="text-white truncate ml-2">{wallpaper?.label || "—"}</span></div>
                    <div className="flex items-center justify-between text-[11px]"><span className="text-muted-foreground">Métrica</span><span className="text-white">{metric.label}</span></div>
                    <div className="flex items-center justify-between text-[11px]"><span className="text-muted-foreground">Período</span><span className="text-white">{period}</span></div>
                    <div className="flex items-center justify-between text-[11px]"><span className="text-muted-foreground">Secundárias</span><span className="text-white">{includeSecondary ? "Sim" : "Não"}</span></div>
                  </div>
                </div>
              )}

              {/* Step 4 — Exportar */}
              {step === 4 && (
                <div className="space-y-4">
                  <div>
                    <p className="text-[11px] uppercase tracking-[0.16em] text-muted-foreground mb-2.5">Formato de saída</p>
                    <div className="grid grid-cols-2 gap-3">
                      <button onClick={() => setAspect("square")} className={`rounded-lg border p-3 text-left transition-colors ${aspect === "square" ? "border-primary bg-primary/10" : "border-white/10 hover:border-white/20"}`}>
                        <div className="h-12 w-12 rounded-md border border-white/15 mb-2" />
                        <span className="text-xs text-white font-medium">Quadrado</span>
                        <p className="text-[10px] text-muted-foreground">Feed · 1:1</p>
                      </button>
                      <button onClick={() => setAspect("vertical")} className={`rounded-lg border p-3 text-left transition-colors ${aspect === "vertical" ? "border-primary bg-primary/10" : "border-white/10 hover:border-white/20"}`}>
                        <div className="h-14 w-8 rounded-md border border-white/15 mb-2" />
                        <span className="text-xs text-white font-medium">Vertical</span>
                        <p className="text-[10px] text-muted-foreground">Stories/Reels · 9:16</p>
                      </button>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Button onClick={handleDownload} disabled={exporting} className="w-full glow-red-sm"><Download className="h-4 w-4" />{exporting ? "Gerando..." : "Baixar imagem (PNG)"}</Button>
                    <Button onClick={handleShare} disabled={exporting} variant="outline" className="w-full"><Share2 className="h-4 w-4" />Compartilhar</Button>
                  </div>
                  <p className="text-[10px] text-muted-foreground/70 text-center">Geração client-side em alta resolução · sem servidor externo.</p>
                </div>
              )}
            </div>

            {/* Rodapé fixo — navegação */}
            <div className="flex items-center justify-between px-5 py-3 border-t border-white/8 shrink-0">
              <Button variant="ghost" size="sm" onClick={() => setStep((s) => Math.max(1, s - 1))} disabled={step === 1}><ChevronLeft className="h-4 w-4" />Voltar</Button>
              {step < 4 ? (
                <Button size="sm" onClick={() => setStep((s) => Math.min(4, s + 1))}>Avançar<ChevronRight className="h-4 w-4" /></Button>
              ) : (
                <Button size="sm" variant="outline" onClick={() => onOpenChange(false)}>Concluir</Button>
              )}
            </div>
          </div>

          {/* Coluna de preview */}
          <div className="hidden lg:flex flex-col min-h-0 bg-black/40">
            <div className="px-4 py-3 border-b border-white/8 flex items-center justify-between shrink-0">
              <span className="text-[11px] uppercase tracking-[0.16em] text-muted-foreground">Pré-visualização</span>
              <span className="text-[11px] text-muted-foreground">{aspect === "vertical" ? "9:16" : "1:1"}</span>
            </div>
            <div ref={previewWrapRef} className="flex-1 min-h-0 flex items-center justify-center p-4 overflow-hidden">
              {renderPreview()}
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}