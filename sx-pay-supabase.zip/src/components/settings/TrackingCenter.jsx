import React, { useState } from "react";
import { Radio, CheckCircle2, AlertTriangle, ChevronDown, Activity } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { cn } from "@/lib/utils";
import { useToast } from "@/components/ui/use-toast";

const PLATFORMS = [
  {
    id: "utmify",
    name: "UTMify",
    desc: "Rastreador de UTM — repasse automático de origem, meio, campanha, conteúdo e termo.",
    fields: [{ key: "token", label: "Token / ID de integração", placeholder: "utm_xxxxxxxxxxxx" }],
    events: ["Lead capturado", "Pagamento aprovado", "Repasse UTM"]
  },
  {
    id: "meta",
    name: "Meta Ads",
    desc: "Facebook & Instagram — Pixel + Conversions API (CAPI).",
    fields: [
      { key: "pixelId", label: "Pixel ID", placeholder: "000000000000000" },
      { key: "capiToken", label: "Conversions API Access Token", placeholder: "caap_token_..." }
    ],
    events: ["PageView", "InitiateCheckout", "AddPaymentInfo", "Purchase"]
  },
  {
    id: "tiktok",
    name: "TikTok Ads",
    desc: "Pixel + Events API para conversões no TikTok.",
    fields: [
      { key: "pixelId", label: "Pixel ID", placeholder: "Cxxxxxxxxxxxxx" },
      { key: "eventsToken", label: "Events API Token", placeholder: "evt_token_..." }
    ],
    events: ["PageView", "InitiateCheckout", "PlaceAnOrder", "CompletePayment"]
  },
  {
    id: "google",
    name: "Google Ads & GA4",
    desc: "ID de medição GA4 + tag de conversão do Google Ads.",
    fields: [
      { key: "ga4Id", label: "GA4 — Measurement ID", placeholder: "G-XXXXXXX" },
      { key: "gadsId", label: "Google Ads — Conversion ID", placeholder: "AW-XXXXXXXX" }
    ],
    events: ["page_view", "begin_checkout", "add_payment_info", "purchase"]
  },
  {
    id: "webhook",
    name: "Webhook genérico",
    desc: "Receba eventos de venda em tempo real em uma URL customizada.",
    fields: [{ key: "url", label: "URL do webhook", placeholder: "https://sua-api.com/sxpay/events" }],
    events: ["sale.approved", "sale.refunded", "lead.captured"]
  }
];

const SAMPLE_LOGS = [
  { event: "Purchase", time: "09:14:22", status: "enviado" },
  { event: "InitiateCheckout", time: "09:13:08", status: "enviado" },
  { event: "AddPaymentInfo", time: "09:11:45", status: "enviado" },
  { event: "PageView", time: "09:09:30", status: "enviado" },
  { event: "Lead capturado", time: "09:08:12", status: "enviado" },
  { event: "Purchase", time: "08:58:04", status: "erro" }
];

export default function TrackingCenter() {
  return (
    <div>
      <div className="mb-5 pb-4 border-b border-white/5">
        <div className="flex items-center gap-2">
          <Radio className="h-4 w-4 text-primary" />
          <h3 className="font-display font-semibold text-white text-base">Central de rastreamento</h3>
        </div>
        <p className="text-xs text-muted-foreground mt-0.5">Conecte suas plataformas de anúncio e rastreadores para medir de onde vêm as vendas.</p>
      </div>
      <div className="space-y-3">
        {PLATFORMS.map((p) => <TrackingCard key={p.id} platform={p} />)}
      </div>
    </div>
  );
}

function TrackingCard({ platform }) {
  const { toast } = useToast();
  const [active, setActive] = useState(false);
  const [connected, setConnected] = useState(false);
  const [open, setOpen] = useState(false);
  const [creds, setCreds] = useState({});

  const setField = (k, v) => setCreds((c) => ({ ...c, [k]: v }));
  const hasCreds = platform.fields.every((f) => (creds[f.key] || "").trim().length > 0);

  const connect = () => {
    if (!hasCreds) { toast({ title: "Preencha as credenciais", variant: "destructive" }); return; }
    setConnected(true);
    setActive(true);
    toast({ title: `${platform.name} conectado`, description: "Eventos de conversão serão disparados." });
  };

  const statusLabel = connected ? "Conectado" : "Não conectado";
  const statusColor = connected ? "text-success" : "text-muted-foreground";

  return (
    <div className={cn("rounded-lg border p-4 transition-colors", active ? "border-primary/30 bg-primary/[0.04]" : "border-white/5 bg-white/[0.02]")}>
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <div className="flex items-center gap-2">
            <span className="text-sm text-white font-medium">{platform.name}</span>
            <span className={cn("inline-flex items-center gap-1 text-[10px]", statusColor)}>
              <span className={cn("h-1.5 w-1.5 rounded-full", connected ? "bg-success" : "bg-muted-foreground")} />
              {statusLabel}
            </span>
          </div>
          <p className="text-[11px] text-muted-foreground mt-0.5">{platform.desc}</p>
        </div>
        <div className="flex items-center gap-2 shrink-0">
          <button onClick={() => { setActive((a) => !a); if (!active) toast({ title: `${platform.name} ${active ? "desativado" : "ativado"}` }); }} className={cn("relative h-5 w-9 rounded-full transition-colors", active ? "bg-primary" : "bg-white/10")}>
            <span className="absolute top-0.5 h-4 w-4 rounded-full bg-white transition-all" style={{ left: active ? "18px" : "2px" }} />
          </button>
          <button onClick={() => setOpen((o) => !o)} className="flex h-7 w-7 items-center justify-center rounded-md bg-white/5 hover:bg-white/10 text-muted-foreground">
            <ChevronDown className={cn("h-4 w-4 transition-transform", open && "rotate-180")} />
          </button>
        </div>
      </div>

      {open && (
        <div className="mt-4 space-y-3 animate-fade-in">
          <div className="grid sm:grid-cols-2 gap-3">
            {platform.fields.map((f) => (
              <div key={f.key} className="space-y-1.5">
                <Label className="text-muted-foreground text-xs">{f.label}</Label>
                <Input value={creds[f.key] || ""} onChange={(e) => setField(f.key, e.target.value)} placeholder={f.placeholder} className="bg-background border-white/10 font-mono text-xs" />
              </div>
            ))}
          </div>
          <div className="flex items-center gap-2">
            <button onClick={connect} disabled={connected} className="rounded-md bg-primary hover:bg-[#E10600] px-3 py-1.5 text-xs font-medium text-white disabled:opacity-50">
              {connected ? "Conectado ✓" : "Conectar"}
            </button>
            {connected && <span className="text-[11px] text-success flex items-center gap-1"><CheckCircle2 className="h-3.5 w-3.5" /> Credenciais válidas</span>}
          </div>

          {/* Eventos disparados */}
          <div>
            <div className="flex items-center gap-1.5 text-[10px] uppercase tracking-[0.12em] text-muted-foreground font-semibold mb-2"><Activity className="h-3 w-3" /> Eventos disparados</div>
            <div className="flex flex-wrap gap-1.5">
              {platform.events.map((e) => <span key={e} className="text-[10px] px-2 py-0.5 rounded bg-white/5 border border-white/10 text-muted-foreground">{e}</span>)}
            </div>
          </div>

          {/* Log simples */}
          <div>
            <div className="text-[10px] uppercase tracking-[0.12em] text-muted-foreground font-semibold mb-2">Últimos eventos</div>
            <div className="rounded-md bg-black/30 border border-white/5 overflow-hidden">
              {SAMPLE_LOGS.map((l, i) => (
                <div key={i} className="flex items-center justify-between px-3 py-1.5 border-b border-white/[0.03] last:border-0">
                  <span className="text-[11px] text-white font-mono">{l.event}</span>
                  <div className="flex items-center gap-3">
                    <span className="text-[10px] text-muted-foreground font-mono">{l.time}</span>
                    <span className={cn("text-[10px] flex items-center gap-1", l.status === "enviado" ? "text-success" : "text-[#FF6A4D]")}>
                      {l.status === "enviado" ? <CheckCircle2 className="h-3 w-3" /> : <AlertTriangle className="h-3 w-3" />}
                      {l.status}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}