import React from "react";
import { cn } from "@/lib/utils";
import { Bot, MoreVertical, Pencil, Trash2, Power, Users, DollarSign, Percent } from "lucide-react";
import { formatCurrency } from "@/lib/mockData";
import { Image } from "@/components/ui/image";

export default function BotCard({ bot, flow, wallet, onEdit, onDelete, onToggle, onOpenFlow }) {
  return (
    <div className="group rounded-xl surface p-4 glow-soft hover:border-white/20 transition-colors">
      <div className="flex items-start gap-3">
        <div className="h-12 w-12 rounded-xl overflow-hidden border border-white/10 bg-[#0D0D0D] shrink-0 flex items-center justify-center">
          {bot.avatar ? <Image src={bot.avatar} alt={bot.name} fittingType="fill" className="h-full w-full object-cover" /> : <Bot className="h-6 w-6 text-muted-foreground" />}
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2">
            <h3 className="text-sm font-semibold text-white truncate">{bot.name}</h3>
            <span className={cn("h-1.5 w-1.5 rounded-full shrink-0", bot.status === "ativo" ? "bg-success animate-pulse-red" : "bg-muted-foreground")} />
          </div>
          <p className="text-[11px] text-muted-foreground truncate">Fluxo: {flow?.name || "—"}</p>
          <p className="text-[11px] text-muted-foreground truncate">Wallet: {wallet?.name || "—"}</p>
        </div>
        <div className="relative">
          <button onClick={onToggle} className={cn("h-8 w-8 rounded-lg flex items-center justify-center", bot.status === "ativo" ? "text-success hover:bg-success/10" : "text-muted-foreground hover:bg-white/5")} title={bot.status === "ativo" ? "Pausar" : "Ativar"}><Power className="h-4 w-4" /></button>
        </div>
      </div>

      <div className="grid grid-cols-3 gap-2 mt-4">
        <div className="rounded-lg bg-white/[0.02] border border-white/5 p-2.5">
          <div className="flex items-center gap-1 text-muted-foreground"><Users className="h-3 w-3" /><span className="text-[9px] uppercase tracking-wide">Contatos</span></div>
          <p className="text-sm font-semibold text-white mt-0.5">{bot.subscribers.toLocaleString("pt-BR")}</p>
        </div>
        <div className="rounded-lg bg-white/[0.02] border border-white/5 p-2.5">
          <div className="flex items-center gap-1 text-muted-foreground"><DollarSign className="h-3 w-3" /><span className="text-[9px] uppercase tracking-wide">Faturamento</span></div>
          <p className="text-sm font-semibold text-white mt-0.5">{formatCurrency(bot.revenue)}</p>
        </div>
        <div className="rounded-lg bg-white/[0.02] border border-white/5 p-2.5">
          <div className="flex items-center gap-1 text-muted-foreground"><Percent className="h-3 w-3" /><span className="text-[9px] uppercase tracking-wide">Conversão</span></div>
          <p className="text-sm font-semibold text-white mt-0.5">{bot.conversion}%</p>
        </div>
      </div>

      <div className="flex gap-2 mt-3">
        <button onClick={onEdit} className="flex-1 rounded-lg border border-white/10 hover:bg-white/5 text-[12px] font-medium text-white py-2 flex items-center justify-center gap-1.5"><Pencil className="h-3.5 w-3.5" /> Editar</button>
        <button onClick={onOpenFlow} className="flex-1 rounded-lg border border-white/10 hover:bg-white/5 text-[12px] font-medium text-white py-2 flex items-center justify-center gap-1.5"><MoreVertical className="h-3.5 w-3.5" /> Fluxo</button>
        <button onClick={onDelete} className="rounded-lg border border-white/10 hover:bg-danger/10 hover:text-danger text-muted-foreground px-3 py-2"><Trash2 className="h-3.5 w-3.5" /></button>
      </div>
    </div>
  );
}