import React, { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Button } from "@/components/ui/button";
import { useToast } from "@/components/ui/use-toast";
import { Loader2, Upload, Bot, ShieldCheck } from "lucide-react";
import { base44 } from "@/api/base44Client";

export default function BotEditorDialog({ open, onClose, onSave, bot, flows, wallets }) {
  const { toast } = useToast();
  const [form, setForm] = useState({ name: "", token: "", status: "ativo", flowId: "", walletId: "", ageGate: true, termsAccepted: true, avatar: null });
  const [saving, setUploading] = useState(false);

  useEffect(() => {
    if (open) setForm(bot ? { ...bot } : { name: "", token: "", status: "ativo", flowId: flows[0]?.id || "", walletId: wallets[0]?.id || "", ageGate: true, termsAccepted: true, avatar: null });
  }, [open, bot, flows, wallets]);

  const set = (patch) => setForm((f) => ({ ...f, ...patch }));

  const onAvatar = async (file) => {
    if (!file) return;
    setUploading(true);
    try {
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      set({ avatar: file_url });
    } catch (e) {
      toast({ title: "Falha no upload", description: String(e?.message || e), variant: "destructive" });
    } finally {
      setUploading(false);
    }
  };

  const submit = () => {
    if (!form.name || !form.token) {
      toast({ title: "Preencha nome e token", variant: "destructive" });
      return;
    }
    if (!form.termsAccepted) {
      toast({ title: "Aceite os termos do nicho hot obrigatório", variant: "destructive" });
      return;
    }
    onSave(form);
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-lg bg-[#0D0D0D] border-white/10">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2"><Bot className="h-4 w-4 text-primary" /> {bot ? "Editar bot" : "Criar novo bot"}</DialogTitle>
        </DialogHeader>
        <div className="space-y-4 max-h-[60vh] overflow-y-auto pr-1">
          <div className="flex items-center gap-4">
            <div className="h-16 w-16 rounded-xl overflow-hidden border border-white/10 bg-[#070707] flex items-center justify-center shrink-0">
              {form.avatar ? <img src={form.avatar} alt="" className="h-full w-full object-cover" /> : <Bot className="h-7 w-7 text-muted-foreground" />}
            </div>
            <div>
              <Label className="text-[11px] uppercase tracking-[0.1em] text-muted-foreground">Foto do bot</Label>
              <label className="mt-1 inline-flex items-center gap-2 rounded-lg border border-white/10 hover:bg-white/5 px-3 py-1.5 text-[12px] cursor-pointer">
                {saving ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Upload className="h-3.5 w-3.5" />}
                Enviar imagem
                <input type="file" accept="image/*" className="hidden" onChange={(e) => onAvatar(e.target.files?.[0])} />
              </label>
            </div>
          </div>

          <div className="space-y-1.5">
            <Label className="text-[11px] uppercase tracking-[0.1em] text-muted-foreground">Nome do bot</Label>
            <Input value={form.name || ""} onChange={(e) => set({ name: e.target.value })} placeholder="Ex: VIP Content Bot" />
          </div>
          <div className="space-y-1.5">
            <Label className="text-[11px] uppercase tracking-[0.1em] text-muted-foreground">Token do Telegram (BotFather)</Label>
            <Input value={form.token || ""} onChange={(e) => set({ token: e.target.value })} placeholder="8123456789:AAH-xxxxx" />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <Label className="text-[11px] uppercase tracking-[0.1em] text-muted-foreground">Fluxo vinculado</Label>
              <select value={form.flowId || ""} onChange={(e) => set({ flowId: e.target.value })} className="w-full h-9 rounded-md border border-input bg-transparent px-3 text-sm">
                <option value="">Selecione…</option>
                {flows.map((f) => <option key={f.id} value={f.id}>{f.name}</option>)}
              </select>
            </div>
            <div className="space-y-1.5">
              <Label className="text-[11px] uppercase tracking-[0.1em] text-muted-foreground">Wallet vinculada</Label>
              <select value={form.walletId || ""} onChange={(e) => set({ walletId: e.target.value })} className="w-full h-9 rounded-md border border-input bg-transparent px-3 text-sm">
                <option value="">Selecione…</option>
                {wallets.map((w) => <option key={w.id} value={w.id}>{w.name}</option>)}
              </select>
            </div>
          </div>
          <div className="flex items-center justify-between rounded-lg border border-white/10 p-3">
            <div>
              <p className="text-[12px] font-medium text-white">Status</p>
              <p className="text-[11px] text-muted-foreground">{form.status === "ativo" ? "Bot ativo" : "Bot pausado"}</p>
            </div>
            <Switch checked={form.status === "ativo"} onCheckedChange={(v) => set({ status: v ? "ativo" : "pausado" })} />
          </div>
          <div className="flex items-center justify-between rounded-lg border border-white/10 p-3">
            <div className="flex items-start gap-2">
              <ShieldCheck className="h-4 w-4 text-primary mt-0.5" />
              <div>
                <p className="text-[12px] font-medium text-white">Confirmação de maioridade (18+)</p>
                <p className="text-[11px] text-muted-foreground">Nó de gatilho obrigatório no início do fluxo</p>
              </div>
            </div>
            <Switch checked={form.ageGate} onCheckedChange={(v) => set({ ageGate: v })} />
          </div>
          <div className="rounded-lg border border-warning/30 bg-warning/5 p-3 space-y-2">
            <p className="text-[11px] text-white/80 leading-relaxed">
              Termos de uso — nicho hot: ao continuar, você concorda em não distribuir conteúdo não consensual, envolvendo menores ou qualquer material ilegal. Violações resultam em encerramento imediato da conta.
            </p>
            <label className="flex items-center gap-2 text-[12px] cursor-pointer">
              <Switch checked={form.termsAccepted} onCheckedChange={(v) => set({ termsAccepted: v })} />
              <span>Aceito os termos específicos do nicho hot</span>
            </label>
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" size="sm" onClick={onClose}>Cancelar</Button>
          <Button size="sm" onClick={submit}>{bot ? "Salvar" : "Criar bot"}</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}