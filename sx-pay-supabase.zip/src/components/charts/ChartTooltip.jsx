import React from "react";

// Tooltip escuro premium para recharts
export function ChartTooltip({ active, payload, label, currency = false, prefix = "", suffix = "" }) {
  if (!active || !payload || !payload.length) return null;
  return (
    <div className="rounded-lg border border-white/10 bg-popover px-3 py-2 shadow-2xl glow-soft">
      {label && <p className="text-[11px] text-muted-foreground mb-1">{label}</p>}
      {payload.map((entry, i) => (
        <div key={i} className="flex items-center gap-2 text-xs">
          <span className="h-2 w-2 rounded-full" style={{ background: entry.color || entry.fill }} />
          <span className="text-muted-foreground">{entry.name}:</span>
          <span className="text-white font-semibold tabular-nums">
            {currency
              ? (entry.value).toLocaleString("pt-BR", { style: "currency", currency: "BRL" })
              : `${prefix}${entry.value?.toLocaleString("pt-BR")}${suffix}`}
          </span>
        </div>
      ))}
    </div>
  );
}