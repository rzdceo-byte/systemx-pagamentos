import React from "react";
import { cn } from "@/lib/utils";

export default function Logo({ size = 32, showText = true, className }) {
  return (
    <div className={cn("flex items-center gap-2.5", className)}>
      





















      
      {showText &&
      <div className="flex flex-col leading-none">
          <span className="font-display font-bold text-white tracking-tight-display text-[15px]">
            SX<span className="text-primary">Pay</span>
          </span>
          <span className="text-[8px] uppercase tracking-[0.25em] text-muted-foreground font-medium mt-0.5">
            Elite
          </span>
        </div>
      }
    </div>);

}