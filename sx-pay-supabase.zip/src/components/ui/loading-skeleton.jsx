import React from "react";
import { cn } from "@/lib/utils";

export function LoadingSkeleton({ className }) {
  return <div className={cn("animate-pulse rounded-md bg-white/[0.04]", className)} />;
}

export function TableSkeleton({ rows = 6, cols = 5 }) {
  return (
    <div className="space-y-1">
      {Array.from({ length: rows }).map((_, r) => (
        <div key={r} className="flex gap-4 py-3.5 px-4 border-b border-white/[0.03]">
          {Array.from({ length: cols }).map((_, c) => (
            <LoadingSkeleton key={c} className={cn("h-4 flex-1", c === 0 && "max-w-[120px]")} />
          ))}
        </div>
      ))}
    </div>
  );
}

export function CardSkeleton() {
  return (
    <div className="rounded-xl surface p-5 glow-soft">
      <LoadingSkeleton className="h-3 w-24 mb-4" />
      <LoadingSkeleton className="h-7 w-32 mb-3" />
      <LoadingSkeleton className="h-3 w-20" />
    </div>
  );
}