import React from "react";
import { cn } from "@/lib/utils";

const STATUS_CONFIG = {
  aprovado: { label: "Aprovado", className: "bg-success/10 text-success border-success/20" },
  pendente: { label: "Pendente", className: "bg-warning/10 text-warning border-warning/20" },
  recusado: { label: "Recusado", className: "bg-white/5 text-muted-foreground border-white/10" },
  reembolsado: { label: "Reembolsado", className: "bg-purple-500/10 text-purple-300 border-purple-500/20" },
  chargeback: { label: "Chargeback", className: "bg-[#C10000]/15 text-[#FF5A4D] border-[#C10000]/30" },
  ativo: { label: "Ativo", className: "bg-success/10 text-success border-success/20" },
  inativo: { label: "Inativo", className: "bg-white/5 text-muted-foreground border-white/10" },
  lead: { label: "Lead", className: "bg-blue-500/10 text-blue-300 border-blue-500/20" },
  rascunho: { label: "Rascunho", className: "bg-white/5 text-muted-foreground border-white/10" },
  processando: { label: "Processando", className: "bg-warning/10 text-warning border-warning/20" },
  concluido: { label: "Concluído", className: "bg-success/10 text-success border-success/20" }
};

export default function StatusBadge({ status, className }) {
  const config = STATUS_CONFIG[status] || { label: status, className: "bg-white/5 text-muted-foreground border-white/10" };
  return (
    <span className={cn("inline-flex items-center gap-1.5 rounded-md border px-2 py-0.5 text-[11px] font-medium", config.className, className)}>
      <span className="h-1.5 w-1.5 rounded-full bg-current opacity-70" />
      {config.label}
    </span>
  );
}

export { STATUS_CONFIG };