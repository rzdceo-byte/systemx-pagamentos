import React, { useState, useEffect, useRef } from "react";

// Hook: anima um número de 0 até `target` ao montar (count-up)
export function useCountUp(target, duration = 1200, decimals = 0) {
  const [val, setVal] = useState(0);
  const startedRef = useRef(false);

  useEffect(() => {
    if (startedRef.current) return;
    startedRef.current = true;
    const start = performance.now();
    const from = 0;
    const to = Number(target) || 0;
    let raf;
    const tick = (now) => {
      const p = Math.min(1, (now - start) / duration);
      const eased = 1 - Math.pow(1 - p, 3); // easeOutCubic
      setVal(from + (to - from) * eased);
      if (p < 1) raf = requestAnimationFrame(tick);
      else setVal(to);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [target, duration]);

  return val;
}

// Componente: exibe número formatado com count-up
export default function CountUp({ value, prefix = "", suffix = "", decimals = 0, className }) {
  const v = useCountUp(value, 1300, decimals);
  const formatted = v.toLocaleString("pt-BR", { minimumFractionDigits: decimals, maximumFractionDigits: decimals });
  return <span className={className}>{prefix}{formatted}{suffix}</span>;
}