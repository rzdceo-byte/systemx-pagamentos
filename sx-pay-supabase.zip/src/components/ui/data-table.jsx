import React from "react";
import { cn } from "@/lib/utils";

export function DataTable({ columns, data, onRowClick, emptyMessage = "Nenhum registro encontrado" }) {
  return (
    <div className="w-full overflow-x-auto">
      <table className="w-full">
        <thead>
          <tr className="border-b border-white/5">
            {columns.map((col) => (
              <th
                key={col.key}
                className={cn(
                  "text-left text-[10px] uppercase tracking-[0.12em] text-muted-foreground font-semibold py-3 px-4 whitespace-nowrap",
                  col.align === "right" && "text-right",
                  col.className
                )}
              >
                {col.header}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {data.length === 0 ? (
            <tr>
              <td colSpan={columns.length} className="py-12 text-center text-sm text-muted-foreground">
                {emptyMessage}
              </td>
            </tr>
          ) : (
            data.map((row, i) => (
              <tr
                key={row.id || i}
                onClick={() => onRowClick?.(row)}
                className={cn(
                  "border-b border-white/[0.03] transition-colors",
                  onRowClick && "cursor-pointer hover:bg-white/[0.02]"
                )}
              >
                {columns.map((col) => (
                  <td
                    key={col.key}
                    className={cn(
                      "py-3.5 px-4 text-sm text-foreground/90 whitespace-nowrap",
                      col.align === "right" && "text-right tabular-nums",
                      col.cellClassName
                    )}
                  >
                    {col.render ? col.render(row) : row[col.key]}
                  </td>
                ))}
              </tr>
            ))
          )}
        </tbody>
      </table>
    </div>
  );
}