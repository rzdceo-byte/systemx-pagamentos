import React from "react";
import { cn } from "@/lib/utils";

export default function EmptyState({ icon: Icon, title, description, action, className }) {
  return (
    <div className={cn("flex flex-col items-center justify-center py-16 px-6 text-center", className)}>
      {Icon && (
        <div className="relative mb-5">
          <div className="absolute inset-0 rounded-full bg-primary/10 blur-xl" />
          <div className="relative flex h-16 w-16 items-center justify-center rounded-2xl surface">
            <Icon className="h-7 w-7 text-primary/60" />
          </div>
        </div>
      )}
      <h3 className="font-display font-semibold text-white text-base mb-1.5">{title}</h3>
      {description && <p className="text-sm text-muted-foreground max-w-sm">{description}</p>}
      {action && <div className="mt-5">{action}</div>}
    </div>
  );
}