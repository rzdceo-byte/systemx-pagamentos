import React from "react";
import { cn } from "@/lib/utils";
import { ArrowUpRight, ArrowDownRight } from "lucide-react";

export default function StatCard({ label, value, prefix = "", suffix = "", decimals = 2, isCount = false, trend, trendLabel, icon: Icon, accent = false }) {
  const positive = (trend ?? 0) >= 0;
  const TrendIcon = positive ? ArrowUpRight : ArrowDownRight;
  const formatted = isCount
    ? value.toLocaleString("pt-BR")
    : value.toLocaleString("pt-BR", { minimumFractionDigits: decimals, maximumFractionDigits: decimals });

  return (
    <div
      className={cn(
        "group relative rounded-xl p-5 surface glow-soft transition-all duration-300 hover:-translate-y-0.5",
        accent && "glow-red-sm"
      )}
    >
      <div className="flex items-start justify-between mb-4">
        <div className="flex items-center gap-2.5">
          {Icon && (
            <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-black/40 border border-white/5">
              <Icon className="h-4 w-4 text-primary" />
            </div>
          )}
          <span className="text-[11px] uppercase tracking-[0.15em] text-muted-foreground font-medium">
            {label}
          </span>
        </div>
      </div>

      <div className="font-display font-bold tracking-tight-display text-2xl text-white tabular-nums">
        {prefix}{formatted}{suffix}
      </div>

      {typeof trend === "number" && (
        <div className="mt-3 flex items-center gap-1.5">
          <span
            className={cn(
              "inline-flex items-center gap-0.5 rounded-md px-1.5 py-0.5 text-[11px] font-semibold",
              positive ? "bg-success/10 text-success" : "bg-[#E10600]/10 text-[#FF6A4D]"
            )}
          >
            <TrendIcon className="h-3 w-3" />
            {positive ? "+" : ""}{trend}%
          </span>
          {trendLabel && <span className="text-[11px] text-muted-foreground">{trendLabel}</span>}
        </div>
      )}

      {accent && (
        <div className="absolute top-3 right-3 text-[8px] uppercase tracking-[0.2em] text-primary/60 font-semibold">
          SXPay Elite
        </div>
      )}
    </div>
  );
}