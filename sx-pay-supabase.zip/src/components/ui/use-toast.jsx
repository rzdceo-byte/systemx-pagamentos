import { useState, useEffect } from "react";

// Sistema de Toasts — feedback temporário de ações.
// Cada toast some sozinho após `duration` (ms), com seu próprio temporizador.
// Fechar manualmente limpa o timer daquele toast sem afetar os outros.

const TOAST_LIMIT = 20;
const DEFAULT_DURATION = 5000;

let count = 0;
function genId() {
  count = (count + 1) % Number.MAX_VALUE;
  return count.toString();
}

const listeners = [];
let memoryState = { toasts: [] };

// Mapa de timers de auto-remoção por id do toast.
const autoTimers = new Map();
function clearAutoTimer(id) {
  const t = autoTimers.get(id);
  if (t) { clearTimeout(t); autoTimers.delete(id); }
}
function scheduleAutoRemove(id, duration) {
  clearAutoTimer(id);
  const t = setTimeout(() => {
    autoTimers.delete(id);
    dispatch({ type: "REMOVE_TOAST", toastId: id });
  }, duration);
  autoTimers.set(id, t);
}

function reducer(state, action) {
  switch (action.type) {
    case "ADD_TOAST":
      return { ...state, toasts: [action.toast, ...state.toasts].slice(0, TOAST_LIMIT) };
    case "UPDATE_TOAST":
      return {
        ...state,
        toasts: state.toasts.map((t) => (t.id === action.toast.id ? { ...t, ...action.toast } : t))
      };
    case "DISMISS_TOAST": {
      // Fecha imediatamente (manual ou programado) — remove do array aquele id.
      if (action.toastId === undefined) return { ...state, toasts: [] };
      clearAutoTimer(action.toastId);
      return { ...state, toasts: state.toasts.filter((t) => t.id !== action.toastId) };
    }
    case "REMOVE_TOAST":
      if (action.toastId === undefined) return { ...state, toasts: [] };
      return { ...state, toasts: state.toasts.filter((t) => t.id !== action.toastId) };
    default:
      return state;
  }
}

function dispatch(action) {
  memoryState = reducer(memoryState, action);
  listeners.forEach((listener) => listener(memoryState));
}

function toast({ duration = DEFAULT_DURATION, ...props } = {}) {
  const id = genId();
  dispatch({ type: "ADD_TOAST", toast: { id, open: true, ...props } });
  if (duration > 0) scheduleAutoRemove(id, duration);

  return {
    id,
    dismiss: () => { clearAutoTimer(id); dispatch({ type: "DISMISS_TOAST", toastId: id }); },
    update: (p) => dispatch({ type: "UPDATE_TOAST", toast: { ...p, id } })
  };
}

function dismiss(toastId) {
  if (toastId === undefined) {
    memoryState.toasts.forEach((t) => clearAutoTimer(t.id));
    dispatch({ type: "DISMISS_TOAST" });
  } else {
    clearAutoTimer(toastId);
    dispatch({ type: "DISMISS_TOAST", toastId });
  }
}

function useToast() {
  const [state, setState] = useState(memoryState);

  useEffect(() => {
    listeners.push(setState);
    return () => {
      const index = listeners.indexOf(setState);
      if (index > -1) listeners.splice(index, 1);
    };
  }, []);

  return { ...state, toast, dismiss };
}

export { useToast, toast };