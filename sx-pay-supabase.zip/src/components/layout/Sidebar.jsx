import React, { useState } from "react";
import { Link, useLocation } from "react-router-dom";
import { cn } from "@/lib/utils";
import {
  LayoutDashboard, TrendingUp, CreditCard, Package, Users,
  ArrowLeftRight, Wallet, BarChart3, Settings, RotateCcw, ChevronLeft,
  Bot, Workflow, ChevronDown } from "lucide-react";
import Logo from "@/components/Logo";

const BOTS_CHILDREN = [
  { label: "Meus Bots", path: "/bots/meus-bots", icon: Bot },
  { label: "Construtor de Fluxos", path: "/bots/fluxos", icon: Workflow },
  { label: "Wallet Hot", path: "/bots/wallet", icon: Wallet },
  { label: "Relatórios do Bot", path: "/bots/relatorios", icon: BarChart3 }
];

export const NAV_ITEMS = [
  { label: "Dashboard", path: "/", icon: LayoutDashboard },
  { label: "Vendas", path: "/vendas", icon: TrendingUp },
  { label: "Checkout", path: "/checkout", icon: CreditCard },
  { label: "Produtos", path: "/produtos", icon: Package },
  { label: "Clientes", path: "/clientes", icon: Users },
  { label: "Recuperação", path: "/recuperacao", icon: RotateCcw },
  { label: "Transações", path: "/transacoes", icon: ArrowLeftRight },
  { label: "Financeiro", path: "/financeiro", icon: Wallet },
  { label: "Relatórios", path: "/relatorios", icon: BarChart3 },
  { label: "Configurações", path: "/configuracoes", icon: Settings },
  { label: "Bots & Fluxos", path: "/bots/meus-bots", icon: Bot, children: BOTS_CHILDREN }
];

function isBotsActive(pathname) {
  return pathname.startsWith("/bots");
}

export default function Sidebar({ collapsed, onToggle }) {
  const location = useLocation();
  const [botsOpen, setBotsOpen] = useState(true);

  return (
    <aside
      className={cn(
        "hidden lg:flex flex-col shrink-0 border-r border-white/5 bg-[#070707] transition-all duration-300 sticky top-0 h-screen",
        collapsed ? "w-[72px]" : "w-[244px]"
      )}
    >
      <div className={cn("flex items-center h-16 border-b border-white/5", collapsed ? "justify-center px-2" : "px-5")}>
        <Logo showText={!collapsed} size={32} />
      </div>

      <nav className="flex-1 overflow-y-auto py-4 px-3 space-y-0.5">
        {NAV_ITEMS.map((item) => {
          if (item.children) {
            const groupActive = isBotsActive(location.pathname);
            return (
              <div key={item.label}>
                <button
                  onClick={() => setBotsOpen((v) => !v)}
                  className={cn(
                    "group relative flex w-full items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition-all",
                    collapsed && "justify-center",
                    groupActive ? "bg-primary/10 text-white" : "text-muted-foreground hover:text-white hover:bg-white/[0.03]"
                  )}
                  title={collapsed ? item.label : undefined}
                >
                  {groupActive && <span className="absolute left-0 top-1/2 -translate-y-1/2 h-5 w-[3px] rounded-full bg-primary glow-red-sm" />}
                  <item.icon className={cn("h-[18px] w-[18px] shrink-0", groupActive && "text-primary")} />
                  {!collapsed && (
                    <>
                      <span className="truncate flex-1 text-left">{item.label}</span>
                      <ChevronDown className={cn("h-4 w-4 transition-transform", botsOpen && "rotate-180")} />
                    </>
                  )}
                </button>
                {!collapsed && botsOpen && (
                  <div className="ml-4 mt-0.5 space-y-0.5 border-l border-white/5 pl-2">
                    {item.children.map((child) => {
                      const active = location.pathname === child.path;
                      return (
                        <Link
                          key={child.path}
                          to={child.path}
                          className={cn(
                            "flex items-center gap-2.5 rounded-lg px-3 py-2 text-[13px] font-medium transition-colors",
                            active ? "bg-primary/10 text-white" : "text-muted-foreground hover:text-white hover:bg-white/[0.03]"
                          )}
                        >
                          <child.icon className={cn("h-[15px] w-[15px] shrink-0", active && "text-primary")} />
                          <span className="truncate">{child.label}</span>
                        </Link>
                      );
                    })}
                  </div>
                )}
              </div>
            );
          }

          const active = location.pathname === item.path;
          return (
            <Link
              key={item.path}
              to={item.path}
              className={cn(
                "group relative flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition-all",
                collapsed && "justify-center",
                active ? "bg-primary/10 text-white" : "text-muted-foreground hover:text-white hover:bg-white/[0.03]"
              )}
              title={collapsed ? item.label : undefined}
            >
              {active && <span className="absolute left-0 top-1/2 -translate-y-1/2 h-5 w-[3px] rounded-full bg-primary glow-red-sm" />}
              <item.icon className={cn("h-[18px] w-[18px] shrink-0", active && "text-primary")} />
              {!collapsed && <span className="truncate">{item.label}</span>}
            </Link>
          );
        })}
      </nav>

      <div className="p-3 border-t border-white/5">
        <button
          onClick={onToggle}
          className="flex w-full items-center gap-3 rounded-lg px-3 py-2 text-sm text-muted-foreground hover:text-white hover:bg-white/[0.03] transition-colors"
        >
          <ChevronLeft className={cn("h-[18px] w-[18px] transition-transform", collapsed && "rotate-180")} />
          {!collapsed && <span>Recolher</span>}
        </button>
      </div>
    </aside>
  );
}