import React, { useState, useRef, useEffect } from "react";
import { Link, useLocation } from "react-router-dom";
import { cn } from "@/lib/utils";
import { Bell, Search, ChevronDown, LogOut, User, Settings as SettingsIcon, Menu, Trash2 } from "lucide-react";
import Logo from "@/components/Logo";
import AreaHelpButton from "@/components/tour/AreaHelpButton";
import { account, notifications as initialNotifs } from "@/lib/mockData";

export default function Header({ onMenuClick }) {
  const location = useLocation();
  const [notifOpen, setNotifOpen] = useState(false);
  const [userOpen, setUserOpen] = useState(false);
  const [mobileSearch, setMobileSearch] = useState(false);
  const notifRef = useRef(null);
  const userRef = useRef(null);
  const [notifs, setNotifs] = useState(() => initialNotifs.map((n) => ({ ...n, read: false })));
  const unread = notifs.filter((n) => !n.read).length;
  const markAllRead = () => setNotifs((prev) => prev.map((n) => ({ ...n, read: true })));
  const removeNotif = (id) => setNotifs((prev) => prev.filter((n) => n.id !== id));

  useEffect(() => {
    const handler = (e) => {
      if (notifRef.current && !notifRef.current.contains(e.target)) setNotifOpen(false);
      if (userRef.current && !userRef.current.contains(e.target)) setUserOpen(false);
    };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, []);

  const pageTitle = (() => {
    const map = {
      "/": "Dashboard",
      "/vendas": "Vendas",
      "/checkout": "Checkout",
      "/produtos": "Produtos",
      "/clientes": "Clientes",
      "/transacoes": "Transações",
      "/financeiro": "Financeiro",
      "/relatorios": "Relatórios",
      "/configuracoes": "Configurações"
    };
    return map[location.pathname] || "SXPay";
  })();

  return (
    <header className="sticky top-0 z-30 flex h-16 items-center gap-3 border-b border-white/5 bg-background/80 backdrop-blur-xl px-4 lg:px-6">
      <button onClick={onMenuClick} className="lg:hidden p-2 -ml-1 text-muted-foreground hover:text-white">
        <Menu className="h-5 w-5" />
      </button>

      <div className="lg:hidden">
        <Logo showText={false} size={30} />
      </div>

      <div className="hidden lg:block">
        <h1 className="font-display font-semibold text-white tracking-tight-display text-[15px]">{pageTitle}</h1>
        <p className="text-[11px] text-muted-foreground">Bem-vindo de volta, {account.name.split(" ")[0]}</p>
      </div>

      <div className="ml-auto flex items-center gap-1.5 sm:gap-2">
        <button
          onClick={() => setMobileSearch((s) => !s)}
          className="flex h-9 w-9 items-center justify-center rounded-lg text-muted-foreground hover:text-white hover:bg-white/5 transition-colors"
        >
          <Search className="h-[18px] w-[18px]" />
        </button>

        <div className="relative" ref={notifRef}>
          <button
            onClick={() => setNotifOpen((o) => !o)}
            className="relative flex h-9 w-9 items-center justify-center rounded-lg text-muted-foreground hover:text-white hover:bg-white/5 transition-colors"
          >
            <Bell className="h-[18px] w-[18px]" />
            {unread > 0 && <span className="absolute top-1.5 right-1.5 h-2 w-2 rounded-full bg-primary animate-pulse-red" />}
          </button>

          {notifOpen && (
            <div className="absolute right-0 mt-2 w-[320px] rounded-xl border border-white/10 bg-popover shadow-2xl glow-soft animate-fade-in overflow-hidden">
              <div className="flex items-center justify-between px-4 py-3 border-b border-white/5">
                <span className="text-sm font-semibold text-white">Notificações</span>
                {unread > 0 ? (
                  <button onClick={markAllRead} className="text-[10px] px-1.5 py-0.5 rounded bg-primary/15 text-primary font-medium hover:bg-primary/25 transition-colors">Marcar todas como lidas</button>
                ) : (
                  <span className="text-[10px] text-muted-foreground">Tudo lido</span>
                )}
              </div>
              <div className="max-h-[320px] overflow-y-auto">
                {notifs.length === 0 ? (
                  <p className="px-4 py-8 text-center text-xs text-muted-foreground">Sem notificações</p>
                ) : notifs.map((n) => (
                  <div key={n.id} className="group flex gap-3 px-4 py-3 border-b border-white/[0.03] hover:bg-white/[0.02] transition-colors">
                    <div className={cn(
                      "mt-1.5 h-2 w-2 rounded-full shrink-0",
                      n.read ? "bg-transparent border border-white/15" : n.type === "success" ? "bg-success" : n.type === "danger" ? "bg-[#E10600]" : "bg-blue-400"
                    )} />
                    <div className="min-w-0 flex-1">
                      <p className={cn("text-sm leading-tight", n.read ? "text-muted-foreground font-normal" : "text-white font-medium")}>{n.title}</p>
                      <p className="text-xs text-muted-foreground truncate">{n.desc}</p>
                      <p className="text-[10px] text-muted-foreground/70 mt-0.5">{n.time}</p>
                    </div>
                    <button onClick={() => removeNotif(n.id)} title="Excluir notificação" className="opacity-0 group-hover:opacity-100 focus:opacity-100 transition-opacity flex h-6 w-6 items-center justify-center rounded text-muted-foreground hover:text-[#FF6A4D] hover:bg-white/5">
                      <Trash2 className="h-3.5 w-3.5" />
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        <AreaHelpButton />

        <div className="relative" ref={userRef}>
          <button
            onClick={() => setUserOpen((o) => !o)}
            className="flex items-center gap-2 rounded-lg pl-1 pr-2 py-1 hover:bg-white/5 transition-colors"
          >
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-gradient-to-br from-[#8A0303] to-[#1a1a1a] text-white text-xs font-semibold border border-primary/30">
              {account.name.split(" ").map((n) => n[0]).join("").slice(0, 2)}
            </div>
            <div className="hidden sm:block text-left leading-tight">
              <div className="text-xs font-semibold text-white">{account.name}</div>
              <div className="text-[10px] text-primary">{account.plan}</div>
            </div>
            <ChevronDown className="hidden sm:block h-3.5 w-3.5 text-muted-foreground" />
          </button>

          {userOpen && (
            <div className="absolute right-0 mt-2 w-60 rounded-xl border border-white/10 bg-popover shadow-2xl glow-soft animate-fade-in overflow-hidden">
              <div className="px-4 py-3 border-b border-white/5">
                <p className="text-sm font-semibold text-white">{account.name}</p>
                <p className="text-xs text-muted-foreground truncate">{account.email}</p>
              </div>
              <div className="py-1">
                <Link to="/configuracoes" className="flex items-center gap-2.5 px-4 py-2 text-sm text-muted-foreground hover:text-white hover:bg-white/5">
                  <User className="h-4 w-4" /> Perfil
                </Link>
                <Link to="/configuracoes" className="flex items-center gap-2.5 px-4 py-2 text-sm text-muted-foreground hover:text-white hover:bg-white/5">
                  <SettingsIcon className="h-4 w-4" /> Configurações
                </Link>
              </div>
              <div className="border-t border-white/5 py-1">
                <button className="flex w-full items-center gap-2.5 px-4 py-2 text-sm text-[#FF6A4D] hover:bg-white/5">
                  <LogOut className="h-4 w-4" /> Sair
                </button>
              </div>
            </div>
          )}
        </div>
      </div>

      {mobileSearch && (
        <div className="absolute top-16 left-0 right-0 border-b border-white/5 bg-background px-4 py-3 lg:hidden">
          <input
            autoFocus
            placeholder="Buscar transações, clientes, produtos..."
            className="w-full rounded-lg bg-white/5 border border-white/10 px-3 py-2 text-sm text-white placeholder:text-muted-foreground focus:outline-none focus:border-primary/50"
          />
        </div>
      )}
    </header>
  );
}