import React, { useMemo } from "react";
import { pickRandomPhrase } from "@/lib/systemxPhrases";

// Rodapé da marca, visível em todas as telas internas. Discreto.
// A frase é sorteada uma única vez ao montar (só troca ao recarregar a página).
export default function SystemxFooter() {
  const phrase = useMemo(() => pickRandomPhrase(), []);

  return (
    <footer className="border-t border-white/5 bg-background/60 px-4 lg:px-8 py-3">
      <div className="mx-auto flex max-w-[1400px] items-center justify-center gap-2.5 text-center">
        <span className="font-display font-bold text-[11px] tracking-[0.32em] text-white/75">SYSTEMX VIVE</span>
        <span className="hidden sm:inline h-3 w-px bg-white/15" />
        <span className="text-[11px] italic text-muted-foreground/70 truncate max-w-[60%] sm:max-w-md">{phrase}</span>
      </div>
    </footer>
  );
}