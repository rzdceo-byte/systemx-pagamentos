import React from "react";
import { Link, useLocation } from "react-router-dom";
import { cn } from "@/lib/utils";
import { X } from "lucide-react";
import Logo from "@/components/Logo";
import { NAV_ITEMS } from "./Sidebar";
import { account } from "@/lib/mockData";

export function MobileNav({ open, onClose }) {
  const location = useLocation();
  if (!open) return null;

  return (
    <div className="fixed inset-0 z-50 lg:hidden">
      <div className="absolute inset-0 bg-black/70 backdrop-blur-sm" onClick={onClose} />
      <div className="absolute left-0 top-0 h-full w-[280px] bg-[#070707] border-r border-white/5 flex flex-col animate-fade-in">
        <div className="flex items-center justify-between h-16 px-5 border-b border-white/5">
          <Logo size={30} />
          <button onClick={onClose} className="p-1.5 text-muted-foreground hover:text-white">
            <X className="h-5 w-5" />
          </button>
        </div>
        <nav className="flex-1 overflow-y-auto py-4 px-3 space-y-0.5">
          {NAV_ITEMS.map((item) => {
            if (item.children) {
              const groupActive = location.pathname.startsWith("/bots");
              return (
                <div key={item.label}>
                  <div className={cn("px-3 py-2 text-[10px] uppercase tracking-[0.14em] font-semibold", groupActive ? "text-primary" : "text-muted-foreground")}>
                    {item.label}
                  </div>
                  <div className="ml-3 space-y-0.5 border-l border-white/5 pl-2">
                    {item.children.map((child) => {
                      const active = location.pathname === child.path;
                      return (
                        <Link
                          key={child.path}
                          to={child.path}
                          onClick={onClose}
                          className={cn(
                            "flex items-center gap-2.5 rounded-lg px-3 py-2.5 text-[13px] font-medium transition-colors",
                            active ? "bg-primary/10 text-white" : "text-muted-foreground hover:text-white hover:bg-white/[0.03]"
                          )}
                        >
                          <child.icon className={cn("h-[15px] w-[15px]", active && "text-primary")} />
                          {child.label}
                        </Link>
                      );
                    })}
                  </div>
                </div>
              );
            }
            const active = location.pathname === item.path;
            return (
              <Link
                key={item.path}
                to={item.path}
                onClick={onClose}
                className={cn(
                  "flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition-colors",
                  active ? "bg-primary/10 text-white" : "text-muted-foreground hover:text-white hover:bg-white/[0.03]"
                )}
              >
                <item.icon className={cn("h-[18px] w-[18px]", active && "text-primary")} />
                {item.label}
              </Link>
            );
          })}
        </nav>
        <div className="p-4 border-t border-white/5">
          <div className="text-xs text-muted-foreground">{account.email}</div>
          <div className="text-[10px] text-primary mt-0.5">{account.plan}</div>
        </div>
      </div>
    </div>
  );
}