import React, { useState, useMemo, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Send, RotateCcw, CheckCircle2 } from "lucide-react";

function nodeContent(node) {
  const d = node.data || {};
  switch (node.type) {
    case "start": return { kind: "system", text: "Conversa iniciada com /start" };
    case "age_confirmation": return { kind: "system", text: d.message || "Confirmação de maioridade (18+) exibida." };
    case "text": return { kind: "bot", text: d.message };
    case "buttons": return { kind: "bot", text: d.message, buttons: d.options };
    case "offer": return { kind: "bot", text: `🛒 ${d.name || "Oferta"} — R$ ${Number(d.price || 0).toFixed(2)}\nMétodos: ${(d.methods || []).join(", ")}`, cta: "Comprar agora" };
    case "order_bump": return { kind: "bot", text: `➕ ${d.name || "Order bump"} +R$ ${Number(d.price || 0).toFixed(2)}`, cta: "Adicionar" };
    case "upsell": return { kind: "bot", text: `⬆️ ${d.name || "Upsell"} — R$ ${Number(d.price || 0).toFixed(2)}`, cta: "Aceitar oferta" };
    case "downsell": return { kind: "bot", text: `⬇️ ${d.name || "Downsell"} — R$ ${Number(d.price || 0).toFixed(2)}`, cta: "Aproveitar" };
    case "delay": return { kind: "system", text: `⏳ Aguardando ${d.seconds || 0}s…` };
    case "tag": return { kind: "system", text: `Etiqueta aplicada: ${d.tag || "…"}` };
    case "webhook": return { kind: "system", text: `Webhook ${d.method || "POST"} enviado para ${d.url || "…"}` };
    default: return { kind: "bot", text: `[${node.type}]` };
  }
}

export default function FlowTester({ open, onClose, flow }) {
  const sequence = useMemo(() => {
    if (!flow) return [];
    const { nodes, edges } = flow;
    const start = nodes.find((n) => !NODE_INPUTS(n, edges));
    const order = [];
    const visited = new Set();
    const queue = [start?.id].filter(Boolean);
    while (queue.length) {
      const id = queue.shift();
      if (visited.has(id)) continue;
      visited.add(id);
      const node = nodes.find((n) => n.id === id);
      if (node) order.push(node);
      edges.filter((e) => e.from === id).forEach((e) => { if (!visited.has(e.to)) queue.push(e.to); });
    }
    return order;
  }, [flow]);

  const [step, setStep] = useState(0);
  const [items, setItems] = useState([]);
  const [done, setDone] = useState(false);

  useEffect(() => {
    if (open) { setStep(0); setItems([]); setDone(false); }
  }, [open]);

  useEffect(() => {
    if (!open || step >= sequence.length) { if (step >= sequence.length && sequence.length) setDone(true); return; }
    const node = sequence[step];
    const content = nodeContent(node);
    const t = setTimeout(() => setItems((prev) => [...prev, { id: node.id, type: node.type, ...content }]), 300);
    return () => clearTimeout(t);
  }, [step, open, sequence]);

  const next = () => {
    if (step < sequence.length) setStep((s) => s + 1);
  };
  const restart = () => { setStep(0); setItems([]); setDone(false); };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-md bg-[#0D0D0D] border-white/10">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2"><Send className="h-4 w-4 text-primary" /> Testar fluxo — {flow?.name}</DialogTitle>
        </DialogHeader>
        <div className="rounded-xl surface p-3 h-[360px] overflow-y-auto flex flex-col gap-2 bg-circuit">
          {items.length === 0 && <p className="text-[12px] text-muted-foreground text-center mt-8">Iniciando simulação de conversa…</p>}
          {items.map((it) => (
            <div key={it.id} className={it.kind === "system" ? "flex justify-center" : "flex justify-end animate-fade-in"}>
              {it.kind === "system" ? (
                <span className="text-[10px] text-muted-foreground bg-white/[0.03] rounded-full px-2.5 py-1">{it.text}</span>
              ) : (
                <div className="max-w-[80%]">
                  <div className="rounded-2xl rounded-br-sm bg-[#2a2a2a] px-3 py-2 text-[12px] text-white/90 leading-snug whitespace-pre-wrap">{it.text}</div>
                  {it.buttons && (
                    <div className="mt-1.5 flex flex-col gap-1">
                      {it.buttons.map((b) => <span key={b.id} className="text-center rounded-lg bg-primary/15 border border-primary/30 px-2.5 py-1 text-[11px] text-white">{b.label}</span>)}
                    </div>
                  )}
                  {it.cta && <button className="mt-1.5 w-full rounded-lg bg-primary text-white text-[11px] font-semibold py-1.5">{it.cta}</button>}
                </div>
              )}
            </div>
          ))}
          {done && (
            <div className="flex justify-center mt-2"><span className="inline-flex items-center gap-1.5 text-[11px] text-success bg-success/10 rounded-full px-3 py-1"><CheckCircle2 className="h-3.5 w-3.5" /> Fluxo concluído</span></div>
          )}
        </div>
        <DialogFooter>
          <Button variant="outline" size="sm" onClick={restart}><RotateCcw className="h-3.5 w-3.5" /> Reiniciar</Button>
          <Button size="sm" onClick={next} disabled={done || step >= sequence.length}>Próximo passo</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function NODE_INPUTS(node, edges) {
  return edges.some((e) => e.to === node.id);
}