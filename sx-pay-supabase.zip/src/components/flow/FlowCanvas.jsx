import React, { useRef, useState, useEffect } from "react";
import FlowNode, { NODE_W, PORT_IN_Y, outPortPos, inPortPos } from "./FlowNode";
import { ZoomIn, ZoomOut, Maximize } from "lucide-react";

function bezier(x1, y1, x2, y2) {
  const dx = Math.max(40, Math.abs(x2 - x1) * 0.5);
  return `M ${x1} ${y1} C ${x1 + dx} ${y1}, ${x2 - dx} ${y2}, ${x2} ${y2}`;
}

export default function FlowCanvas({ nodes, edges, selectedId, onSelect, onMoveNode, onConnect, onDeleteEdge, onAddNode }) {
  const containerRef = useRef(null);
  const [zoom, setZoom] = useState(1);
  const [pan, setPan] = useState({ x: 24, y: 20 });
  const [pending, setPending] = useState(null);
  const dragRef = useRef(null);
  const panRef = useRef(pan); panRef.current = pan;
  const zoomRef = useRef(zoom); zoomRef.current = zoom;
  // Refs dos callbacks/nós → os listeners globais são registrados uma única vez,
  // evitando rebind (e perda de gesto) quando o FlowBuilder re-renderiza.
  const nodesRef = useRef(nodes); nodesRef.current = nodes;
  const onMoveNodeRef = useRef(onMoveNode); onMoveNodeRef.current = onMoveNode;
  const onConnectRef = useRef(onConnect); onConnectRef.current = onConnect;

  // Detecção de nó alvo ampliada para incluir os "nós" (portas) de entrada/saída
  // que ficam projetados para fora do card — soltar sobre a porta de entrada conta.
  const nodeAt = (x, y) => nodesRef.current.find((n) => x >= n.x - 14 && x <= n.x + NODE_W + 14 && y >= n.y - 10 && y <= n.y + 130);

  useEffect(() => {
    const move = (e) => {
      const d = dragRef.current;
      if (!d || !containerRef.current) return;
      const rect = containerRef.current.getBoundingClientRect();
      if (d.type === "pan") {
        setPan({ x: d.panX + (e.clientX - d.startX), y: d.panY + (e.clientY - d.startY) });
      } else if (d.type === "node") {
        const dx = (e.clientX - d.startX) / zoomRef.current;
        const dy = (e.clientY - d.startY) / zoomRef.current;
        onMoveNodeRef.current(d.id, d.nodeX + dx, d.nodeY + dy);
      } else if (d.type === "connect") {
        const x = (e.clientX - rect.left - panRef.current.x) / zoomRef.current;
        const y = (e.clientY - rect.top - panRef.current.y) / zoomRef.current;
        setPending({ from: d.from, fromPort: d.fromPort, x, y });
      }
    };
    const up = (e) => {
      const d = dragRef.current;
      if (d && d.type === "connect" && containerRef.current) {
        const rect = containerRef.current.getBoundingClientRect();
        const x = (e.clientX - rect.left - panRef.current.x) / zoomRef.current;
        const y = (e.clientY - rect.top - panRef.current.y) / zoomRef.current;
        const target = nodeAt(x, y);
        if (target && target.id !== d.from) onConnectRef.current(d.from, d.fromPort, target.id);
        setPending(null);
      }
      dragRef.current = null;
    };
    window.addEventListener("pointermove", move);
    window.addEventListener("pointerup", up);
    return () => { window.removeEventListener("pointermove", move); window.removeEventListener("pointerup", up); };
  }, []);

  useEffect(() => {
    const el = containerRef.current;
    if (!el) return;
    const handler = (e) => {
      e.preventDefault();
      const rect = el.getBoundingClientRect();
      const cx = e.clientX - rect.left;
      const cy = e.clientY - rect.top;
      const delta = -e.deltaY * 0.0015;
      const nz = Math.min(2, Math.max(0.3, zoomRef.current * (1 + delta)));
      const k = nz / zoomRef.current;
      setPan({ x: cx - k * (cx - panRef.current.x), y: cy - k * (cy - panRef.current.y) });
      setZoom(nz);
    };
    el.addEventListener("wheel", handler, { passive: false });
    return () => el.removeEventListener("wheel", handler);
  }, []);

  const onHeaderDown = (node, e) => {
    dragRef.current = { type: "node", id: node.id, startX: e.clientX, startY: e.clientY, nodeX: node.x, nodeY: node.y };
  };
  const onPortDown = (node, portIndex, e) => {
    // Gesto de conexão — tratado separadamente do movimento do bloco.
    dragRef.current = { type: "connect", from: node.id, fromPort: portIndex };
    const rect = containerRef.current.getBoundingClientRect();
    const x = (e.clientX - rect.left - panRef.current.x) / zoomRef.current;
    const y = (e.clientY - rect.top - panRef.current.y) / zoomRef.current;
    setPending({ from: node.id, fromPort: portIndex, x, y });
  };
  const onBgDown = (e) => {
    if (e.target === e.currentTarget || e.target.dataset?.bg) {
      onSelect(null);
      dragRef.current = { type: "pan", startX: e.clientX, startY: e.clientY, panX: panRef.current.x, panY: panRef.current.y };
    }
  };

  // Drag-and-drop nativo da paleta → canvas.
  const onDragOver = (e) => { e.preventDefault(); if (e.dataTransfer) e.dataTransfer.dropEffect = "copy"; };
  const onDrop = (e) => {
    e.preventDefault();
    const type = e.dataTransfer?.getData("application/sxp-node");
    if (!type || !onAddNode || !containerRef.current) return;
    const rect = containerRef.current.getBoundingClientRect();
    const x = (e.clientX - rect.left - panRef.current.x) / zoomRef.current;
    const y = (e.clientY - rect.top - panRef.current.y) / zoomRef.current;
    // Posição de soltura relativa ao canvas (centro do bloco próximo ao cursor).
    onAddNode(type, Math.round(x - NODE_W / 2), Math.round(y - 22));
  };

  const zoomBy = (factor) => {
    const nz = Math.min(2, Math.max(0.3, zoomRef.current * factor));
    setZoom(nz);
  };

  return (
    <div className="relative flex-1 min-w-0 overflow-hidden bg-circuit bg-[#050505]">
      <div ref={containerRef} className="absolute inset-0 touch-none" onPointerDown={onBgDown} onDragOver={onDragOver} onDrop={onDrop}>
        <div style={{ position: "absolute", top: 0, left: 0, transform: `translate(${pan.x}px, ${pan.y}px) scale(${zoom})`, transformOrigin: "0 0" }}>
          <svg width="1" height="1" style={{ overflow: "visible", position: "absolute", pointerEvents: "none" }}>
            {edges.map((edge) => {
              const fromNode = nodes.find((n) => n.id === edge.from);
              const toNode = nodes.find((n) => n.id === edge.to);
              if (!fromNode || !toNode) return null;
              const p1 = outPortPos(fromNode, edge.fromPort || 0);
              const p2 = inPortPos(toNode);
              return (
                <path key={edge.id} d={bezier(p1.x, p1.y, p2.x, p2.y)} stroke="rgba(193,0,0,0.55)" strokeWidth={2} fill="none" style={{ pointerEvents: "stroke", cursor: "pointer" }} onClick={(e) => { e.stopPropagation(); onDeleteEdge(edge.id); }} />
              );
            })}
            {pending && (() => {
              const fromNode = nodes.find((n) => n.id === pending.from);
              if (!fromNode) return null;
              const p1 = outPortPos(fromNode, pending.fromPort || 0);
              return <path d={bezier(p1.x, p1.y, pending.x, pending.y)} stroke="rgba(193,0,0,0.8)" strokeWidth={2} strokeDasharray="5 4" fill="none" style={{ pointerEvents: "none" }} />;
            })()}
          </svg>
          {nodes.map((node) => (
            <FlowNode key={node.id} node={node} selected={node.id === selectedId} onSelect={onSelect} onHeaderDown={onHeaderDown} onPortDown={onPortDown} />
          ))}
        </div>
      </div>

      <div className="absolute bottom-4 right-4 flex items-center gap-1 rounded-lg surface p-1">
        <button onClick={() => zoomBy(0.85)} className="h-8 w-8 flex items-center justify-center text-muted-foreground hover:text-white"><ZoomOut className="h-4 w-4" /></button>
        <span className="text-[11px] text-muted-foreground px-1 tabular-nums">{Math.round(zoom * 100)}%</span>
        <button onClick={() => zoomBy(1.18)} className="h-8 w-8 flex items-center justify-center text-muted-foreground hover:text-white"><ZoomIn className="h-4 w-4" /></button>
        <button onClick={() => { setZoom(1); setPan({ x: 24, y: 20 }); }} className="h-8 w-8 flex items-center justify-center text-muted-foreground hover:text-white"><Maximize className="h-4 w-4" /></button>
      </div>
    </div>
  );
}