import React from "react";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Plus, Trash2, Send } from "lucide-react";
import { NODE_TYPES, NODE_CATEGORIES } from "@/lib/flowNodes";

function Field({ label, children }) {
  return (
    <div className="space-y-1.5">
      <Label className="text-[11px] uppercase tracking-[0.1em] text-muted-foreground">{label}</Label>
      {children}
    </div>
  );
}

function TelegramPreview({ node }) {
  const d = node.data || {};
  let bubble = null;
  if (node.type === "text" || node.type === "age_confirmation") bubble = d.message;
  else if (node.type === "buttons") bubble = d.message;
  if (bubble == null) return null;
  return (
    <div className="rounded-lg surface p-3">
      <div className="text-[10px] uppercase tracking-[0.12em] text-muted-foreground mb-2 flex items-center gap-1.5">
        <Send className="h-3 w-3 text-primary" /> Prévia no Telegram
      </div>
      <div className="flex justify-end">
        <div className="max-w-[80%] rounded-2xl rounded-br-sm bg-[#2a2a2a] px-3 py-2 text-[12px] text-white/90 leading-snug whitespace-pre-wrap">
          {bubble || "Sua mensagem aparecerá aqui…"}
        </div>
      </div>
      {node.type === "buttons" && (d.options || []).length > 0 && (
        <div className="mt-2 flex flex-wrap gap-1.5 justify-end">
          {(d.options || []).map((o) => (
            <span key={o.id} className="rounded-lg bg-primary/15 border border-primary/30 px-2.5 py-1 text-[11px] text-white">{o.label}</span>
          ))}
        </div>
      )}
    </div>
  );
}

function Methods({ value, onChange }) {
  const toggle = (m) => onChange(value.includes(m) ? value.filter((x) => x !== m) : [...value, m]);
  return (
    <div className="flex gap-2">
      {["pix", "card"].map((m) => (
        <button key={m} type="button" onClick={() => toggle(m)} className={`flex-1 rounded-lg border px-3 py-2 text-[12px] font-medium transition-colors ${value.includes(m) ? "border-primary bg-primary/10 text-white" : "border-white/10 text-muted-foreground hover:text-white"}`}>
          {m === "pix" ? "PIX" : "Cartão"}
        </button>
      ))}
    </div>
  );
}

export default function NodeEditorPanel({ node, onUpdate, onDelete }) {
  if (!node) {
    return (
      <div className="w-72 shrink-0 border-l border-white/5 bg-[#080808] flex items-center justify-center p-6">
        <p className="text-[12px] text-muted-foreground text-center">Selecione um nó no canvas para editar seu conteúdo.</p>
      </div>
    );
  }
  const def = NODE_TYPES[node.type];
  const cat = NODE_CATEGORIES.find((c) => c.id === def.category);
  const set = (patch) => onUpdate({ ...node.data, ...patch });

  return (
    <div className="w-72 shrink-0 border-l border-white/5 bg-[#080808] flex flex-col">
      <div className="px-4 py-3 border-b border-white/5">
        <div className="flex items-center gap-2">
          <span className="h-2.5 w-2.5 rounded-full" style={{ background: cat.color }} />
          <h3 className="text-[13px] font-semibold text-white">{def.label}</h3>
        </div>
        <p className="text-[11px] text-muted-foreground mt-0.5">Categoria: {cat.label}</p>
      </div>
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {["text", "age_confirmation", "buttons"].includes(node.type) && (
          <Field label="Mensagem"><Textarea value={node.data.message || ""} onChange={(e) => set({ message: e.target.value })} rows={4} placeholder="Digite a mensagem…" /></Field>
        )}
        {node.type === "keyword" && (
          <Field label="Palavras-chave (uma por linha)">
            <Textarea value={(node.data.words || []).join("\n") || ""} onChange={(e) => set({ words: e.target.value.split("\n") })} rows={3} />
          </Field>
        )}
        {node.type === "button_click" && <Field label="Rótulo do botão"><Input value={node.data.buttonLabel || ""} onChange={(e) => set({ buttonLabel: e.target.value })} /></Field>}
        {node.type === "audio" && (
          <>
            <Field label="URL do áudio"><Input value={node.data.url || ""} onChange={(e) => set({ url: e.target.value })} placeholder="https://…" /></Field>
            <Field label="Legenda"><Input value={node.data.caption || ""} onChange={(e) => set({ caption: e.target.value })} /></Field>
          </>
        )}
        {node.type === "media" && (
          <>
            <Field label="URL da mídia"><Input value={node.data.url || ""} onChange={(e) => set({ url: e.target.value })} placeholder="https://…" /></Field>
            <Field label="Tipo">
              <div className="flex gap-2">
                {["photo", "video"].map((t) => (
                  <button key={t} type="button" onClick={() => set({ mediaType: t })} className={`flex-1 rounded-lg border px-3 py-1.5 text-[12px] ${node.data.mediaType === t ? "border-primary bg-primary/10 text-white" : "border-white/10 text-muted-foreground"}`}>{t === "photo" ? "Foto" : "Vídeo"}</button>
                ))}
              </div>
            </Field>
            <Field label="Legenda"><Input value={node.data.caption || ""} onChange={(e) => set({ caption: e.target.value })} /></Field>
          </>
        )}
        {node.type === "file" && (
          <>
            <Field label="URL do arquivo"><Input value={node.data.url || ""} onChange={(e) => set({ url: e.target.value })} /></Field>
            <Field label="Nome do arquivo"><Input value={node.data.filename || ""} onChange={(e) => set({ filename: e.target.value })} /></Field>
          </>
        )}
        {node.type === "buttons" && (
          <Field label="Botões de resposta">
            <div className="space-y-2">
              {(node.data.options || []).map((opt, i) => (
                <div key={opt.id} className="flex gap-2">
                  <Input value={opt.label} onChange={(e) => { const options = [...node.data.options]; options[i] = { ...opt, label: e.target.value }; set({ options }); }} placeholder={`Opção ${i + 1}`} />
                  <button type="button" onClick={() => set({ options: node.data.options.filter((_, idx) => idx !== i) })} className="text-muted-foreground hover:text-danger p-2"><Trash2 className="h-4 w-4" /></button>
                </div>
              ))}
              <Button type="button" variant="outline" size="sm" onClick={() => set({ options: [...(node.data.options || []), { id: `o${Date.now()}`, label: "Nova opção" }] })} className="w-full"><Plus className="h-3.5 w-3.5" /> Adicionar botão</Button>
            </div>
          </Field>
        )}
        {node.type === "delay" && <Field label="Segundos"><Input type="number" value={node.data.seconds || 0} onChange={(e) => set({ seconds: Number(e.target.value) })} /></Field>}
        {node.type === "condition" && (
          <>
            <Field label="Variável"><Input value={node.data.variable || ""} onChange={(e) => set({ variable: e.target.value })} placeholder="ex: clicou_oferta" /></Field>
            <Field label="Operador">
              <select value={node.data.operator || "eq"} onChange={(e) => set({ operator: e.target.value })} className="w-full h-9 rounded-md border border-input bg-transparent px-3 text-sm">
                <option value="eq">Igual a</option><option value="neq">Diferente de</option><option value="contains">Contém</option>
              </select>
            </Field>
            <Field label="Valor"><Input value={node.data.value || ""} onChange={(e) => set({ value: e.target.value })} /></Field>
          </>
        )}
        {node.type === "tag" && <Field label="Etiqueta"><Input value={node.data.tag || ""} onChange={(e) => set({ tag: e.target.value })} placeholder="ex: cliente_vip" /></Field>}
        {node.type === "offer" && (
          <>
            <Field label="Nome da oferta"><Input value={node.data.name || ""} onChange={(e) => set({ name: e.target.value })} /></Field>
            <Field label="Preço (R$)"><Input type="number" value={node.data.price || 0} onChange={(e) => set({ price: Number(e.target.value) })} /></Field>
            <Field label="Métodos aceitos"><Methods value={node.data.methods || []} onChange={(m) => set({ methods: m })} /></Field>
          </>
        )}
        {(node.type === "order_bump" || node.type === "upsell" || node.type === "downsell") && (
          <>
            <Field label="Nome"><Input value={node.data.name || ""} onChange={(e) => set({ name: e.target.value })} /></Field>
            <Field label="Preço (R$)"><Input type="number" value={node.data.price || 0} onChange={(e) => set({ price: Number(e.target.value) })} /></Field>
            {node.type === "upsell" && <Field label="Desconto (%)"><Input type="number" value={node.data.discount || 0} onChange={(e) => set({ discount: Number(e.target.value) })} /></Field>}
          </>
        )}
        {node.type === "coupon" && (
          <>
            <Field label="Código"><Input value={node.data.code || ""} onChange={(e) => set({ code: e.target.value })} /></Field>
            <Field label="Desconto (%)"><Input type="number" value={node.data.discount || 0} onChange={(e) => set({ discount: Number(e.target.value) })} /></Field>
          </>
        )}
        {node.type === "webhook" && (
          <>
            <Field label="URL"><Input value={node.data.url || ""} onChange={(e) => set({ url: e.target.value })} placeholder="https://…" /></Field>
            <Field label="Método">
              <select value={node.data.method || "POST"} onChange={(e) => set({ method: e.target.value })} className="w-full h-9 rounded-md border border-input bg-transparent px-3 text-sm">
                <option value="POST">POST</option><option value="GET">GET</option><option value="PUT">PUT</option>
              </select>
            </Field>
          </>
        )}
        {["start", "payment_approved", "payment_refused"].includes(node.type) && (
          <p className="text-[12px] text-muted-foreground leading-relaxed">Nó de gatilho automático. Não requer configuração adicional.</p>
        )}
        <TelegramPreview node={node} />
      </div>
      <div className="p-3 border-t border-white/5">
        <Button variant="outline" size="sm" onClick={onDelete} className="w-full text-muted-foreground hover:text-danger"><Trash2 className="h-3.5 w-3.5" /> Excluir nó</Button>
      </div>
    </div>
  );
}