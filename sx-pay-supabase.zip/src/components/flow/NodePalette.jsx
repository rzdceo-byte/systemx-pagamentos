import React from "react";
import { cn } from "@/lib/utils";
import { NODE_CATEGORIES, NODE_TYPES } from "@/lib/flowNodes";
import {
  Zap, Type, MousePointerClick, BadgeCheck, XCircle, MessageSquare,
  AudioLines, Image as ImageIcon, FileText, ListChecks, Clock, GitBranch,
  Tag, ShoppingBag, PlusCircle, TrendingUp, TrendingDown, Ticket, Webhook
} from "lucide-react";

const ICONS = { Zap, Type, MousePointerClick, BadgeCheck, XCircle, MessageSquare, AudioLines, ImageIcon, FileText, ListChecks, Clock, GitBranch, Tag, ShoppingBag, PlusCircle, TrendingUp, TrendingDown, Ticket, Webhook };

export default function NodePalette({ onAdd }) {
  return (
    <div className="w-60 shrink-0 border-r border-white/5 bg-[#080808] overflow-y-auto">
      <div className="px-4 py-3 border-b border-white/5">
        <h3 className="text-[10px] uppercase tracking-[0.18em] font-semibold text-muted-foreground">Blocos</h3>
        <p className="text-[11px] text-muted-foreground/70 mt-0.5">Arraste para o canvas ou clique</p>
      </div>
      <div className="p-2 space-y-3">
        {NODE_CATEGORIES.map((cat) => {
          const types = Object.values(NODE_TYPES).filter((t) => t.category === cat.id);
          return (
            <div key={cat.id}>
              <div className="flex items-center gap-2 px-2 py-1.5">
                <span className="h-2 w-2 rounded-full" style={{ background: cat.color }} />
                <span className="text-[10px] uppercase tracking-[0.14em] font-semibold text-muted-foreground">{cat.label}</span>
              </div>
              <div className="space-y-1">
                {types.map((t) => {
                  const Icon = ICONS[t.icon] || Zap;
                  return (
                    <button
                      key={t.type}
                      draggable
                      onDragStart={(e) => { e.dataTransfer.setData("application/sxp-node", t.type); e.dataTransfer.effectAllowed = "copy"; }}
                      onClick={() => onAdd(t.type)}
                      className={cn(
                        "w-full flex items-center gap-2.5 rounded-lg px-2.5 py-2 text-[12px] font-medium text-muted-foreground",
                        "hover:text-white hover:bg-white/[0.04] transition-colors group cursor-grab active:cursor-grabbing"
                      )}
                    >
                      <span className="flex items-center justify-center h-6 w-6 rounded-md border border-white/10 group-hover:border-white/20" style={{ background: `${cat.color}14` }}>
                        <Icon className="h-3.5 w-3.5" style={{ color: cat.color }} />
                      </span>
                      <span className="truncate">{t.label}</span>
                    </button>
                  );
                })}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}