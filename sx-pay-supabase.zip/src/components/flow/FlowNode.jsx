import React from "react";
import { cn } from "@/lib/utils";
import { NODE_TYPES, NODE_CATEGORIES, getOutputCount } from "@/lib/flowNodes";
import {
  Zap, Type, MousePointerClick, BadgeCheck, XCircle, MessageSquare,
  AudioLines, Image as ImageIcon, FileText, ListChecks, Clock, GitBranch,
  Tag, ShoppingBag, PlusCircle, TrendingUp, TrendingDown, Ticket, Webhook
} from "lucide-react";

const ICONS = { Zap, Type, MousePointerClick, BadgeCheck, XCircle, MessageSquare, AudioLines, ImageIcon, FileText, ListChecks, Clock, GitBranch, Tag, ShoppingBag, PlusCircle, TrendingUp, TrendingDown, Ticket, Webhook };

export const NODE_W = 208;
export const PORT_IN_Y = 22;
export const PORT_GAP = 26;

export function outPortPos(node, i) {
  return { x: node.x + NODE_W, y: node.y + PORT_IN_Y + i * PORT_GAP };
}
export function inPortPos(node) {
  return { x: node.x, y: node.y + PORT_IN_Y };
}

function preview(node) {
  const d = node.data || {};
  switch (node.type) {
    case "text": return d.message || "Mensagem de texto…";
    case "age_confirmation": return d.message || "Confirmação de maioridade (18+)";
    case "buttons": return d.message || "Botões de resposta";
    case "offer": return `${d.name || "Oferta"} — R$ ${Number(d.price || 0).toFixed(2)}`;
    case "order_bump": return `${d.name || "Order bump"} +R$ ${Number(d.price || 0).toFixed(2)}`;
    case "upsell": return `${d.name || "Upsell"} — R$ ${Number(d.price || 0).toFixed(2)}`;
    case "downsell": return `${d.name || "Downsell"} — R$ ${Number(d.price || 0).toFixed(2)}`;
    case "coupon": return `Cupom ${d.code || "…"} (${d.discount || 0}%)`;
    case "delay": return `Aguardar ${d.seconds || 0}s`;
    case "condition": return `${d.variable || "var"} ${d.operator || "=="} ${d.value || "…"}`;
    case "tag": return `Etiqueta: ${d.tag || "…"}`;
    case "webhook": return `${d.method || "POST"} → ${d.url || "https://…"}`;
    case "keyword": return `Palavras: ${(d.words || []).join(", ") || "…"}`;
    case "button_click": return `Botão: ${d.buttonLabel || "…"}`;
    case "audio": return `Áudio${d.caption ? " — " + d.caption : ""}`;
    case "media": return `Mídia (${d.mediaType || "foto"})${d.caption ? " — " + d.caption : ""}`;
    case "file": return `Arquivo: ${d.filename || "…"}`;
    default: return null;
  }
}

export default function FlowNode({ node, selected, onSelect, onHeaderDown, onPortDown }) {
  const def = NODE_TYPES[node.type];
  if (!def) return null;
  const cat = NODE_CATEGORIES.find((c) => c.id === def.category);
  const Icon = ICONS[def.icon] || Zap;
  const outputs = def.outputs === "dynamic" ? Math.max(1, (node.data.options || []).length) : def.outputs;
  const body = preview(node);
  const outLabels = def.outputLabels || (def.outputs === "dynamic" ? (node.data.options || []).map((o) => o.label) : null);

  return (
    <div
      className="absolute select-none"
      style={{ left: node.x, top: node.y, width: NODE_W }}
      onPointerDown={(e) => { e.stopPropagation(); onSelect(node.id); }}
    >
      <div
        className={cn(
          "rounded-xl overflow-hidden border bg-[#0D0D0D] shadow-lg transition-shadow",
          selected ? "border-primary glow-red-sm" : "border-white/10"
        )}
        style={{ boxShadow: selected ? undefined : "0 8px 24px -16px rgba(0,0,0,0.9)" }}
      >
        <div
          onPointerDown={(e) => { e.stopPropagation(); onSelect(node.id); onHeaderDown(node, e); }}
          className="flex items-center gap-2 px-3 h-11 cursor-grab active:cursor-grabbing"
          style={{ background: `linear-gradient(90deg, ${cat.color}22, transparent)`, borderBottom: `1px solid ${cat.color}33` }}
        >
          <span className="flex items-center justify-center h-6 w-6 rounded-md" style={{ background: `${cat.color}1a` }}>
            <Icon className="h-3.5 w-3.5" style={{ color: cat.color }} />
          </span>
          <span className="text-[12px] font-semibold text-white truncate">{def.label}</span>
        </div>
        <div className="px-3 py-2.5 min-h-[34px]">
          {body ? <p className="text-[11px] text-muted-foreground leading-snug line-clamp-3">{body}</p> : <p className="text-[11px] text-muted-foreground italic">Nó de gatilho</p>}
        </div>
      </div>

      {def.inputs > 0 && (
        <span
          className="absolute -left-2 top-[14px] h-3.5 w-3.5 rounded-full border-2 border-[#0D0D0D] bg-muted-foreground/70 hover:bg-primary"
          style={{ transform: "translateY(7px)" }}
        />
      )}

      {Array.from({ length: outputs }).map((_, i) => (
        <div key={i} className="absolute -right-2 flex items-center gap-1" style={{ top: PORT_IN_Y + i * PORT_GAP, transform: "translateY(-50%)" }}>
          {outLabels && outLabels[i] && (
            <span className="text-[9px] text-muted-foreground bg-[#0D0D0D] px-1 rounded whitespace-nowrap border border-white/10">{outLabels[i]}</span>
          )}
          <span
            onPointerDown={(e) => { e.stopPropagation(); onSelect(node.id); onPortDown(node, i, e); }}
            className="h-3.5 w-3.5 rounded-full border-2 border-[#0D0D0D] bg-primary hover:scale-125 cursor-crosshair transition-transform"
          />
        </div>
      ))}
    </div>
  );
}