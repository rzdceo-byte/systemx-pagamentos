import React, { useState, useEffect } from "react";
import { Info, Image as ImageIcon, DollarSign, Briefcase, Link2, Plus, Trash2, Star, Download, MessageSquare, Check } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { useApp } from "@/lib/AppContext";
import { useToast } from "@/components/ui/use-toast";
import { formatCurrency } from "@/lib/mockData";
import { useNavigate } from "react-router-dom";
import { TabBar, SectionCard, Field, ChipSelect, AddButton, Toggle } from "@/components/shared/EditorControls";
import MediaUploader from "@/components/products/MediaUploader";
import GalleryUploader from "@/components/products/GalleryUploader";

const PRODUCT_DEFAULTS = {
  shortDescription: "", longDescription: "", category: "Infoproduto",
  deliveryType: "Acesso digital imediato", gallery: [], videoUrl: "",
  promoPrice: null, maxInstallments: 12, plans: [],
  warrantyDays: 7, warrantyText: "Garantia incondicional de 7 dias. Se não gostar, devolvemos 100% do seu dinheiro.",
  affiliateEnabled: false, affiliatePercent: 30,
  stockType: "ilimitado", stockQty: 0, tags: [], status: "ativo",
  delivery: { message: "", links: [] }
};

export default function ProductEditor({ open, onOpenChange, product, onSave }) {
  const { checkouts, addCheckout } = useApp();
  const { toast } = useToast();
  const navigate = useNavigate();
  const [tab, setTab] = useState("info");
  const [form, setForm] = useState({ ...PRODUCT_DEFAULTS });

  useEffect(() => {
    if (product) setForm({ ...PRODUCT_DEFAULTS, ...product });
    else setForm({ ...PRODUCT_DEFAULTS, image: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=400" });
    setTab("info");
  }, [product, open]);

  const set = (k, v) => setForm((f) => ({ ...f, [k]: v }));
  const productCheckouts = checkouts.filter((c) => c.productId === (form.id || product?.id));

  const submit = () => {
    if (!form.name?.trim()) { toast({ title: "Informe o nome do produto", variant: "destructive" }); setTab("info"); return; }
    if (!form.price || form.price <= 0) { toast({ title: "Preço inválido", variant: "destructive" }); setTab("price"); return; }
    onSave({
      ...form,
      name: form.name.trim(),
      price: parseFloat(form.price) || 0,
      promoPrice: form.promoPrice ? parseFloat(form.promoPrice) : null,
      maxInstallments: parseInt(form.maxInstallments) || 12
    });
  };

  const createCheckoutForProduct = () => {
    const created = addCheckout({
      name: `Checkout ${form.name}`,
      productId: form.id, productName: form.name, productImage: form.image,
      price: form.promoPrice || form.price, accentColor: "#C10000",
      headline: form.name, description: form.shortDescription || "Acesso imediato após a confirmação do pagamento.",
      hasOrderBump: false, hasUpsell: false, methods: ["pix", "card", "boleto"], published: false
    });
    toast({ title: "Checkout criado", description: "Redirecionando para o editor..." });
    navigate("/checkout");
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="bg-popover border-white/10 max-w-3xl p-0 overflow-hidden">
        <DialogHeader className="px-6 pt-6 pb-3">
          <DialogTitle className="text-white">{product ? "Editar produto" : "Novo produto"}</DialogTitle>
        </DialogHeader>
        <div className="px-6">
          <TabBar tabs={[
            { id: "info", label: "Informações", icon: Info },
            { id: "media", label: "Mídia", icon: ImageIcon },
            { id: "price", label: "Preço", icon: DollarSign },
            { id: "commercial", label: "Comercial", icon: Briefcase },
            { id: "entrega", label: "Entrega", icon: Download },
            { id: "checkouts", label: "Checkouts", icon: Link2 }
          ]} active={tab} onChange={setTab} />
        </div>
        <div className="overflow-y-auto max-h-[58vh] px-6 py-5 space-y-4">
          {tab === "info" && <InfoTab form={form} set={set} />}
          {tab === "media" && <MediaTab form={form} set={set} />}
          {tab === "price" && <PriceTab form={form} set={set} />}
          {tab === "commercial" && <CommercialTab form={form} set={set} />}
          {tab === "entrega" && <DeliveryTab form={form} set={set} />}
          {tab === "checkouts" && <CheckoutsTab form={form} checkouts={productCheckouts} onCreate={createCheckoutForProduct} />}
        </div>
        <DialogFooter className="px-6 py-4 border-t border-white/5">
          <Button variant="ghost" onClick={() => onOpenChange(false)}>Cancelar</Button>
          <Button onClick={submit} className="bg-primary hover:bg-[#E10600]">{product ? "Salvar alterações" : "Criar produto"}</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function InfoTab({ form, set }) {
  return (
    <>
      <Field label="Nome do produto" value={form.name} onChange={(v) => set("name", v)} placeholder="Ex: Método Tráfego Direto 3.0" />
      <Field label="Descrição curta (listagens)" value={form.shortDescription} onChange={(v) => set("shortDescription", v)} placeholder="Uma frase que resume a oferta" />
      <Field label="Descrição longa (página de checkout)" value={form.longDescription} onChange={(v) => set("longDescription", v)} rows={4} placeholder="Texto exibido na página do checkout" />
      <div className="grid grid-cols-2 gap-3">
        <div className="space-y-1">
          <span className="text-[11px] text-muted-foreground font-medium">Categoria</span>
          <select value={form.category} onChange={(e) => set("category", e.target.value)} className="w-full rounded-md bg-background border border-white/10 px-2.5 py-1.5 text-xs text-white focus:outline-none focus:border-primary/50">
            {["Infoproduto", "Curso", "Mentoria", "Assinatura", "Serviço", "Físico"].map((c) => <option key={c} value={c}>{c}</option>)}
          </select>
        </div>
        <div className="space-y-1">
          <span className="text-[11px] text-muted-foreground font-medium">Tipo de entrega</span>
          <select value={form.deliveryType} onChange={(e) => set("deliveryType", e.target.value)} className="w-full rounded-md bg-background border border-white/10 px-2.5 py-1.5 text-xs text-white focus:outline-none focus:border-primary/50">
            {["Acesso digital imediato", "Liberação em data programada", "Envio físico", "Comunidade/Área de membros"].map((c) => <option key={c} value={c}>{c}</option>)}
          </select>
        </div>
      </div>
      <SectionCard title="Status do produto">
        <ChipSelect options={[{ v: "ativo", l: "Ativo" }, { v: "rascunho", l: "Rascunho" }, { v: "pausado", l: "Pausado" }]} value={form.status} onChange={(v) => set("status", v)} />
      </SectionCard>
    </>
  );
}

function MediaTab({ form, set }) {
  return (
    <>
      <MediaUploader value={form.image || ""} onChange={(v) => set("image", v)} />
      <SectionCard title="Galeria de imagens" icon={ImageIcon}>
        <GalleryUploader items={form.gallery || []} onChange={(v) => set("gallery", v)} />
      </SectionCard>
      <Field label="Vídeo de apresentação (URL)" value={form.videoUrl} onChange={(v) => set("videoUrl", v)} placeholder="https://youtube.com/..." />
    </>
  );
}

const DELIVERY_TYPES = ["Área de membros", "Download direto", "Grupo/Comunidade", "Redirecionamento externo"];

function DeliveryTab({ form, set }) {
  const delivery = form.delivery || { message: "", links: [] };
  const setDelivery = (patch) => set("delivery", { ...delivery, ...patch });
  const links = delivery.links || [];
  const addLink = () => setDelivery({ links: [...links, { id: `lnk-${Date.now()}`, label: "", url: "", type: "Área de membros" }] });
  const updateLink = (i, patch) => setDelivery({ links: links.map((l, idx) => (idx === i ? { ...l, ...patch } : l)) });
  const removeLink = (i) => setDelivery({ links: links.filter((_, idx) => idx !== i) });

  return (
    <>
      <div className="rounded-md bg-primary/[0.06] border border-primary/20 px-3 py-2 text-[11px] text-muted-foreground flex items-start gap-2">
        <Info className="h-3.5 w-3.5 text-primary shrink-0 mt-0.5" />
        <span>Configure como o cliente recebe o produto após o pagamento aprovado. A SXPay entrega apenas <span className="text-white font-medium">produtos digitais</span> — a estrutura já prevê futuros tipos de entrega.</span>
      </div>
      <SectionCard title="Mensagem de entrega" icon={MessageSquare}>
        <Field label="Mensagem exibida/enviada ao cliente junto com os links" value={delivery.message} onChange={(v) => setDelivery({ message: v })} rows={3} placeholder="Parabéns pela compra! Acesse seu curso pelo link abaixo:" />
      </SectionCard>
      <SectionCard title="Links de entrega" icon={Link2} action={<AddButton onClick={addLink} label="Adicionar link" />}>
        {links.length === 0 ? (
          <p className="text-[11px] text-muted-foreground">Nenhum link configurado. Adicione o link que o cliente vai receber após a compra (área de membros, download, grupo etc.).</p>
        ) : (
          <div className="space-y-2">
            {links.map((l, i) => (
              <div key={l.id} className="rounded-md bg-background border border-white/10 p-2.5 space-y-2">
                <div className="grid grid-cols-[1fr_150px_auto] gap-2">
                  <Field label="Rótulo" value={l.label} onChange={(v) => updateLink(i, { label: v })} placeholder="Ex: Módulo 1 - PDF" />
                  <div className="space-y-1">
                    <span className="text-[11px] text-muted-foreground font-medium">Tipo</span>
                    <select value={l.type} onChange={(e) => updateLink(i, { type: e.target.value })} className="w-full rounded-md bg-background border border-white/10 px-2.5 py-1.5 text-xs text-white focus:outline-none focus:border-primary/50">
                      {DELIVERY_TYPES.map((t) => <option key={t} value={t}>{t}</option>)}
                    </select>
                  </div>
                  <button type="button" onClick={() => removeLink(i)} className="self-end h-8 w-8 rounded-md bg-white/5 hover:bg-[#E10600]/15 text-muted-foreground hover:text-[#FF6A4D] flex items-center justify-center"><Trash2 className="h-3.5 w-3.5" /></button>
                </div>
                <Field label="URL de acesso" value={l.url} onChange={(v) => updateLink(i, { url: v })} placeholder="https://..." mono />
              </div>
            ))}
          </div>
        )}
      </SectionCard>
      {(delivery.message || links.length > 0) && (
        <SectionCard title="Resumo da entrega" icon={Check}>
          <div className="space-y-1.5 text-[11px]">
            {delivery.message && <p className="text-muted-foreground leading-relaxed">"{delivery.message}"</p>}
            {links.map((l) => (
              <div key={l.id} className="flex items-center gap-2">
                <span className="text-[9px] px-1.5 py-0.5 rounded bg-white/5 text-muted-foreground shrink-0">{l.type}</span>
                <span className="text-white font-medium">{l.label || "Link"}</span>
                {l.url && <span className="text-muted-foreground truncate font-mono text-[10px]">{l.url}</span>}
              </div>
            ))}
          </div>
        </SectionCard>
      )}
    </>
  );
}

function PriceTab({ form, set }) {
  const discountPct = form.promoPrice && form.price > 0 ? Math.round((1 - form.promoPrice / form.price) * 100) : 0;
  const addPlan = () => set("plans", [...(form.plans || []), { name: "Novo plano", price: 0, description: "" }]);
  return (
    <>
      <div className="grid grid-cols-2 gap-3">
        <Field label="Preço padrão (R$)" type="number" value={form.price} onChange={(v) => set("price", v)} placeholder="297" />
        <Field label="Preço promocional (R$)" type="number" value={form.promoPrice} onChange={(v) => set("promoPrice", v)} placeholder="197" />
      </div>
      {discountPct > 0 && (
        <div className="rounded-md bg-success/10 border border-success/20 px-3 py-2 text-[11px] text-success">
          Exibição "de/por": <span className="line-through text-muted-foreground">{formatCurrency(form.price)}</span> por <span className="font-bold">{formatCurrency(form.promoPrice)}</span> · {discountPct}% OFF
        </div>
      )}
      <Field label="Parcelamento máximo (x)" type="number" value={form.maxInstallments} onChange={(v) => set("maxInstallments", v)} />
      <SectionCard title="Planos / Variações" icon={Plus} action={<AddButton onClick={addPlan} label="Adicionar plano" />}>
        {(form.plans || []).length === 0 ? (
          <p className="text-[11px] text-muted-foreground">Crie variações como Básico, Pro, Vitalício — cada uma com nome, preço e descrição.</p>
        ) : (
          <div className="space-y-2">
            {(form.plans || []).map((p, i) => (
              <div key={i} className="rounded-md bg-background border border-white/10 p-2.5 space-y-2">
                <div className="grid grid-cols-[1fr_90px_auto] gap-2">
                  <Field label="Nome" value={p.name} onChange={(v) => set("plans", form.plans.map((x, idx) => idx === i ? { ...x, name: v } : x))} />
                  <Field label="Preço" type="number" value={p.price} onChange={(v) => set("plans", form.plans.map((x, idx) => idx === i ? { ...x, price: v } : x))} />
                  <button onClick={() => set("plans", form.plans.filter((_, idx) => idx !== i))} className="self-end h-8 w-8 rounded-md bg-white/5 hover:bg-[#E10600]/15 text-muted-foreground hover:text-[#FF6A4D] flex items-center justify-center"><Trash2 className="h-3.5 w-3.5" /></button>
                </div>
                <Field label="Descrição" value={p.description} onChange={(v) => set("plans", form.plans.map((x, idx) => idx === i ? { ...x, description: v } : x))} />
              </div>
            ))}
          </div>
        )}
      </SectionCard>
    </>
  );
}

function CommercialTab({ form, set }) {
  return (
    <>
      <SectionCard title="Garantia" icon={Briefcase}>
        <div className="grid grid-cols-[100px_1fr] gap-2">
          <Field label="Dias" type="number" value={form.warrantyDays} onChange={(v) => set("warrantyDays", v)} />
          <Field label="Texto da garantia" value={form.warrantyText} onChange={(v) => set("warrantyText", v)} />
        </div>
      </SectionCard>
      <Toggle checked={form.affiliateEnabled} onChange={(v) => set("affiliateEnabled", v)} label="Programa de afiliados" description="Permitir que afiliados promovam este produto" />
      {form.affiliateEnabled && (
        <Field label="Comissão do afiliado (%)" type="number" value={form.affiliatePercent} onChange={(v) => set("affiliatePercent", v)} />
      )}
      <SectionCard title="Estoque">
        <div className="grid grid-cols-2 gap-3">
          <div className="space-y-1">
            <span className="text-[11px] text-muted-foreground font-medium">Tipo</span>
            <ChipSelect options={[{ v: "ilimitado", l: "Ilimitado" }, { v: "limitado", l: "Limitado" }]} value={form.stockType} onChange={(v) => set("stockType", v)} />
          </div>
          {form.stockType === "limitado" && <Field label="Quantidade" type="number" value={form.stockQty} onChange={(v) => set("stockQty", v)} />}
        </div>
        {form.stockType === "limitado" && form.stockQty <= 10 && <p className="text-[11px] text-warning">Alerta de "últimas unidades" será exibido no checkout.</p>}
      </SectionCard>
      <SectionCard title="Tags internas" icon={Star}>
        <ChipSelect multi options={[{ v: "lancamento", l: "Lançamento" }, { v: "evergreen", l: "Evergreen" }, { v: "alto-ticket", l: "Alto ticket" }, { v: "best-seller", l: "Best seller" }]} value={form.tags} onChange={(v) => set("tags", v)} />
      </SectionCard>
    </>
  );
}

function CheckoutsTab({ form, checkouts, onCreate }) {
  return (
    <>
      <Button onClick={onCreate} className="w-full bg-primary hover:bg-[#E10600] gap-2"><Plus className="h-4 w-4" /> Criar checkout para este produto</Button>
      <div className="space-y-2">
        <span className="text-[11px] text-muted-foreground font-medium">Checkouts vinculados ({checkouts.length})</span>
        {checkouts.length === 0 ? (
          <p className="text-[11px] text-muted-foreground rounded-md bg-background border border-white/10 p-3">Este produto ainda não possui checkouts. Crie um para começar a vender — ideal para testes A/B.</p>
        ) : (
          checkouts.map((c) => (
            <div key={c.id} className="flex items-center justify-between rounded-md bg-background border border-white/10 px-3 py-2">
              <div className="flex items-center gap-2 min-w-0">
                <div className="h-2 w-2 rounded-full shrink-0" style={{ background: c.accentColor }} />
                <span className="text-xs text-white truncate">{c.name}</span>
              </div>
              <span className={`text-[10px] ${c.published ? "text-success" : "text-muted-foreground"}`}>{c.published ? "Publicado" : "Rascunho"}</span>
            </div>
          ))
        )}
      </div>
    </>
  );
}