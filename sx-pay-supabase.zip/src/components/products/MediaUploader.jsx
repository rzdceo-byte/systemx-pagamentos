import React, { useRef, useState } from "react";
import { Image as ImageIcon, Loader2, X } from "lucide-react";
import { Image } from "@/components/ui/image";
import { base44 } from "@/api/base44Client";
import { useToast } from "@/components/ui/use-toast";
import { cn } from "@/lib/utils";

const ACCEPTED = ["image/jpeg", "image/png", "image/webp"];
const MAX_SIZE = 5 * 1024 * 1024; // 5MB

// Upload de imagem única com preview imediato, validação (JPG/PNG/WEBP, 5MB) e placeholder.
export default function MediaUploader({ value, onChange, label = "Imagem principal", className }) {
  const inputRef = useRef(null);
  const [uploading, setUploading] = useState(false);
  const { toast } = useToast();

  const handleFile = async (file) => {
    if (!file) return;
    if (!ACCEPTED.includes(file.type)) { toast({ title: "Formato inválido", description: "Envie JPG, PNG ou WEBP.", variant: "destructive" }); return; }
    if (file.size > MAX_SIZE) { toast({ title: "Arquivo muito grande", description: "O tamanho máximo é 5MB.", variant: "destructive" }); return; }
    setUploading(true);
    try {
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      onChange(file_url);
      toast({ title: "Imagem enviada" });
    } catch (e) {
      toast({ title: "Falha no upload", description: String(e?.message || e), variant: "destructive" });
    } finally {
      setUploading(false);
      if (inputRef.current) inputRef.current.value = "";
    }
  };

  return (
    <div className="space-y-1.5">
      <span className="text-[11px] text-muted-foreground font-medium">{label}</span>
      <div className={cn("relative rounded-lg border border-dashed border-white/15 overflow-hidden bg-black/30 h-40", className)}>
        {value ? (
          <>
            <Image src={value} alt="" fittingType="fill" className="block w-full h-full" />
            <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent opacity-0 hover:opacity-100 transition-opacity flex items-end justify-end gap-2 p-2">
              <button type="button" onClick={() => inputRef.current?.click()} className="rounded-md bg-black/70 border border-white/20 px-2.5 py-1 text-[11px] text-white">Trocar</button>
              <button type="button" onClick={() => onChange("")} className="rounded-md bg-primary/90 px-2.5 py-1 text-[11px] text-white flex items-center gap-1"><X className="h-3 w-3" /> Remover</button>
            </div>
          </>
        ) : (
          <button type="button" onClick={() => inputRef.current?.click()} className="absolute inset-0 flex flex-col items-center justify-center gap-1.5 text-muted-foreground hover:text-white transition-colors">
            {uploading ? <Loader2 className="h-6 w-6 animate-spin" /> : <ImageIcon className="h-7 w-7 opacity-50" />}
            <span className="text-[11px]">{uploading ? "Enviando..." : "Clique para enviar"}</span>
            <span className="text-[9px] opacity-60">JPG, PNG ou WEBP · até 5MB</span>
          </button>
        )}
        {uploading && value && <div className="absolute inset-0 bg-black/60 flex items-center justify-center"><Loader2 className="h-6 w-6 animate-spin text-white" /></div>}
      </div>
      <input ref={inputRef} type="file" accept={ACCEPTED.join(",")} onChange={(e) => handleFile(e.target.files?.[0])} className="hidden" />
    </div>
  );
}