import React, { useRef, useState } from "react";
import { Loader2, X, GripVertical, Plus } from "lucide-react";
import { Image } from "@/components/ui/image";
import { base44 } from "@/api/base44Client";
import { useToast } from "@/components/ui/use-toast";
import { DragDropContext, Droppable, Draggable } from "@hello-pangea/dnd";

const ACCEPTED = ["image/jpeg", "image/png", "image/webp"];
const MAX_SIZE = 5 * 1024 * 1024; // 5MB

// Galeria de imagens com upload múltiplo, miniaturas arrastáveis (reordenar) e remoção individual.
export default function GalleryUploader({ items = [], onChange }) {
  const inputRef = useRef(null);
  const [uploading, setUploading] = useState(false);
  const { toast } = useToast();

  const addFiles = async (files) => {
    const valid = [];
    for (const f of Array.from(files || [])) {
      if (!ACCEPTED.includes(f.type)) { toast({ title: `${f.name}: formato inválido`, description: "Envie JPG, PNG ou WEBP.", variant: "destructive" }); continue; }
      if (f.size > MAX_SIZE) { toast({ title: `${f.name}: muito grande`, description: "Máximo de 5MB por arquivo.", variant: "destructive" }); continue; }
      valid.push(f);
    }
    if (!valid.length) return;
    setUploading(true);
    try {
      const urls = [];
      for (const f of valid) {
        const { file_url } = await base44.integrations.Core.UploadFile({ file: f });
        urls.push(file_url);
      }
      onChange([...items, ...urls]);
      toast({ title: `${urls.length} imagem(ns) adicionada(s)` });
    } catch (e) {
      toast({ title: "Falha no upload", description: String(e?.message || e), variant: "destructive" });
    } finally {
      setUploading(false);
      if (inputRef.current) inputRef.current.value = "";
    }
  };

  const onDragEnd = (res) => {
    if (!res.destination) return;
    const next = [...items];
    const [moved] = next.splice(res.source.index, 1);
    next.splice(res.destination.index, 0, moved);
    onChange(next);
  };

  return (
    <div className="space-y-2">
      <DragDropContext onDragEnd={onDragEnd}>
        <Droppable droppableId="gallery" direction="horizontal">
          {(provided) => (
            <div ref={provided.innerRef} {...provided.droppableProps} className="flex flex-wrap gap-2 min-h-[68px]">
              {items.map((url, i) => (
                <Draggable key={url + i} draggableId={`g-${i}`} index={i}>
                  {(p) => (
                    <div ref={p.innerRef} {...p.draggableProps} {...p.dragHandleProps} className="relative group rounded-md overflow-hidden border border-white/10 bg-black/30 h-16 w-[72px] shrink-0">
                      <Image src={url} alt="" fittingType="fill" className="block w-full h-full" />
                      <span className="absolute top-1 left-1 rounded bg-black/60 p-0.5 opacity-0 group-hover:opacity-100"><GripVertical className="h-3 w-3 text-white" /></span>
                      <button type="button" onClick={() => onChange(items.filter((_, idx) => idx !== i))} className="absolute -top-1.5 -right-1.5 h-5 w-5 rounded-full bg-primary text-white flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity"><X className="h-3 w-3" /></button>
                    </div>
                  )}
                </Draggable>
              ))}
              {provided.placeholder}
            </div>
          )}
        </Droppable>
      </DragDropContext>
      {items.length === 0 && <p className="text-[11px] text-muted-foreground">Nenhuma imagem na galeria.</p>}
      <button type="button" onClick={() => inputRef.current?.click()} className="w-full rounded-md border border-dashed border-white/15 py-2 text-[11px] text-muted-foreground hover:text-white hover:border-primary/40 transition-colors flex items-center justify-center gap-1.5">
        {uploading ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <><Plus className="h-3.5 w-3.5" /> Adicionar imagem</>}
      </button>
      <input ref={inputRef} type="file" accept={ACCEPTED.join(",")} multiple onChange={(e) => addFiles(e.target.files)} className="hidden" />
      <p className="text-[10px] text-muted-foreground">Arraste para reordenar · JPG, PNG ou WEBP · até 5MB cada</p>
    </div>
  );
}