import React from "react";
import { cn } from "@/lib/utils";

// Toggle switch com label e descrição opcional
export function Toggle({ checked, onChange, label, icon: Icon, description }) {
  return (
    <label className="flex items-center justify-between gap-3 cursor-pointer rounded-lg surface p-3">
      <span className="flex items-start gap-2.5 min-w-0">
        {Icon && <Icon className="h-4 w-4 text-primary shrink-0 mt-0.5" />}
        <span className="min-w-0">
          <span className="block text-sm text-white font-medium leading-tight">{label}</span>
          {description && <span className="block text-[11px] text-muted-foreground mt-0.5 leading-tight">{description}</span>}
        </span>
      </span>
      <button type="button" onClick={() => onChange(!checked)} className={cn("relative h-5 w-9 rounded-full transition-colors shrink-0", checked ? "bg-primary" : "bg-white/10")}>
        <span className="absolute top-0.5 h-4 w-4 rounded-full bg-white transition-all" style={{ left: checked ? "18px" : "2px" }} />
      </button>
    </label>
  );
}

// Color picker com swatch + hex input
export function ColorField({ label, value, onChange }) {
  return (
    <div className="space-y-1.5">
      <span className="text-muted-foreground text-xs">{label}</span>
      <div className="flex items-center gap-2">
        <input type="color" value={value || "#000000"} onChange={(e) => onChange(e.target.value)} className="h-8 w-8 rounded-md border border-white/10 bg-transparent cursor-pointer p-0" />
        <input value={value || ""} onChange={(e) => onChange(e.target.value)} placeholder="#C10000" className="flex-1 rounded-md bg-background border border-white/10 px-2.5 py-1.5 text-xs text-white font-mono focus:outline-none focus:border-primary/50" />
      </div>
    </div>
  );
}

// Cartão de seção do editor
export function SectionCard({ title, icon: Icon, children, action }) {
  return (
    <div className="rounded-lg surface p-3.5 space-y-3">
      <div className="flex items-center justify-between">
        <span className="flex items-center gap-2 text-sm text-white font-medium">
          {Icon && <Icon className="h-4 w-4 text-primary" />}
          {title}
        </span>
        {action}
      </div>
      {children}
    </div>
  );
}

// Barra de abas
export function TabBar({ tabs, active, onChange }) {
  return (
    <div className="flex gap-1 overflow-x-auto border-b border-white/5 pb-px">
      {tabs.map((t) => (
        <button key={t.id} onClick={() => onChange(t.id)} className={cn("flex items-center gap-1.5 whitespace-nowrap rounded-t-md px-3 py-2 text-xs font-medium transition-colors border-b-2 -mb-px", active === t.id ? "border-primary text-white bg-white/[0.03]" : "border-transparent text-muted-foreground hover:text-white")}>
          {t.icon && <t.icon className="h-3.5 w-3.5" />}
          {t.label}
        </button>
      ))}
    </div>
  );
}

// Seleção de chips (multi ou single)
export function ChipSelect({ options, value, onChange, multi = false }) {
  const isSelected = (v) => (multi ? (value || []).includes(v) : value === v);
  const toggle = (v) => {
    if (multi) {
      onChange(isSelected(v) ? (value || []).filter((x) => x !== v) : [...(value || []), v]);
    } else {
      onChange(v);
    }
  };
  return (
    <div className="flex flex-wrap gap-1.5">
      {options.map((o) => (
        <button key={o.v} type="button" onClick={() => toggle(o.v)} className={cn("rounded-md border px-2.5 py-1.5 text-[11px] font-medium transition-colors", isSelected(o.v) ? "border-primary/50 bg-primary/10 text-primary" : "border-white/10 text-muted-foreground hover:text-white")}>
          {o.l}
        </button>
      ))}
    </div>
  );
}

// Botão adicionar item (lista)
export function AddButton({ onClick, label = "Adicionar" }) {
  return (
    <button type="button" onClick={onClick} className="w-full rounded-md border border-dashed border-white/15 py-2 text-[11px] text-muted-foreground hover:text-white hover:border-primary/40 transition-colors">
      + {label}
    </button>
  );
}

// Input rotulado reutilizável dentro do editor
export function Field({ label, value, onChange, placeholder, type = "text", rows, mono }) {
  return (
    <div className="space-y-1">
      <span className="text-[11px] text-muted-foreground font-medium">{label}</span>
      {rows ? (
        <textarea value={value || ""} onChange={(e) => onChange(e.target.value)} rows={rows} placeholder={placeholder} className={cn("w-full rounded-md bg-background border border-white/10 px-2.5 py-1.5 text-xs text-white placeholder:text-muted-foreground/50 focus:outline-none focus:border-primary/50 resize-none", mono && "font-mono")} />
      ) : (
        <input type={type} value={value ?? ""} onChange={(e) => onChange(type === "number" ? (e.target.value === "" ? "" : parseFloat(e.target.value)) : e.target.value)} placeholder={placeholder} className={cn("w-full rounded-md bg-background border border-white/10 px-2.5 py-1.5 text-xs text-white placeholder:text-muted-foreground/50 focus:outline-none focus:border-primary/50", mono && "font-mono")} />
      )}
    </div>
  );
}